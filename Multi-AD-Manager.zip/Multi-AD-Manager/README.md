# AD Manager

Desktop application for managing **Active Directory** across **multiple client domains** from one workspace. Built for IT analysts who connect through **Ziti**, VPN, or direct networks using **WinRM**, **LDAP**, **SSH**, **local PowerShell**, or **ADWS**.

## Features

- **Multi-domain** — register many clients; per-domain color and connectivity strip
- **Multiple transports** — WinRM (HTTP/HTTPS/custom port), LDAP / LDAPS / StartTLS / custom, SSH tunnel → LDAP, SSH → PowerShell, local PowerShell (RSAT), ADWS
- **User lifecycle** — create, edit, disable, enable, unlock, reset password, move, delete, group membership
- **Groups & OUs** — browse, create, edit, members, move (within permissions of the service account)
- **Computers** — inventory-style listing where supported by the connector
- **Audit trail** — write operations recorded in local SQLite (`data/audit.sqlite`)
- **Encrypted credentials** — AES-256-GCM with a **PBKDF2**-derived key from a **master password** (master password is never stored on disk)
- **Dark / light** appearance — toggle in Settings

## Requirements

- **Windows** 10 or 11
- **Python 3.11+**
- Network path to DCs (Ziti, VPN, or LAN) matching the chosen **transport**

## Quick start

1. Run **`install_dependencies.bat`** to create a virtual environment and install dependencies (or use `pip install -r requirements.txt` manually).
2. Run **`python main.py`** or double-click **`run.bat`**.
3. On first launch, set a **master password** to protect the credential vault.
4. Add a domain with **+ Add Domain** in the sidebar (or copy `config/domains_config.example.json` to `config/domains_config.json` and edit).

## Domain controller prerequisites (WinRM)

Before connecting with **WinRM**, on each DC as Domain Admin:

```powershell
Enable-PSRemoting -Force
Set-Item WSMan:\localhost\Client\TrustedHosts -Value '*' -Force
Restart-Service WinRM
Get-Module -ListAvailable ActiveDirectory
```

Tighten **TrustedHosts** outside of lab environments.

For **LDAP**, **SSH**, **local PowerShell**, and **ADWS**, see **[docs/transports.md](docs/transports.md)**.

## Supported transports (summary)

| Method | Port | Use case |
|--------|------|----------|
| WinRM HTTP | 5985 | Default; Ziti with 5985 open |
| WinRM HTTPS | 5986 | TLS WinRM |
| WinRM custom | varies | Mapped non-default WinRM port |
| LDAP | 389 | Direct LDAP |
| LDAPS | 636 | Encrypted LDAP |
| LDAP + StartTLS | 389 | TLS upgrade on 389 |
| LDAP custom | varies | Non-standard LDAP/LDAPS port |
| SSH tunnel → LDAP | 22 + 389/636 | Via bastion / port forward |
| SSH → PowerShell | 22 | Windows OpenSSH + AD PowerShell |
| Local PowerShell | — | Analyst PC with RSAT / AD module |
| ADWS | 9389 (+ WinRM) | AD Web Services via PowerShell |

## Security notes

- Domain passwords and bind secrets are **encrypted** in `config/domains_config.json`.
- The **master password** is not written to disk; if you lose it, stored secrets cannot be recovered.
- **`config/domains_config.json`**, vault files under `config/`, and **`data/`** are listed in **`.gitignore`** — do not commit real customer configs.
- Use **Lock session** in Settings to clear keys from memory and disconnect connectors.
- Runtime errors are appended to **`logs/errors.log`** when present.

## Build standalone executable

```bat
build.bat
```

Output folder (PyInstaller one-folder build):

`dist\ADMultiDomainManager\ADMultiDomainManager.exe`

Copy **`config\domains_config.example.json`** to **`config\domains_config.json`** next to the executable (or create config through the UI) before distributing to analysts.

## GitHub setup

- First-time: run **`setup_github.bat`** (configures Git user for this repo, initial commit, remote, push to `main`).
- Updates: run **`push_update.bat`** (checks `.gitignore` before commit/push).

## Distribution package (source tree for colleagues)

Run **`build_distribution.bat`** to create **`dist_package\`** with code, `requirements.txt`, `install_dependencies.bat`, `run.bat`, docs, and **`config\domains_config.example.json` only** (never the real `domains_config.json`). Zip the folder and share.

## License

MIT
