"""SQLite-backed audit trail and simple file error logging."""

from __future__ import annotations

import getpass
import json
import sqlite3
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


_lock = threading.Lock()


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class AuditLogger:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    analyst TEXT NOT NULL,
                    domain_id TEXT,
                    domain_name TEXT,
                    operation TEXT NOT NULL,
                    target TEXT,
                    params_json TEXT,
                    success INTEGER NOT NULL,
                    error TEXT
                )
                """
            )
            con.commit()

    def log(
        self,
        *,
        operation: str,
        success: bool,
        domain_id: str | None = None,
        domain_name: str | None = None,
        target: str | None = None,
        params: dict | None = None,
        error: str | None = None,
    ) -> None:
        row = (
            _utc_now_iso(),
            getpass.getuser(),
            domain_id,
            domain_name,
            operation,
            target,
            json.dumps(params or {}, ensure_ascii=False),
            1 if success else 0,
            error or "",
        )
        with _lock, sqlite3.connect(self.db_path) as con:
            con.execute(
                "INSERT INTO audit (ts, analyst, domain_id, domain_name, operation, target, params_json, success, error) VALUES (?,?,?,?,?,?,?,?,?)",
                row,
            )
            con.commit()

    def fetch(
        self,
        *,
        limit: int = 500,
        domain_id: str | None = None,
        operation_like: str | None = None,
        only_failures: bool = False,
    ) -> list[dict]:
        q = "SELECT id, ts, analyst, domain_id, domain_name, operation, target, params_json, success, error FROM audit WHERE 1=1"
        args: list = []
        if domain_id:
            q += " AND domain_id = ?"
            args.append(domain_id)
        if operation_like:
            q += " AND operation LIKE ?"
            args.append(f"%{operation_like}%")
        if only_failures:
            q += " AND success = 0"
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with sqlite3.connect(self.db_path) as con:
            cur = con.execute(q, args)
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]


def append_error_log(project_root: Path, message: str, exc: BaseException | None = None) -> None:
    log_dir = project_root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / "errors.log"
    line = f"{_utc_now_iso()} | {message}"
    if exc is not None:
        line += f" | {type(exc).__name__}: {exc}"
    line += "\n"
    with _lock:
        path.open("a", encoding="utf-8").write(line)


def append_runtime_log(project_root: Path, message: str) -> None:
    """Append lightweight runtime trace messages for troubleshooting UI hangs."""
    log_dir = project_root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / "runtime.log"
    line = f"{_utc_now_iso()} | {message}\n"
    with _lock:
        path.open("a", encoding="utf-8").write(line)
