"""AES-256-GCM encryption for stored secrets with PBKDF2-HMAC-SHA256 master key."""

from __future__ import annotations

import base64
import json
import secrets
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

PBKDF2_ITERATIONS = 390_000
KEY_LEN = 32
NONCE_LEN = 12


def _app_data_dir(root: Path) -> Path:
    d = root / "config"
    d.mkdir(parents=True, exist_ok=True)
    return d


def vault_paths(project_root: Path) -> tuple[Path, Path]:
    base = _app_data_dir(project_root)
    return base / "vault_salt.bin", base / "vault_verify.json"


def has_vault(project_root: Path) -> bool:
    salt_path, verify_path = vault_paths(project_root)
    return salt_path.is_file() and verify_path.is_file()


def create_vault(project_root: Path, master_password: str) -> None:
    """First-run: generate salt and verification token."""
    salt_path, verify_path = vault_paths(project_root)
    salt = secrets.token_bytes(32)
    salt_path.write_bytes(salt)
    key = derive_key(master_password, salt)
    token = secrets.token_bytes(32)
    aes = AESGCM(key)
    nonce = secrets.token_bytes(NONCE_LEN)
    ct = aes.encrypt(nonce, token, None)
    verify_path.write_text(
        json.dumps(
            {
                "nonce": base64.b64encode(nonce).decode("ascii"),
                "ciphertext": base64.b64encode(ct).decode("ascii"),
            }
        ),
        encoding="utf-8",
    )


def derive_key(master_password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_LEN,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
        backend=default_backend(),
    )
    return kdf.derive(master_password.encode("utf-8"))


def verify_master_password(project_root: Path, master_password: str) -> bool:
    salt_path, verify_path = vault_paths(project_root)
    if not salt_path.is_file() or not verify_path.is_file():
        return False
    salt = salt_path.read_bytes()
    key = derive_key(master_password, salt)
    data = json.loads(verify_path.read_text(encoding="utf-8"))
    nonce = base64.b64decode(data["nonce"])
    ct = base64.b64decode(data["ciphertext"])
    aes = AESGCM(key)
    try:
        aes.decrypt(nonce, ct, None)
        return True
    except Exception:
        return False


def encrypt_secret(plaintext: str, key: bytes) -> str:
    aes = AESGCM(key)
    nonce = secrets.token_bytes(NONCE_LEN)
    ct = aes.encrypt(nonce, plaintext.encode("utf-8"), None)
    blob = nonce + ct
    return base64.b64encode(blob).decode("ascii")


def decrypt_secret(blob_b64: str, key: bytes) -> str:
    raw = base64.b64decode(blob_b64)
    nonce, ct = raw[:NONCE_LEN], raw[NONCE_LEN:]
    aes = AESGCM(key)
    pt = aes.decrypt(nonce, ct, None)
    return pt.decode("utf-8")


def load_master_key(project_root: Path, master_password: str) -> bytes | None:
    salt_path, _ = vault_paths(project_root)
    if not salt_path.is_file():
        return None
    salt = salt_path.read_bytes()
    if not verify_master_password(project_root, master_password):
        return None
    return derive_key(master_password, salt)
