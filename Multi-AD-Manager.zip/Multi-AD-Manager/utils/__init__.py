# Utility helpers (crypto, audit, validation).
