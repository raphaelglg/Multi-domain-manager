"""Lightweight validation helpers for AD / LDAP forms."""

from __future__ import annotations

import re

_DN_RE = re.compile(r"^(.+?)=(.+?)(?:,(.+?)=(.+?))*$")
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def is_non_empty(value: str | None) -> bool:
    return bool(value and str(value).strip())


def looks_like_dn(value: str) -> bool:
    v = (value or "").strip()
    if "=" not in v or "," not in v:
        return False
    return v.upper().startswith(("CN=", "OU=", "DC="))


def looks_like_upn(value: str) -> bool:
    return "@" in (value or "") and not looks_like_dn(value)


def is_valid_email(value: str) -> bool:
    return bool(_EMAIL_RE.match((value or "").strip()))


def sanitize_sam(value: str) -> str:
    v = re.sub(r"[^A-Za-z0-9._-]", "", (value or "").strip())
    return v[:20] if v else ""
