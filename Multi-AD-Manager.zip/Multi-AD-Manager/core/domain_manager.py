"""Coordinates multiple AD domains (multi-transport), persistence, and health checks."""

from __future__ import annotations

import copy
import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from core.domain_config import transport_display_name
from core.transport_factory import get_connector
from utils import crypto_vault
from utils.audit_logger import append_error_log, append_runtime_log


class DomainManager:
    def __init__(self, project_root: Path | None = None) -> None:
        self.project_root = project_root or Path(__file__).resolve().parents[1]
        self.config_path = self.project_root / "config" / "domains_config.json"
        self._domains: list[dict] = []
        self._connectors: dict[str, Any] = {}
        self._master_key: bytes | None = None
        self._status: dict[str, dict] = {}
        self._status_lock = threading.Lock()
        self._health_thread: threading.Thread | None = None
        self._health_stop = threading.Event()
        self._listeners: list[Callable[[], None]] = []
        self._last_sync: dict[str, float] = {}

    def set_master_key(self, key: bytes | None) -> None:
        self._master_key = key

    @property
    def master_key(self) -> bytes | None:
        return self._master_key

    def add_listener(self, cb: Callable[[], None]) -> None:
        self._listeners.append(cb)

    def _notify(self) -> None:
        for cb in list(self._listeners):
            try:
                cb()
            except Exception:
                pass

    def load_domains(self) -> None:
        if not self.config_path.is_file():
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            self._domains = []
            self.save_domains()
            return
        data = json.loads(self.config_path.read_text(encoding="utf-8"))
        self._domains = data.get("domains") or []
        self.fix_incomplete_base_dns()
        self.refresh_secrets()

    def fix_incomplete_base_dns(self) -> None:
        changed = False
        for d in self._domains:
            base_dn = str(d.get("base_dn") or "").strip()
            domain_name = str(d.get("domain_name") or "").strip().strip(".")
            if not domain_name:
                continue
            if not base_dn or "," not in base_dn:
                parts = [p for p in domain_name.split(".") if p]
                if not parts:
                    continue
                d["base_dn"] = ",".join([f"DC={p}" for p in parts])
                changed = True
        if changed:
            self.save_domains()

    def refresh_secrets(self) -> None:
        self._apply_decryption()

    def _apply_decryption(self) -> None:
        if not self._master_key:
            return
        for d in self._domains:
            enc = d.get("bind_password_encrypted")
            if enc:
                try:
                    d["_bind_password_plain"] = crypto_vault.decrypt_secret(enc, self._master_key)
                except Exception as e:  # noqa: BLE001
                    d["_bind_password_plain"] = ""
                    append_error_log(self.project_root, f"Failed to decrypt domain bind password {d.get('id')}", e)
            else:
                d["_bind_password_plain"] = d.get("_bind_password_plain", "")
            wenc = d.get("winrm_password_encrypted")
            if wenc:
                try:
                    d["_winrm_password_plain"] = crypto_vault.decrypt_secret(wenc, self._master_key)
                except Exception as e:  # noqa: BLE001
                    d["_winrm_password_plain"] = ""
                    append_error_log(self.project_root, f"Failed to decrypt WinRM password {d.get('id')}", e)
            else:
                d["_winrm_password_plain"] = d.get("_winrm_password_plain", "")
            if not d.get("_winrm_password_plain") and d.get("_bind_password_plain"):
                d["_winrm_password_plain"] = d["_bind_password_plain"]
            wr = d.get("winrm")
            if isinstance(wr, dict) and wr.get("password_encrypted"):
                try:
                    wp = crypto_vault.decrypt_secret(wr["password_encrypted"], self._master_key)
                    d["_winrm_password_plain"] = wp
                    wr["_password_plain"] = wp
                except Exception as e:  # noqa: BLE001
                    append_error_log(self.project_root, f"Failed to decrypt nested WinRM password {d.get('id')}", e)
            ld = d.get("ldap")
            if isinstance(ld, dict) and ld.get("password_encrypted"):
                try:
                    lp = crypto_vault.decrypt_secret(ld["password_encrypted"], self._master_key)
                    d["_ldap_password_plain"] = lp
                    ld["_password_plain"] = lp
                except Exception as e:  # noqa: BLE001
                    d["_ldap_password_plain"] = ""
                    append_error_log(self.project_root, f"Failed to decrypt LDAP password {d.get('id')}", e)
            else:
                d["_ldap_password_plain"] = d.get("_ldap_password_plain", "")
            if isinstance(ld, dict) and d.get("_ldap_password_plain"):
                ld["_password_plain"] = d["_ldap_password_plain"]
            sh = d.get("ssh")
            if isinstance(sh, dict) and sh.get("password_encrypted"):
                try:
                    sp = crypto_vault.decrypt_secret(sh["password_encrypted"], self._master_key)
                    d["_ssh_password_plain"] = sp
                    sh["_password_plain"] = sp
                except Exception as e:  # noqa: BLE001
                    d["_ssh_password_plain"] = ""
                    append_error_log(self.project_root, f"Failed to decrypt SSH password {d.get('id')}", e)
            else:
                d["_ssh_password_plain"] = d.get("_ssh_password_plain", "")
            if isinstance(sh, dict) and d.get("_ssh_password_plain"):
                sh["_password_plain"] = d["_ssh_password_plain"]
            adw = d.get("adws")
            if isinstance(adw, dict) and adw.get("password_encrypted"):
                try:
                    ap = crypto_vault.decrypt_secret(adw["password_encrypted"], self._master_key)
                    d["_adws_password_plain"] = ap
                    d["_winrm_password_plain"] = ap
                    adw["_password_plain"] = ap
                except Exception as e:  # noqa: BLE001
                    d["_adws_password_plain"] = ""
                    append_error_log(self.project_root, f"Failed to decrypt ADWS password {d.get('id')}", e)
            else:
                d["_adws_password_plain"] = d.get("_adws_password_plain", "")
            if not d.get("_ldap_password_plain") and d.get("_bind_password_plain"):
                d["_ldap_password_plain"] = d["_bind_password_plain"]
            ld2 = d.get("ldap")
            if isinstance(ld2, dict) and d.get("_ldap_password_plain"):
                ld2["_password_plain"] = d["_ldap_password_plain"]

    def _get_decrypted_config(self, domain: dict) -> dict:
        cfg = copy.deepcopy(domain)
        if not self._master_key:
            return cfg

        def safe_decrypt(encrypted: str) -> str:
            if not encrypted:
                return ""
            try:
                return crypto_vault.decrypt_secret(encrypted, self._master_key)
            except Exception:
                return ""

        if cfg.get("winrm_password_encrypted"):
            cfg["winrm_password"] = safe_decrypt(str(cfg.get("winrm_password_encrypted") or ""))
            cfg["_winrm_password_plain"] = cfg["winrm_password"]

        wr = cfg.get("winrm")
        if isinstance(wr, dict):
            if wr.get("password_encrypted"):
                wr["password"] = safe_decrypt(str(wr.get("password_encrypted") or ""))
                wr["_password_plain"] = wr["password"]
                cfg["_winrm_password_plain"] = wr["password"]
            if not wr.get("user") and cfg.get("winrm_user"):
                wr["user"] = cfg["winrm_user"]

        ld = cfg.get("ldap")
        if isinstance(ld, dict) and ld.get("password_encrypted"):
            ld["password"] = safe_decrypt(str(ld.get("password_encrypted") or ""))
            ld["_password_plain"] = ld["password"]
            cfg["_ldap_password_plain"] = ld["password"]

        sh = cfg.get("ssh")
        if isinstance(sh, dict) and sh.get("password_encrypted"):
            sh["password"] = safe_decrypt(str(sh.get("password_encrypted") or ""))
            sh["_password_plain"] = sh["password"]
            cfg["_ssh_password_plain"] = sh["password"]

        return cfg

    def _strip_private_keys(self, obj: Any) -> Any:
        if isinstance(obj, dict):
            return {k: self._strip_private_keys(v) for k, v in obj.items() if not str(k).startswith("_")}
        if isinstance(obj, list):
            return [self._strip_private_keys(x) for x in obj]
        return obj

    def save_domains(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        to_save: list[dict] = []
        for d in self._domains:
            c = {k: v for k, v in d.items() if not str(k).startswith("_")}
            to_save.append(self._strip_private_keys(c))
        payload = {"domains": to_save}
        self.config_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    def domains(self) -> list[dict]:
        out: list[dict] = []
        for d in self._domains:
            c = self._strip_private_keys(copy.deepcopy(d))
            for k in list(c.keys()):
                if str(k).startswith("_"):
                    del c[k]
            out.append(c)
        return out

    def get_domain(self, domain_id: str) -> dict | None:
        for d in self._domains:
            if d.get("id") == domain_id:
                c = self._strip_private_keys(copy.deepcopy(d))
                for k in list(c.keys()):
                    if str(k).startswith("_"):
                        del c[k]
                return c
        return None

    def add_domain(self, domain_config: dict) -> str:
        did = domain_config.get("id") or str(uuid.uuid4())
        domain_config["id"] = did
        self._domains.append(domain_config)
        self._apply_decryption()
        self.save_domains()
        return did

    def remove_domain(self, domain_id: str) -> None:
        self._domains = [d for d in self._domains if d.get("id") != domain_id]
        if domain_id in self._connectors:
            try:
                self._connectors[domain_id].disconnect()
            except Exception:
                pass
            del self._connectors[domain_id]
        with self._status_lock:
            self._status.pop(domain_id, None)
        self.save_domains()

    def update_domain(self, domain_id: str, changes: dict) -> None:
        for d in self._domains:
            if d.get("id") == domain_id:
                d.update(changes)
                break
        self._apply_decryption()
        self.save_domains()

    def connect_all(self) -> None:
        with ThreadPoolExecutor(max_workers=min(8, max(1, len(self._domains)))) as ex:
            futs = {ex.submit(self.connect_domain, d.get("id")): d.get("id") for d in self._domains if d.get("enabled", True)}
            for fut in as_completed(futs):
                _ = fut.result()

    def reconnect_domain(self, domain_id: str) -> bool:
        append_runtime_log(self.project_root, f"domain_manager:reconnect:start:{domain_id}")
        cfg0 = self._domain_by_id(domain_id)
        self._set_status(
            domain_id,
            state="reconnecting",
            message="Reconnecting…",
            latency_ms=0.0,
            transport=transport_display_name((cfg0 or {}).get("transport")),
        )
        self._notify()
        if domain_id in self._connectors:
            try:
                self._connectors[domain_id].disconnect()
            except Exception:
                pass
            del self._connectors[domain_id]
        ok = self.connect_domain(domain_id)
        append_runtime_log(self.project_root, f"domain_manager:reconnect:done:{domain_id}:ok={ok}")
        return ok

    def connect_domain(self, domain_id: str) -> bool:
        append_runtime_log(self.project_root, f"domain_manager:connect:start:{domain_id}")
        raw_cfg = self._domain_by_id(domain_id)
        cfg = self._get_decrypted_config(raw_cfg) if raw_cfg else None
        if not cfg:
            append_runtime_log(self.project_root, f"domain_manager:connect:missing_cfg:{domain_id}")
            return False
        if not cfg.get("enabled", True):
            self._set_status(
                domain_id,
                state="disabled",
                message="Domain disabled.",
                transport=transport_display_name(cfg.get("transport")),
            )
            append_runtime_log(self.project_root, f"domain_manager:connect:disabled:{domain_id}")
            return False
        try:
            con = get_connector(cfg)
        except Exception as e:  # noqa: BLE001
            append_error_log(self.project_root, f"get_connector {domain_id}", e)
            self._set_status(
                domain_id,
                state="offline",
                message=str(e),
                transport=transport_display_name(cfg.get("transport")),
            )
            self._notify()
            return False
        if str(cfg.get("transport") or "").startswith("winrm"):
            winrm_pw = (
                (cfg.get("winrm") or {}).get("password")
                or cfg.get("_winrm_password_plain")
                or cfg.get("winrm_password")
                or ""
            )
            winrm_user = (cfg.get("winrm") or {}).get("user") or cfg.get("winrm_user") or ""
            if not winrm_user:
                self._set_status(
                    domain_id,
                    state="offline",
                    message="WinRM username is missing. Edit domain and set WinRM user.",
                    transport=transport_display_name(cfg.get("transport")),
                )
                self._notify()
                return False
            if not winrm_pw:
                self._set_status(
                    domain_id,
                    state="offline",
                    message="WinRM password could not be decrypted. Re-enter it in Edit Domain.",
                    transport=transport_display_name(cfg.get("transport")),
                )
                self._notify()
                return False
        ok = con.connect()
        self._connectors[domain_id] = con
        tlabel = transport_display_name(cfg.get("transport"))
        ep = getattr(con, "_active_server_endpoint", "") or ""
        lbl = getattr(con, "_active_server_label", "") or ""
        if ok:
            self._set_status(
                domain_id,
                state="online",
                message="Connected",
                latency_ms=0.0,
                active_server=lbl,
                active_endpoint=ep,
                transport=tlabel,
            )
            self._last_sync[domain_id] = time.time()
        else:
            self._set_status(
                domain_id,
                state="offline",
                message=con.last_error or "Connection failed.",
                active_server=lbl,
                active_endpoint=ep,
                transport=tlabel,
            )
        self._notify()
        append_runtime_log(self.project_root, f"domain_manager:connect:done:{domain_id}:ok={ok}:msg={con.last_error}")
        return ok

    def debug_credentials(self) -> None:
        for d in self._domains:
            cfg = self._get_decrypted_config(d)
            wr = cfg.get("winrm") or {}
            winrm_user = wr.get("user") or cfg.get("winrm_user") or ""
            winrm_pw = wr.get("password") or cfg.get("winrm_password") or cfg.get("_winrm_password_plain") or ""
            servers = wr.get("servers") if isinstance(wr, dict) else None
            if not servers:
                servers = cfg.get("dc_servers") or []
            hosts = [s.get("host") for s in servers if isinstance(s, dict)]
            append_runtime_log(
                self.project_root,
                f"[DEBUG] {(d.get('client_name') or d.get('domain_name') or d.get('id'))}: user='{winrm_user}' password={'SET' if bool(winrm_pw) else 'MISSING'} servers={hosts}",
            )

    def disconnect_all(self) -> None:
        for c in self._connectors.values():
            try:
                c.disconnect()
            except Exception:
                pass
        self._connectors.clear()

    def get_connector(self, domain_id: str) -> Any:
        if domain_id not in self._connectors:
            raise KeyError(domain_id)
        return self._connectors[domain_id]

    def _domain_by_id(self, domain_id: str) -> dict | None:
        for d in self._domains:
            if d.get("id") == domain_id:
                return d
        return None

    def _set_status(
        self,
        domain_id: str,
        *,
        state: str,
        message: str = "",
        latency_ms: float = 0.0,
        active_server: str = "",
        active_endpoint: str = "",
        transport: str = "",
    ) -> None:
        with self._status_lock:
            prev = self._status.get(domain_id, {}).get("state")
            self._status[domain_id] = {
                "state": state,
                "latency_ms": latency_ms,
                "active_server": active_server,
                "active_endpoint": active_endpoint,
                "transport": transport,
                "last_sync": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self._last_sync.get(domain_id, 0))),
                "message": message,
                "prev": prev,
            }

    def check_all_status(self) -> dict[str, dict]:
        results: dict[str, dict] = {}
        for d in self._domains:
            did = d.get("id")
            if not did:
                continue
            if not d.get("enabled", True):
                self._set_status(did, state="disabled", message="Disabled", transport=transport_display_name(d.get("transport")))
                results[did] = dict(self._status[did])
                continue
            cfg = copy.deepcopy(d)
            try:
                con = get_connector(cfg)
            except Exception as e:  # noqa: BLE001
                self._set_status(
                    did,
                    state="offline",
                    message=str(e),
                    transport=transport_display_name(d.get("transport")),
                )
                results[did] = dict(self._status[did])
                continue
            ok, msg, ms = con.test_connection()
            try:
                con.disconnect()
            except Exception:
                pass
            state = "online" if ok else "offline"
            ep = getattr(con, "_active_server_endpoint", "") or ""
            lbl = getattr(con, "_active_server_label", "") or ""
            self._set_status(
                did,
                state=state,
                message=msg,
                latency_ms=ms,
                active_server=lbl,
                active_endpoint=ep,
                transport=transport_display_name(d.get("transport")),
            )
            if ok:
                self._last_sync[did] = time.time()
            results[did] = dict(self._status[did])
        self._notify()
        return results

    def start_health_check_loop(self, interval_sec: int = 30) -> None:
        if self._health_thread and self._health_thread.is_alive():
            return
        self._health_stop.clear()

        def loop() -> None:
            while not self._health_stop.wait(interval_sec):
                try:
                    self.check_all_status()
                except Exception as e:  # noqa: BLE001
                    append_error_log(self.project_root, "Health check failed", e)

        self._health_thread = threading.Thread(target=loop, name="ad-health", daemon=True)
        self._health_thread.start()

    def stop_health_check_loop(self) -> None:
        self._health_stop.set()

    def status_snapshot(self) -> dict[str, dict]:
        with self._status_lock:
            return copy.deepcopy(self._status)

    def get_all_users_consolidated(self) -> list[dict]:
        rows: list[dict] = []

        def work(item: tuple[str, dict]) -> list[dict]:
            domain_id, dcfg = item
            out: list[dict] = []
            try:
                if domain_id not in self._connectors:
                    self.connect_domain(domain_id)
                con = self.get_connector(domain_id)
                if not con.is_connected:
                    return out
                for u in con.get_all_users():
                    u2 = dict(u)
                    u2["domain_id"] = domain_id
                    u2["client_name"] = dcfg.get("client_name", "")
                    u2["domain_name"] = dcfg.get("domain_name", "")
                    out.append(u2)
            except Exception as e:  # noqa: BLE001
                append_error_log(self.project_root, f"get_all_users {domain_id}", e)
            return out

        items = [(d.get("id"), d) for d in self._domains if d.get("id") and d.get("enabled", True)]
        with ThreadPoolExecutor(max_workers=min(8, max(1, len(items)))) as ex:
            futs = [ex.submit(work, it) for it in items if it[0]]
            for fut in as_completed(futs):
                rows.extend(fut.result())
        return rows

    def refresh_connectors_after_unlock(self) -> None:
        """Reload decrypted passwords into domain dicts."""
        self._apply_decryption()
        for did, con in list(self._connectors.items()):
            cfg = self._domain_by_id(did)
            if cfg:
                con.cfg = copy.deepcopy(cfg)
