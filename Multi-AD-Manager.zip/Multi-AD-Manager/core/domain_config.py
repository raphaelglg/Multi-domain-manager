"""Normalize domain JSON (legacy flat + nested multi-transport) for connectors."""

from __future__ import annotations

import copy
from typing import Any

VALID_TRANSPORTS = frozenset(
    {
        "winrm_http",
        "winrm_https",
        "winrm_custom",
        "ldap",
        "ldaps",
        "ldap_starttls",
        "ldap_custom",
        "ssh_ldap_tunnel",
        "ssh_powershell",
        "powershell_local",
        "adws",
    }
)

TRANSPORT_LABELS: dict[str, str] = {
    "winrm_http": "WinRM HTTP",
    "winrm_https": "WinRM HTTPS",
    "winrm_custom": "WinRM (custom port)",
    "ldap": "LDAP",
    "ldaps": "LDAPS",
    "ldap_starttls": "LDAP with StartTLS",
    "ldap_custom": "LDAP/LDAPS (custom port)",
    "ssh_ldap_tunnel": "SSH tunnel → LDAP",
    "ssh_powershell": "SSH → PowerShell",
    "powershell_local": "Local PowerShell",
    "adws": "ADWS (9389)",
}


def transport_display_name(transport: str | None) -> str:
    t = transport or "winrm_http"
    return TRANSPORT_LABELS.get(t, t.replace("_", " ").title())


def _infer_transport_from_legacy(d: dict[str, Any]) -> str:
    if d.get("transport") in VALID_TRANSPORTS:
        return str(d["transport"])
    if d.get("use_https"):
        return "winrm_https"
    return "winrm_http"


def _ensure_winrm_block(d: dict[str, Any]) -> dict[str, Any]:
    wr = d.get("winrm")
    if isinstance(wr, dict) and wr.get("servers"):
        return wr
    if d.get("transport") == "adws":
        adws = d.get("adws") if isinstance(d.get("adws"), dict) else {}
        servers = []
        for s in adws.get("servers") or []:
            host = (s.get("host") or "").strip()
            if not host:
                continue
            servers.append(
                {
                    "host": host,
                    "port": int(s.get("winrm_port") or 5985),
                    "label": (s.get("label") or host).strip(),
                }
            )
        return {
            "servers": servers,
            "user": (adws.get("user") or "").strip(),
            "password_encrypted": adws.get("password_encrypted", ""),
            "use_https": bool(adws.get("use_https", d.get("use_https", False))),
            "validate_ssl": bool(adws.get("validate_ssl", d.get("validate_ssl", False))),
        }
    servers: list[dict[str, Any]] = []
    use_https = bool(d.get("use_https", False))
    default_port = 5986 if use_https else 5985
    for dc in d.get("dc_servers") or []:
        host = (dc.get("host") or "").strip()
        if not host:
            continue
        pw = int(dc.get("port_winrm") or dc.get("port") or default_port)
        servers.append(
            {
                "host": host,
                "port": pw,
                "label": (dc.get("label") or host).strip(),
            }
        )
    return {
        "servers": servers,
        "user": (d.get("winrm_user") or d.get("bind_user") or "").strip(),
        "password_encrypted": d.get("winrm_password_encrypted") or d.get("bind_password_encrypted") or "",
        "use_https": bool(d.get("use_https", False)),
        "validate_ssl": bool(d.get("validate_ssl", d.get("validate_cert", False))),
    }


def _ensure_ldap_block(d: dict[str, Any], transport: str) -> dict[str, Any]:
    ldap = d.get("ldap")
    if isinstance(ldap, dict) and ldap.get("servers"):
        out = dict(ldap)
        out.setdefault("bind_user", d.get("bind_user", ""))
        out.setdefault("password_encrypted", d.get("bind_password_encrypted", ""))
        out.setdefault("use_ssl", transport == "ldaps")
        out.setdefault("use_start_tls", transport == "ldap_starttls")
        out.setdefault("validate_ssl", bool(d.get("validate_ssl", False)))
        return out
    # legacy: no nested ldap
    use_ssl = transport in ("ldaps", "ldap_custom") and int(d.get("ldap_port") or 389) == 636
    host = (d.get("ldap_host") or "").strip()
    servers: list[dict[str, Any]] = []
    if host:
        servers.append(
            {
                "host": host,
                "port": int(d.get("ldap_port") or (636 if use_ssl else 389)),
                "label": host,
            }
        )
    return {
        "servers": servers,
        "bind_user": (d.get("bind_user") or "").strip(),
        "password_encrypted": d.get("bind_password_encrypted", ""),
        "use_ssl": use_ssl,
        "use_start_tls": transport == "ldap_starttls",
        "validate_ssl": bool(d.get("validate_ssl", False)),
    }


def _ensure_adws_block(d: dict[str, Any]) -> dict[str, Any]:
    adws = d.get("adws")
    if isinstance(adws, dict) and adws.get("servers"):
        return adws
    servers: list[dict[str, Any]] = []
    for dc in d.get("dc_servers") or []:
        host = (dc.get("host") or "").strip()
        if not host:
            continue
        servers.append(
            {
                "host": host,
                "port": int(dc.get("port_adws") or dc.get("port") or 9389),
                "winrm_port": int(dc.get("port_winrm") or 5985),
                "label": (dc.get("label") or host).strip(),
            }
        )
    wr = _ensure_winrm_block(d)
    return {
        "servers": servers,
        "user": wr.get("user", ""),
        "password_encrypted": d.get("winrm_password_encrypted", ""),
        "validate_ssl": wr.get("validate_ssl", False),
    }


def normalized_connector_config(domain: dict[str, Any]) -> dict[str, Any]:
    """Deep copy with nested winrm/ldap/ssh/adws filled for connector use (read-only shape)."""
    d = copy.deepcopy(domain)
    transport = _infer_transport_from_legacy(d)
    if d.get("transport") not in VALID_TRANSPORTS:
        d["transport"] = transport
    d["winrm"] = _ensure_winrm_block(d)
    d["ldap"] = _ensure_ldap_block(d, str(d.get("transport", transport)))
    d["adws"] = _ensure_adws_block(d)
    if "ssh" not in d or not isinstance(d.get("ssh"), dict):
        d["ssh"] = {
            "host": "",
            "port": 22,
            "user": "",
            "password_encrypted": "",
            "private_key_path": "",
            "tunnel_local_port": 13890,
            "tunnel_remote_host": "127.0.0.1",
            "tunnel_remote_port": 389,
        }
    return d


def winrm_effective_https(domain: dict[str, Any]) -> bool:
    t = domain.get("transport", "winrm_http")
    if t == "winrm_https":
        return True
    if t == "winrm_http":
        return bool(domain.get("winrm", {}).get("use_https", domain.get("use_https", False)))
    if t == "winrm_custom":
        return bool(domain.get("winrm", {}).get("use_https", domain.get("use_https", False)))
    if t == "adws":
        return bool(domain.get("winrm", {}).get("use_https", domain.get("use_https", False)))
    return bool(domain.get("use_https", False))


def ldap_effective_ssl_flags(domain: dict[str, Any]) -> tuple[bool, bool]:
    """Returns (use_ssl, use_start_tls) for ldap3 Server."""
    t = str(domain.get("transport", "ldap"))
    ldap = domain.get("ldap") or {}
    if t == "ldaps":
        return True, False
    if t == "ldap_starttls":
        return False, True
    if t == "ldap_custom":
        return bool(ldap.get("use_ssl", False)), bool(ldap.get("use_start_tls", False))
    if t == "ldap":
        return False, False
    return bool(ldap.get("use_ssl", False)), bool(ldap.get("use_start_tls", False))
