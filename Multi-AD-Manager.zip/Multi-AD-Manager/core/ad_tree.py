"""Build nested OU tree from flat distinguished names."""

from __future__ import annotations


def build_ou_hierarchy(ou_dns: list[str], base_dn: str) -> list[dict]:
    ou_dns = sorted(set(ou_dns), key=lambda s: (s.count(","), s))
    nodes: dict[str, dict] = {}

    def ensure(dn: str) -> dict:
        if dn not in nodes:
            name = dn.split(",")[0].split("=", 1)[-1] if "=" in dn else dn
            nodes[dn] = {"dn": dn, "name": name, "children": []}
        return nodes[dn]

    for dn in ou_dns:
        ensure(dn)

    root = {"dn": base_dn, "name": base_dn, "children": []}
    for dn in ou_dns:
        node = ensure(dn)
        parent = ",".join(dn.split(",")[1:])
        if parent.upper() == base_dn.upper():
            if node not in root["children"]:
                root["children"].append(node)
        elif parent in nodes:
            pnode = ensure(parent)
            if node not in pnode["children"]:
                pnode["children"].append(node)
        else:
            if node not in root["children"]:
                root["children"].append(node)

    return [root]
