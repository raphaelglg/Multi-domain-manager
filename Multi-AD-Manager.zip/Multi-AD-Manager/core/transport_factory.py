"""Instantiate the correct AD connector for a domain's transport."""

from __future__ import annotations

from typing import Any

from core.domain_config import VALID_TRANSPORTS, normalized_connector_config

TRANSPORT_MAP: dict[str, str] = {
    "winrm_http": "winrm",
    "winrm_https": "winrm",
    "winrm_custom": "winrm",
    "ldap": "ldap",
    "ldaps": "ldap",
    "ldap_starttls": "ldap",
    "ldap_custom": "ldap",
    "ssh_ldap_tunnel": "ssh",
    "ssh_powershell": "ssh_ps",
    "powershell_local": "local",
    "adws": "adws",
}


def get_connector(domain_config: dict[str, Any]) -> Any:
    cfg = normalized_connector_config(domain_config)
    transport = str(cfg.get("transport") or "winrm_http")
    if transport not in VALID_TRANSPORTS:
        raise ValueError(f"Unsupported transport: {transport}")
    kind = TRANSPORT_MAP[transport]
    if kind == "winrm":
        from core.winrm_connector import WinRMConnector

        return WinRMConnector(cfg)
    if kind == "ldap":
        from core.ldap_connector import LDAPConnector

        return LDAPConnector(cfg)
    if kind == "ssh":
        from core.ssh_connector import SSHLDAPConnector

        return SSHLDAPConnector(cfg)
    if kind == "ssh_ps":
        from core.ssh_connector import SSHPowerShellConnector

        return SSHPowerShellConnector(cfg)
    if kind == "local":
        from core.local_ps_connector import LocalPSConnector

        return LocalPSConnector(cfg)
    if kind == "adws":
        from core.adws_connector import ADWSConnector

        return ADWSConnector(cfg)
    raise ValueError(f"Unsupported transport: {transport}")
