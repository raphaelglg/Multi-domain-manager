"""Active Directory constants and display helpers (no LDAP dependency)."""

from __future__ import annotations

import re
import time
from typing import Any

UAC_ACCOUNTDISABLE = 0x0002
UAC_DONT_EXPIRE_PASSWD = 0x10000
UAC_PASSWD_NOTREQD = 0x0020
UAC_NORMAL_ACCOUNT = 0x0200
UAC_SMARTCARD_REQUIRED = 0x40000


def _filetime_to_iso(raw: Any) -> str:
    """100-ns Windows filetime string, or empty."""
    if raw in (None, "", 0, "0"):
        return ""
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return ""
    if v == 9223372036854775807:
        return ""
    secs = (v / 10_000_000.0) - 11644473600.0
    if secs <= 0:
        return ""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(secs))


def user_last_logon_display(user: dict) -> str:
    """Last logon for grid/detail: supports filetime or ISO-ish strings from WinRM/JSON."""
    v = user.get("lastLogonTimestamp") or user.get("LastLogonDate") or user.get("lastLogonDate")
    if v is None or v == "":
        return ""
    s = str(v).strip()
    if re.match(r"^\d{13,}$", s) or (s.isdigit() and len(s) > 8):
        return _filetime_to_iso(s)
    # Already human-readable (e.g. from PowerShell JSON)
    if len(s) >= 10 and s[4] == "-" and s[7] == "-":
        return s[:19].replace("T", " ")
    return s
