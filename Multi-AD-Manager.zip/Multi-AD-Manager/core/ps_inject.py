"""Inject -Server 'spec' into ActiveDirectory PowerShell cmdlet invocations."""

from __future__ import annotations

import re


def _ps_sq(value: str) -> str:
    return str(value or "").replace("'", "''")


_AD_CMDLETS = (
    "Get-ADUser",
    "Set-ADUser",
    "New-ADUser",
    "Remove-ADUser",
    "Enable-ADAccount",
    "Disable-ADAccount",
    "Unlock-ADAccount",
    "Set-ADAccountPassword",
    "Move-ADObject",
    "Get-ADGroup",
    "Set-ADGroup",
    "New-ADGroup",
    "Remove-ADGroup",
    "Get-ADGroupMember",
    "Add-ADGroupMember",
    "Remove-ADGroupMember",
    "Get-ADOrganizationalUnit",
    "New-ADOrganizationalUnit",
    "Get-ADComputer",
    "Get-ADObject",
    "Get-ADDomain",
    "Get-ADForest",
)


def inject_ad_server(script: str, server_spec: str) -> str:
    """Add -Server 'server_spec' to AD cmdlets that do not already specify -Server."""
    srv = _ps_sq(server_spec)
    out = script
    for name in _AD_CMDLETS:
        pattern = rf"(?m)\b{re.escape(name)}\b(?!\s+-Server\s)"
        out = re.sub(pattern, f"{name} -Server '{srv}'", out)
    return out
