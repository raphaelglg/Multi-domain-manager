"""AD operations via WinRM to the DC, forcing AD Web Services (port 9389) with -Server."""

from __future__ import annotations

from typing import Any

from core.connector_errors import format_adws_error
from core.ps_inject import inject_ad_server
from core.winrm_connector import WinRMConnector, _ps_sq


class ADWSConnector(WinRMConnector):
    """WinRM session on 5985/5986; ActiveDirectory cmdlets target host:9389 (ADWS)."""

    def __init__(self, domain_config: dict[str, Any]) -> None:
        super().__init__(domain_config)
        self._adws_target = ""

    def connect(self) -> bool:
        ok = super().connect()
        if not ok or self._mock_mode:
            return ok
        host = getattr(self, "_active_server_host", "") or ""
        adws = self.cfg.get("adws") or {}
        port = 9389
        for s in adws.get("servers") or []:
            if (s.get("host") or "").strip() == host:
                port = int(s.get("port", 9389))
                break
        self._adws_target = f"{host}:{port}" if host else ""
        return ok

    def disconnect(self) -> None:
        super().disconnect()
        self._adws_target = ""

    def _run_ps(self, script: str) -> tuple[bool, str]:
        if self._mock_mode or not self._adws_target:
            return super()._run_ps(script)
        injected = inject_ad_server(script, self._adws_target)
        ok, msg = super()._run_ps(injected)
        if not ok and ("9389" in msg or "9389" in (self._last_error or "")):
            self._last_error = format_adws_error(msg)
        return ok, msg

    def test_connection(self) -> tuple[bool, str, float]:
        import time

        if self._mock_mode:
            return True, "Mock mode: no ADWS connection.", 0.0
        t0 = time.perf_counter()
        ok = self.connect()
        ms = (time.perf_counter() - t0) * 1000.0
        if not ok:
            self.disconnect()
            return False, format_adws_error(self._last_error), ms
        hp = self._adws_target or f"{getattr(self, '_active_server_host', 'localhost')}:9389"
        script = f"Import-Module ActiveDirectory -ErrorAction Stop; (Get-ADDomain -Server '{_ps_sq(hp)}').DNSRoot"
        r_ok, out = self._run_ps_raw(script)
        self.disconnect()
        if r_ok:
            return True, f"Connected: {out}", ms
        return False, format_adws_error(out), ms

    def _run_ps_raw(self, script: str) -> tuple[bool, str]:
        """One-off without double ADWS injection (test uses explicit -Server)."""
        if self._mock_mode:
            return False, "Not supported in mock_mode."
        if not self._session:
            return False, "Not connected."
        full = f"Import-Module ActiveDirectory -ErrorAction Stop\n{script}"
        try:
            r = self._session.run_ps(full)
            out = (r.std_out or b"").decode("utf-8", errors="replace").strip()
            err = (r.std_err or b"").decode("utf-8", errors="replace").strip()
            if r.status_code == 0:
                return True, out
            self._last_error = err or out or f"code {r.status_code}"
            return False, self._last_error
        except Exception as e:  # noqa: BLE001
            self._last_error = str(e)
            return False, str(e)
