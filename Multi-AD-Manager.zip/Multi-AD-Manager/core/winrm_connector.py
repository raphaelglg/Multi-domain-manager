"""WinRM + remote PowerShell connector (ActiveDirectory module on DC)."""

from __future__ import annotations

import copy
import json
import threading
import time
import uuid
from typing import Any

from core.ad_constants import UAC_ACCOUNTDISABLE, UAC_DONT_EXPIRE_PASSWD, UAC_NORMAL_ACCOUNT, UAC_PASSWD_NOTREQD
from core.ad_tree import build_ou_hierarchy
from core.domain_config import winrm_effective_https

try:
    import winrm
except ImportError:
    winrm = None  # type: ignore[misc, assignment]


def _ps_sq(value: str) -> str:
    """Escape for PowerShell single-quoted string."""
    return str(value or "").replace("'", "''")


def _mock_users(base_dn: str, domain_name: str) -> list[dict]:
    ou = f"OU=DemoUsers,{base_dn}"
    return [
        {
            "sAMAccountName": "jsilva",
            "givenName": "John",
            "sn": "Silva",
            "displayName": "John Silva",
            "mail": "joao.silva@example.local",
            "telephoneNumber": "+5511999990001",
            "title": "Analyst",
            "department": "IT",
            "company": "Demo Corp",
            "description": "Demo account",
            "distinguishedName": f"CN=John Silva,{ou}",
            "memberOf": [f"CN=Domain Users,CN=Users,{base_dn}"],
            "userAccountControl": str(UAC_NORMAL_ACCOUNT),
            "lastLogonTimestamp": "133801234567890123",
            "whenCreated": "20240101000000.0Z",
            "whenChanged": "20240601000000.0Z",
            "userPrincipalName": f"jsilva@{domain_name}",
            "objectGUID": str(uuid.uuid4()),
            "objectClass": ["top", "person", "organizationalPerson", "user"],
        },
        {
            "sAMAccountName": "msantos",
            "givenName": "Mary",
            "sn": "Santos",
            "displayName": "Mary Santos",
            "mail": "maria.santos@example.local",
            "telephoneNumber": "",
            "title": "Manager",
            "department": "HR",
            "company": "Demo Corp",
            "description": "",
            "distinguishedName": f"CN=Mary Santos,{ou}",
            "memberOf": [f"CN=Domain Users,CN=Users,{base_dn}"],
            "userAccountControl": str(UAC_NORMAL_ACCOUNT | UAC_ACCOUNTDISABLE),
            "lastLogonTimestamp": "0",
            "whenCreated": "20240201000000.0Z",
            "whenChanged": "20240615000000.0Z",
            "userPrincipalName": f"msantos@{domain_name}",
            "objectGUID": str(uuid.uuid4()),
            "objectClass": ["top", "person", "organizationalPerson", "user"],
        },
    ]


def _mock_groups(base_dn: str) -> list[dict]:
    return [
        {
            "cn": "Domain Users",
            "name": "Domain Users",
            "samAccountName": "Domain Users",
            "distinguishedName": f"CN=Domain Users,CN=Users,{base_dn}",
            "groupType": "-2147483646",
            "description": "Built-in group",
            "member_count": 2,
        },
        {
            "cn": "Demo-App-Users",
            "name": "Demo-App-Users",
            "samAccountName": "Demo-App-Users",
            "distinguishedName": f"CN=Demo-App-Users,OU=DemoGroups,{base_dn}",
            "groupType": "-2147483646",
            "description": "Demo application group",
            "member_count": 1,
        },
    ]


def _mock_computers(base_dn: str) -> list[dict]:
    return [
        {
            "name": "WS-DEMO01",
            "distinguishedName": f"CN=WS-DEMO01,OU=DemoComputers,{base_dn}",
            "operatingSystem": "Windows 11 Pro",
            "lastLogonTimestamp": "133801234567890123",
            "whenChanged": "20240601000000.0Z",
        }
    ]


def _mock_ou_tree(base_dn: str) -> list[dict]:
    return [
        {
            "dn": base_dn,
            "name": base_dn,
            "children": [
                {"dn": f"OU=DemoUsers,{base_dn}", "name": "DemoUsers", "children": []},
                {"dn": f"OU=DemoComputers,{base_dn}", "name": "DemoComputers", "children": []},
                {"dn": f"OU=DemoGroups,{base_dn}", "name": "DemoGroups", "children": []},
            ],
        }
    ]


class WinRMConnector:
    """Runs Active Directory cmdlets on a domain controller via WinRM (5985/5986)."""

    def __init__(self, domain_config: dict) -> None:
        self.cfg = copy.deepcopy(domain_config)
        self._session: Any = None
        self._last_error = ""
        self._mock_mode = bool(self.cfg.get("mock_mode"))
        self._timeout = int(self.cfg.get("connection_timeout_sec", 30))
        self._active_server_label = ""
        self._active_server_endpoint = ""
        self._active_server_host = ""
        self._read_timeout = max(self._timeout, 45)
        self._ps_lock = threading.Lock()

    @property
    def is_connected(self) -> bool:
        if self._mock_mode:
            return True
        return self._session is not None

    @property
    def last_error(self) -> str:
        return self._last_error

    def _normalize_user(self, user: str) -> str:
        user = str(user or "").strip()
        if not user:
            return user
        if "\\" in user or "@" in user:
            return user
        return user

    def _winrm_user(self) -> str:
        wr = self.cfg.get("winrm")
        if isinstance(wr, dict) and (wr.get("user") or "").strip():
            return self._normalize_user(str(wr["user"]).strip())
        return self._normalize_user((self.cfg.get("winrm_user") or self.cfg.get("bind_user") or "").strip())

    def _winrm_password(self) -> str:
        wr = self.cfg.get("winrm") or {}
        return (
            self.cfg.get("_winrm_password_plain")
            or wr.get("_password_plain")
            or wr.get("password")
            or self.cfg.get("winrm_password")
            or self.cfg.get("_bind_password_plain")
            or ""
        ).strip()

    def _use_https(self) -> bool:
        return winrm_effective_https(self.cfg)

    def _validate_ssl(self) -> bool:
        wr = self.cfg.get("winrm")
        if isinstance(wr, dict) and "validate_ssl" in wr:
            return bool(wr.get("validate_ssl"))
        return bool(self.cfg.get("validate_ssl", self.cfg.get("validate_cert", False)))

    def _dc_servers_normalized(self) -> list[dict]:
        out: list[dict] = []
        use_https = self._use_https()
        wr = self.cfg.get("winrm")
        source: list[dict] = []
        if isinstance(wr, dict) and wr.get("servers"):
            source = list(wr["servers"])
        else:
            source = list(self.cfg.get("dc_servers") or [])
        for dc in source:
            host = (dc.get("host") or "").strip()
            if not host:
                continue
            row = dict(dc)
            port_val = row.get("port_winrm") if "port_winrm" in row else row.get("port")
            if port_val in (None, 0):
                legacy = int(row.get("port") or 0)
                if legacy in (389, 636, 3389, 0):
                    row["port_winrm"] = 5986 if use_https else 5985
                else:
                    row["port_winrm"] = legacy
            else:
                row["port_winrm"] = int(port_val)
            row.setdefault("label", host)
            out.append(row)
        return out

    def _open_session(self, server: dict) -> Any | None:
        if winrm is None:
            self._last_error = "pywinrm is not installed."
            return None
        host = server["host"]
        port = int(server.get("port_winrm") or (5986 if self._use_https() else 5985))
        scheme = "https" if self._use_https() else "http"
        target = f"{scheme}://{host}:{port}/wsman"
        transport = "ssl" if self._use_https() else "ntlm"
        validation = "validate" if self._use_https() and self._validate_ssl() else "ignore"
        user = self._winrm_user()
        pwd = self._winrm_password()
        if not user or not pwd:
            self._last_error = "WinRM username or password missing."
            return None
        try:
            return winrm.Session(
                target,
                auth=(user, pwd),
                transport=transport,
                server_cert_validation=validation,
                operation_timeout_sec=self._timeout,
                read_timeout_sec=self._read_timeout,
            )
        except Exception as e:  # noqa: BLE001
            self._last_error = str(e)
            return None

    def connect(self) -> bool:
        if self._mock_mode:
            self._last_error = ""
            return True
        if winrm is None:
            self._last_error = "pywinrm is not installed."
            return False
        for server in self._dc_servers_normalized():
            session = self._open_session(server)
            if not session:
                continue
            try:
                r = session.run_ps("Import-Module ActiveDirectory -ErrorAction Stop; 'OK'")
                out = (r.std_out or b"").decode("utf-8", errors="replace").strip()
                if r.status_code == 0 and "OK" in out:
                    self._session = session
                    self._active_server_label = server.get("label") or server.get("host", "")
                    h = (server.get("host") or "").strip()
                    pt = int(server.get("port_winrm") or (5986 if self._use_https() else 5985))
                    self._active_server_host = h
                    self._active_server_endpoint = f"{h}:{pt}"
                    self._last_error = ""
                    return True
                err = (r.std_err or b"").decode("utf-8", errors="replace").strip()
                self._last_error = err or f"WinRM status {r.status_code}"
            except Exception as e:  # noqa: BLE001
                self._last_error = str(e)
        self._session = None
        return False

    def disconnect(self) -> None:
        self._session = None
        self._active_server_endpoint = ""
        self._active_server_host = ""

    def reconnect(self) -> bool:
        self.disconnect()
        return self.connect()

    def test_connection(self) -> tuple[bool, str, float]:
        if self._mock_mode:
            return True, "Mock mode: no WinRM connection.", 0.0
        t0 = time.perf_counter()
        for server in self._dc_servers_normalized():
            session = self._open_session(server)
            if not session:
                continue
            try:
                r = session.run_ps(
                    "Import-Module ActiveDirectory -ErrorAction Stop; (Get-ADDomain).DNSRoot"
                )
                ms = (time.perf_counter() - t0) * 1000.0
                if r.status_code == 0:
                    dns = (r.std_out or b"").decode("utf-8", errors="replace").strip()
                    lbl = server.get("label") or server.get("host", "")
                    ph = server["host"]
                    pt = int(server.get("port_winrm") or (5986 if self._use_https() else 5985))
                    self._active_server_host = ph
                    self._active_server_endpoint = f"{ph}:{pt}"
                    self._active_server_label = lbl
                    return True, f"Connected: {dns} via {lbl}", ms
                err = (r.std_err or b"").decode("utf-8", errors="replace").strip()[:500]
                return False, err or f"status {r.status_code}", ms
            except Exception as e:  # noqa: BLE001
                ms = (time.perf_counter() - t0) * 1000.0
                return False, str(e), ms
        return False, self._last_error or "No DC responded.", (time.perf_counter() - t0) * 1000.0

    def _run_ps(self, script: str) -> tuple[bool, str]:
        if self._mock_mode:
            return False, "Not supported in mock_mode."
        if not self._session:
            return False, "Not connected."
        full = (
            "Import-Module ActiveDirectory -ErrorAction Stop\n"
            "Set-StrictMode -Off\n"
            "$ErrorActionPreference = 'Continue'\n"
            "$WarningPreference = 'SilentlyContinue'\n"
            f"{script}"
        )
        try:
            with self._ps_lock:
                r = self._session.run_ps(full)
            out = (r.std_out or b"").decode("utf-8", errors="replace").strip()
            err = (r.std_err or b"").decode("utf-8", errors="replace").strip()
            if r.status_code == 0:
                return True, out
            real_errors = [
                line
                for line in err.splitlines()
                if line.strip() and "WARNING" not in line.upper() and "VERBOSE" not in line.upper()
            ]
            filtered = "\n".join(real_errors).strip()
            self._last_error = filtered or err or out or f"code {r.status_code}"
            if out and (out.startswith("[") or out.startswith("{")):
                return True, out
            return False, self._last_error
        except Exception as e:  # noqa: BLE001
            self._last_error = str(e)
            return False, str(e)

    def _ps_to_json(self, script: str) -> tuple[bool, list | dict]:
        raw_script = script.strip()
        if "ConvertTo-Json" in raw_script:
            script_with_json = raw_script
        else:
            # Capture all produced objects first, then convert in a separate statement.
            script_with_json = (
                "$__codex_out = @(\n"
                f"{raw_script}\n"
                ")\n"
                "$__codex_out | ConvertTo-Json -Depth 4 -Compress"
            )

        ok, output = self._run_ps(script_with_json)
        if not ok:
            if "ConvertTo-Json" in raw_script:
                return False, []
            script_retry = (
                "$__codex_out = @(\n"
                f"{raw_script}\n"
                ")\n"
                "$__codex_out | ConvertTo-Json -Depth 4"
            )
            ok2, output2 = self._run_ps(script_retry)
            if not ok2:
                self._last_error = f"PS error: {str(output)[:300]}"
                return False, []
            output = output2

        if not output or not str(output).strip():
            return True, []

        raw = str(output).strip()
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                data = [data]
            return True, data if isinstance(data, list) else []
        except json.JSONDecodeError:
            pass

        for start_char, end_char in (("[", "]"), ("{", "}")):
            idx = raw.find(start_char)
            if idx == -1:
                continue
            depth = 0
            end_idx = -1
            in_string = False
            escape_next = False
            for i, ch in enumerate(raw[idx:], start=idx):
                if escape_next:
                    escape_next = False
                    continue
                if ch == "\\" and in_string:
                    escape_next = True
                    continue
                if ch == '"':
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == start_char:
                    depth += 1
                elif ch == end_char:
                    depth -= 1
                    if depth == 0:
                        end_idx = i + 1
                        break
            if end_idx != -1:
                json_str = raw[idx:end_idx]
                try:
                    data = json.loads(json_str)
                    if isinstance(data, dict):
                        data = [data]
                    return True, data if isinstance(data, list) else []
                except json.JSONDecodeError:
                    continue

        self._last_error = f"Could not extract JSON from output: {raw[:300]}"
        return False, []

    def _base(self, search_base: str | None) -> str:
        return search_base or self.cfg.get("base_dn") or ""

    def get_all_users(self, search_base: str | None = None) -> list[dict]:
        base = self._base(search_base)
        if self._mock_mode:
            return _mock_users(base, self.cfg.get("domain_name", "mock.local"))
        sb = f"-SearchBase '{_ps_sq(base)}'" if base else ""
        ps = r"""
$props = 'SamAccountName','GivenName','Surname','DisplayName','UserPrincipalName','Mail','TelephoneNumber','Title','Department','Company','Description','DistinguishedName','MemberOf','UserAccountControl','LastLogonTimestamp','WhenCreated','WhenChanged','ObjectGUID'
Get-ADUser -Filter * %s -Properties $props | ForEach-Object {
  [PSCustomObject]@{
    sAMAccountName = $_.SamAccountName
    givenName = $_.GivenName
    sn = $_.Surname
    displayName = $_.DisplayName
    userPrincipalName = $_.UserPrincipalName
    mail = $_.Mail
    telephoneNumber = $_.TelephoneNumber
    title = $_.Title
    department = $_.Department
    company = $_.Company
    description = $_.Description
    distinguishedName = $_.DistinguishedName
    memberOf = @($_.MemberOf)
    userAccountControl = [string]$_.UserAccountControl
    lastLogonTimestamp = if ($_.LastLogonTimestamp) { [string]$_.LastLogonTimestamp.ToFileTimeUtc() } else { '0' }
    whenCreated = if ($_.WhenCreated) { $_.WhenCreated.ToString('u') } else { '' }
    whenChanged = if ($_.WhenChanged) { $_.WhenChanged.ToString('u') } else { '' }
    objectGUID = $_.ObjectGUID.ToString()
  }
}
""" % (
            sb,
        )
        ok, data = self._ps_to_json(ps)
        if ok and not data and base:
            # Fallback for environments where provided SearchBase is not resolvable.
            ok, data = self._ps_to_json(ps.replace(sb, "").replace("  ", " "))
        if not ok:
            return []
        if isinstance(data, dict):
            data = [data]
        for u in data:
            if isinstance(u.get("memberOf"), str):
                u["memberOf"] = [x for x in u["memberOf"].split(";") if x]
            elif u.get("memberOf") is None:
                u["memberOf"] = []
        return data  # type: ignore[return-value]

    def get_user_by_sam(self, sam: str) -> dict:
        base = self._base(None)
        if self._mock_mode:
            for u in _mock_users(base, self.cfg.get("domain_name", "mock.local")):
                if str(u.get("sAMAccountName", "")).lower() == sam.lower():
                    return u
            return {}
        ps = r"""
Get-ADUser -Identity '%s' -Properties SamAccountName,GivenName,Surname,DisplayName,UserPrincipalName,Mail,TelephoneNumber,Title,Department,Company,Description,DistinguishedName,MemberOf,UserAccountControl,LastLogonTimestamp,WhenCreated,WhenChanged,ObjectGUID,Manager,Mobile,StreetAddress,City,State,PostalCode,Country,HomePage,ProfilePath,ScriptPath,LogonWorkstations,AccountExpirationDate -ErrorAction Stop |
ForEach-Object {
  [PSCustomObject]@{
    sAMAccountName = $_.SamAccountName
    givenName = $_.GivenName
    sn = $_.Surname
    displayName = $_.DisplayName
    userPrincipalName = $_.UserPrincipalName
    mail = $_.Mail
    telephoneNumber = $_.TelephoneNumber
    title = $_.Title
    department = $_.Department
    company = $_.Company
    description = $_.Description
    distinguishedName = $_.DistinguishedName
    memberOf = @($_.MemberOf)
    userAccountControl = [string]$_.UserAccountControl
    lastLogonTimestamp = if ($_.LastLogonTimestamp) { [string]$_.LastLogonTimestamp.ToFileTimeUtc() } else { '0' }
    whenCreated = if ($_.WhenCreated) { $_.WhenCreated.ToString('u') } else { '' }
    whenChanged = if ($_.WhenChanged) { $_.WhenChanged.ToString('u') } else { '' }
    objectGUID = $_.ObjectGUID.ToString()
    Manager = $_.Manager
    MobilePhone = $_.Mobile
    StreetAddress = $_.StreetAddress
    City = $_.City
    State = $_.State
    PostalCode = $_.PostalCode
    Country = $_.Country
    HomePage = $_.HomePage
    ProfilePath = $_.ProfilePath
    ScriptPath = $_.ScriptPath
    LogonWorkstations = $_.LogonWorkstations
    AccountExpirationDate = if ($_.AccountExpirationDate) { $_.AccountExpirationDate.ToString('u') } else { '' }
  }
}
""" % _ps_sq(
            sam
        )
        ok, data = self._ps_to_json(ps)
        if not ok or not data:
            return {}
        row = data[0] if isinstance(data, list) else data
        if isinstance(row, dict) and isinstance(row.get("memberOf"), str):
            row["memberOf"] = [x for x in row["memberOf"].split(";") if x]
        return row if isinstance(row, dict) else {}

    def create_user(self, user_data: dict, ou_dn: str, groups: list[str]) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK: user created in {ou_dn}"
        raw_sam = str(user_data.get("sAMAccountName", "")).strip()
        sam = _ps_sq(raw_sam)
        nm = _ps_sq(raw_sam or user_data.get("displayName", "user"))
        dn_disp = _ps_sq(user_data.get("displayName") or raw_sam or "user")
        upn_raw = (user_data.get("userPrincipalName") or "").strip() or f"{raw_sam}@{self.cfg.get('domain_name', 'local')}"
        upn = _ps_sq(upn_raw)
        gn = _ps_sq(user_data.get("givenName", ""))
        sn = _ps_sq(user_data.get("sn", ""))
        mail = _ps_sq(user_data.get("mail", ""))
        pwd = user_data.get("password") or ""
        pwd_q = _ps_sq(pwd)
        path = _ps_sq(ou_dn)
        must_change = "$true" if user_data.get("must_change_password") else "$false"
        enabled = "$false" if user_data.get("disabled") else "$true"
        pne = "$true" if user_data.get("password_never_expires") else "$false"
        lines = [
            f"$pw = ConvertTo-SecureString '{pwd_q}' -AsPlainText -Force",
            (
                f"New-ADUser -Name '{nm}' -SamAccountName '{sam}' -UserPrincipalName '{upn}' "
                f"-GivenName '{gn}' -Surname '{sn}' -DisplayName '{dn_disp}' -Path '{path}' "
                f"-AccountPassword $pw -ChangePasswordAtLogon {must_change} -Enabled {enabled} "
                f"-EmailAddress '{mail}' -PasswordNeverExpires {pne} -ErrorAction Stop"
            ),
        ]
        if user_data.get("title"):
            lines.append(f"Set-ADUser -Identity '{sam}' -Title '{_ps_sq(user_data['title'])}'")
        if user_data.get("department"):
            lines.append(f"Set-ADUser -Identity '{sam}' -Department '{_ps_sq(user_data['department'])}'")
        if user_data.get("company"):
            lines.append(f"Set-ADUser -Identity '{sam}' -Company '{_ps_sq(user_data['company'])}'")
        if user_data.get("description"):
            lines.append(f"Set-ADUser -Identity '{sam}' -Description '{_ps_sq(user_data['description'])}'")
        for gdn in groups:
            lines.append(f"Add-ADGroupMember -Identity '{_ps_sq(gdn)}' -Members '{sam}' -ErrorAction Stop")
        return self._run_ps("\n".join(lines))

    def modify_user(self, user_dn: str, changes: dict) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        ident = _ps_sq(user_dn)
        lines: list[str] = []
        set_params: list[str] = []
        mapping = {
            "givenName": "GivenName",
            "sn": "Surname",
            "displayName": "DisplayName",
            "mail": "EmailAddress",
            "telephoneNumber": "TelephoneNumber",
            "officePhone": "OfficePhone",
            "mobilePhone": "Mobile",
            "mobile": "Mobile",
            "title": "Title",
            "department": "Department",
            "company": "Company",
            "description": "Description",
            "userPrincipalName": "UserPrincipalName",
            "streetAddress": "StreetAddress",
            "city": "City",
            "state": "State",
            "postalCode": "PostalCode",
            "country": "Country",
            "homePage": "HomePage",
            "profilePath": "ProfilePath",
            "scriptPath": "ScriptPath",
            "logonWorkstations": "LogonWorkstations",
        }
        for k, ps_attr in mapping.items():
            if k in changes:
                set_params.append(f"-{ps_attr} '{_ps_sq(str(changes[k]))}'")
        if set_params:
            lines.append(f"Set-ADUser -Identity '{ident}' {' '.join(set_params)}")
        if "manager" in changes:
            mv = str(changes.get("manager") or "").strip()
            if mv:
                lines.append(f"Set-ADUser -Identity '{ident}' -Manager '{_ps_sq(mv)}'")
            else:
                lines.append(f"Set-ADUser -Identity '{ident}' -Manager $null")
        if "passwordNeverExpires" in changes:
            v = "$true" if changes["passwordNeverExpires"] else "$false"
            lines.append(f"Set-ADUser -Identity '{ident}' -PasswordNeverExpires {v}")
        if "smartcardLogonRequired" in changes:
            v = "$true" if changes["smartcardLogonRequired"] else "$false"
            lines.append(f"Set-ADUser -Identity '{ident}' -SmartcardLogonRequired {v}")
        if "accountExpirationDate" in changes:
            raw = str(changes.get("accountExpirationDate") or "").strip()
            if not raw:
                lines.append(f"Set-ADUser -Identity '{ident}' -AccountExpirationDate $null")
            else:
                lines.append(f"Set-ADUser -Identity '{ident}' -AccountExpirationDate (Get-Date '{_ps_sq(raw)}')")
        if "userAccountControl" in changes:
            uac = int(changes["userAccountControl"])
            lines.append(f"Set-ADUser -Identity '{ident}' -Replace @{{userAccountControl={uac}}}")
        if not lines:
            return True, "Nothing to change."
        return self._run_ps("\n".join(lines))

    def disable_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Disable-ADAccount -Identity '{_ps_sq(user_dn)}'")

    def enable_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Enable-ADAccount -Identity '{_ps_sq(user_dn)}'")

    def unlock_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Unlock-ADAccount -Identity '{_ps_sq(user_dn)}'")

    def delete_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Remove-ADUser -Identity '{_ps_sq(user_dn)}' -Confirm:$false")

    def reset_password(self, user_dn: str, new_password: str, *, must_change: bool = False) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        ident = _ps_sq(user_dn)
        pq = _ps_sq(new_password)
        mc = "$true" if must_change else "$false"
        ps = (
            f"$sec = ConvertTo-SecureString '{pq}' -AsPlainText -Force\n"
            f"Set-ADAccountPassword -Identity '{ident}' -Reset -NewPassword $sec\n"
            f"Set-ADUser -Identity '{ident}' -ChangePasswordAtLogon {mc}"
        )
        return self._run_ps(ps)

    def move_user(self, user_dn: str, target_ou_dn: str) -> tuple[bool, str]:
        return self.move_object(user_dn, target_ou_dn)

    def move_object(self, object_dn: str, target_ou_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(
            f"Move-ADObject -Identity '{_ps_sq(object_dn)}' -TargetPath '{_ps_sq(target_ou_dn)}'"
        )

    def create_ou(self, name: str, parent_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK OU {name}"
        return self._run_ps(
            f"New-ADOrganizationalUnit -Name '{_ps_sq(name)}' -Path '{_ps_sq(parent_dn)}' -ProtectedFromAccidentalDeletion $false"
        )

    def delete_group(self, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Remove-ADGroup -Identity '{_ps_sq(group_dn)}' -Confirm:$false")

    def create_group(
        self, name: str, ou_dn: str, scope: str, category: str, description: str = ""
    ) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK group {name}"
        nm = _ps_sq(name)
        return self._run_ps(
            f"New-ADGroup -Name '{nm}' -SamAccountName '{nm}' -GroupScope {_ps_sq(scope)} "
            f"-GroupCategory {_ps_sq(category)} -Path '{_ps_sq(ou_dn)}' -Description '{_ps_sq(description)}'"
        )

    def modify_group(self, group_identity: str, changes: dict) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        ident = _ps_sq(group_identity)
        parts: list[str] = []
        if "description" in changes:
            parts.append(f"-Description '{_ps_sq(str(changes['description']))}'")
        if "name" in changes and str(changes.get("name", "")).strip():
            parts.append(f"-Name '{_ps_sq(str(changes['name']).strip())}'")
        if "groupScope" in changes and str(changes.get("groupScope", "")).strip():
            parts.append(f"-GroupScope {_ps_sq(str(changes['groupScope']).strip())}")
        if "groupCategory" in changes and str(changes.get("groupCategory", "")).strip():
            parts.append(f"-GroupCategory {_ps_sq(str(changes['groupCategory']).strip())}")
        if not parts:
            return True, "Nothing to change."
        return self._run_ps(f"Set-ADGroup -Identity '{ident}' {' '.join(parts)}")

    def get_group_parent_groups(self, group_identity: str) -> list[dict]:
        """Groups this group is a member of (nested membership / memberOf)."""
        if self._mock_mode:
            return []
        ps = r"""
$g = Get-ADGroup -Identity '%s' -Properties MemberOf
$list = @()
if ($g.MemberOf) {
  foreach ($mo in @($g.MemberOf)) {
    $x = Get-ADGroup $mo -Properties Name,DistinguishedName,SamAccountName
    $list += [PSCustomObject]@{ Name = $x.Name; DistinguishedName = $x.DistinguishedName; SamAccountName = $x.SamAccountName }
  }
}
$list | ConvertTo-Json -Depth 4 -Compress
""" % _ps_sq(
            group_identity
        )
        ok, output = self._run_ps(ps.strip())
        if not ok:
            return []
        raw = (output or "").strip()
        if not raw:
            return []
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            return []
        if data is None:
            return []
        if isinstance(data, dict):
            data = [data]
        return data  # type: ignore[return-value]

    def get_all_groups(self) -> list[dict]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_groups(base)
        sb = f"-SearchBase '{_ps_sq(base)}'" if base else ""
        ps = r"""
Get-ADGroup -Filter * %s -Properties Name,SamAccountName,GroupCategory,GroupScope,Description,DistinguishedName,Member |
ForEach-Object {
  $mc = 0
  if ($_.Member) { $mc = @($_.Member).Count }
  [PSCustomObject]@{
    cn = $_.Name
    name = $_.Name
    samAccountName = $_.SamAccountName
    distinguishedName = $_.DistinguishedName
    groupType = [string][int]$_.GroupType
    groupCategory = [string]$_.GroupCategory
    groupScope = [string]$_.GroupScope
    description = $_.Description
    member_count = $mc
  }
}
""" % (
            sb,
        )
        ok, data = self._ps_to_json(ps)
        if ok and not data and base:
            ok, data = self._ps_to_json(ps.replace(sb, "").replace("  ", " "))
        if not ok:
            return []
        if isinstance(data, dict):
            data = [data]
        return data  # type: ignore[return-value]

    def get_group_members(self, group_dn: str, *, recursive: bool = False) -> list[dict]:
        if self._mock_mode:
            return _mock_users(self._base(None), self.cfg.get("domain_name", "mock.local"))
        rec = " -Recursive" if recursive else ""
        ps = r"""
Get-ADGroupMember -Identity '%s'%s |
ForEach-Object {
  [PSCustomObject]@{
    cn = $_.Name
    sAMAccountName = $_.SamAccountName
    distinguishedName = $_.DistinguishedName
    objectClass = @($_.objectClass)
  }
}
""" % (
            _ps_sq(group_dn),
            rec,
        )
        ok, data = self._ps_to_json(ps)
        if not ok:
            return []
        if isinstance(data, dict):
            data = [data]
        out: list[dict] = []
        for m in data:
            ocs = m.get("objectClass") or []
            if isinstance(ocs, str):
                ocs = [ocs]
            out.append(
                {
                    "cn": m.get("cn", ""),
                    "sAMAccountName": m.get("sAMAccountName", ""),
                    "distinguishedName": m.get("distinguishedName", ""),
                    "objectClass": [str(x) for x in ocs],
                }
            )
        return out

    def add_user_to_group(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(
            f"Add-ADGroupMember -Identity '{_ps_sq(group_dn)}' -Members '{_ps_sq(user_dn)}'"
        )

    def remove_user_from_group(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(
            f"Remove-ADGroupMember -Identity '{_ps_sq(group_dn)}' -Members '{_ps_sq(user_dn)}' -Confirm:$false"
        )

    def get_ou_children_objects(self, ou_dn: str) -> list[dict]:
        if self._mock_mode:
            base = self._base(None)
            out: list[dict] = []
            needle = ou_dn.upper()
            for u in _mock_users(base, self.cfg.get("domain_name", "mock.local")):
                dn = (u.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": u["distinguishedName"], "name": u.get("displayName") or u.get("sAMAccountName"), "kind": "user"})
            for c in _mock_computers(base):
                dn = (c.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": c["distinguishedName"], "name": c.get("name"), "kind": "computer"})
            for g in _mock_groups(base):
                dn = (g.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": g["distinguishedName"], "name": g.get("name"), "kind": "group"})
            return out
        ps = r"""
Get-ADObject -SearchBase '%s' -SearchScope OneLevel -LDAPFilter '(|(objectClass=user)(objectClass=computer)(objectClass=group))' |
ForEach-Object {
  $kind = 'object'
  if ($_.ObjectClass -contains 'user' -and $_.ObjectClass -contains 'person') { $kind = 'user' }
  elseif ($_.ObjectClass -contains 'computer') { $kind = 'computer' }
  elseif ($_.ObjectClass -contains 'group') { $kind = 'group' }
  [PSCustomObject]@{ dn = $_.DistinguishedName; name = $_.Name; kind = $kind }
}
""" % _ps_sq(
            ou_dn
        )
        ok, data = self._ps_to_json(ps)
        if not ok:
            return []
        if isinstance(data, dict):
            data = [data]
        return data  # type: ignore[return-value]

    def get_ou_tree(self) -> list[dict]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_ou_tree(base)
        sb = f"-SearchBase '{_ps_sq(base)}'" if base else ""
        ps = (
            f"Get-ADOrganizationalUnit -Filter * {sb} "
            "-Properties DistinguishedName | Select-Object -ExpandProperty DistinguishedName | ConvertTo-Json -Compress"
        )
        ok, data = self._run_ps(ps + "\n")
        if ok and (not data or not str(data).strip()) and base:
            ps2 = (
                "Get-ADOrganizationalUnit -Filter * "
                "-Properties DistinguishedName | Select-Object -ExpandProperty DistinguishedName | ConvertTo-Json -Compress"
            )
            ok, data = self._run_ps(ps2 + "\n")
        if not ok:
            return []
        raw = (data or "").strip()
        if not raw:
            return build_ou_hierarchy([], base)
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return build_ou_hierarchy([], base)
        if isinstance(parsed, str):
            dns = [parsed] if parsed else []
        elif isinstance(parsed, list):
            dns = [str(x) for x in parsed]
        else:
            dns = []
        return build_ou_hierarchy(dns, base)

    def get_computers(self) -> list[dict]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_computers(base)
        sb = f"-SearchBase '{_ps_sq(base)}'" if base else ""
        ps = r"""
Get-ADComputer -Filter * %s -Properties Name,DistinguishedName,OperatingSystem,LastLogonTimestamp,WhenChanged |
ForEach-Object {
  [PSCustomObject]@{
    name = $_.Name
    distinguishedName = $_.DistinguishedName
    operatingSystem = $_.OperatingSystem
    lastLogonTimestamp = if ($_.LastLogonTimestamp) { [string]$_.LastLogonTimestamp.ToFileTimeUtc() } else { '0' }
    whenChanged = if ($_.WhenChanged) { $_.WhenChanged.ToString('u') } else { '' }
  }
}
""" % (
            sb,
        )
        ok, data = self._ps_to_json(ps)
        if ok and not data and base:
            ok, data = self._ps_to_json(ps.replace(sb, "").replace("  ", " "))
        if not ok:
            return []
        if isinstance(data, dict):
            data = [data]
        return data  # type: ignore[return-value]

    def get_computer_by_name(self, name: str) -> dict:
        if self._mock_mode:
            for c in _mock_computers(self._base(None)):
                if str(c.get("name", "")).lower() == str(name).lower():
                    return c
            return {}
        ps = r"""
Get-ADComputer -Identity '%s' -Properties * |
Select-Object Name, DNSHostName, DistinguishedName, Enabled,
    OperatingSystem, OperatingSystemVersion, OperatingSystemServicePack,
    IPv4Address, LastLogonDate, Created, Modified, Description,
    ManagedBy, Location, ObjectGUID,
    @{N='OUPath';E={$_.DistinguishedName -replace '^CN=[^,]+,',''}},
    @{N='MemberOf';E={($_.MemberOf | ForEach-Object {(Get-ADGroup $_ -Properties Name).Name }) -join ';'}}
""" % _ps_sq(
            name
        )
        ok, data = self._ps_to_json(ps)
        return data[0] if ok and data else {}  # type: ignore[index]

    def modify_computer(self, name: str, changes: dict) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        set_params: list[str] = []
        simple_map = {
            "description": "Description",
            "location": "Location",
            "managedBy": "ManagedBy",
            "dnsHostName": "DNSHostName",
        }
        for key, ps_attr in simple_map.items():
            if key in changes:
                val = _ps_sq(str(changes[key]))
                set_params.append(f"-{ps_attr} '{val}'")

        if "enabled" in changes:
            val = "$true" if changes["enabled"] else "$false"
            set_params.append(f"-Enabled {val}")

        if not set_params:
            return True, "Nothing to change"

        cmd = f"Set-ADComputer -Identity '{_ps_sq(name)}' {' '.join(set_params)}"
        return self._run_ps(cmd)

    def enable_computer(self, name: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Enable-ADAccount -Identity '{_ps_sq(name)}$'")

    def disable_computer(self, name: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Disable-ADAccount -Identity '{_ps_sq(name)}$'")

    def delete_computer(self, name: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Remove-ADComputer -Identity '{_ps_sq(name)}' -Confirm:$false")

    def move_computer(self, name: str, target_ou_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        script = (
            f"$comp = Get-ADComputer -Identity '{_ps_sq(name)}'\n"
            f"Move-ADObject -Identity $comp.DistinguishedName -TargetPath '{_ps_sq(target_ou_dn)}'"
        )
        return self._run_ps(script)

    def get_computer_groups(self, name: str) -> list:
        if self._mock_mode:
            return []
        script = r"""
$comp = Get-ADComputer -Identity '%s' -Properties MemberOf
$comp.MemberOf | ForEach-Object {
    Get-ADGroup $_ -Properties Name, GroupScope, GroupCategory,
        Description, DistinguishedName |
    Select-Object Name, GroupScope, GroupCategory,
        Description, DistinguishedName, SamAccountName
}
""" % _ps_sq(
            name
        )
        ok, data = self._ps_to_json(script)
        return data if ok else []

    def add_computer_to_group(self, name: str, group_sam: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(f"Add-ADGroupMember -Identity '{_ps_sq(group_sam)}' -Members '{_ps_sq(name)}$'")

    def remove_computer_from_group(self, name: str, group_sam: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        return self._run_ps(
            f"Remove-ADGroupMember -Identity '{_ps_sq(group_sam)}' -Members '{_ps_sq(name)}$' -Confirm:$false"
        )

    def get_all_attributes(self, object_dn: str) -> dict[str, Any]:
        if self._mock_mode:
            return {}
        ps = r"""
Get-ADObject -Identity '%s' -Properties * | Select-Object *
""" % _ps_sq(
            object_dn
        )
        ok, data = self._ps_to_json(ps)
        if not ok or not data:
            return {}
        row = data[0] if isinstance(data, list) else data
        return row if isinstance(row, dict) else {}
