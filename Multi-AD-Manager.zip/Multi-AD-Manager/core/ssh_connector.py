"""SSH: LDAP over local forward port, or remote PowerShell via SSH (OpenSSH on Windows DC)."""

from __future__ import annotations

import base64
import copy
import socket
import threading
import time
from types import SimpleNamespace
from typing import Any

from core.connector_errors import format_ssh_error
from core.ldap_connector import LDAPConnector
from core.winrm_connector import WinRMConnector

try:
    import paramiko
except ImportError:
    paramiko = None  # type: ignore[misc, assignment]


def _forward_loop(client_sock: socket.socket, chan: Any) -> None:
    try:
        while True:
            data = client_sock.recv(32768)
            if not data:
                break
            chan.sendall(data)
            data = chan.recv(32768)
            if not data:
                break
            client_sock.sendall(data)
    except Exception:
        pass
    finally:
        try:
            client_sock.close()
        except Exception:
            pass
        try:
            chan.close()
        except Exception:
            pass


class SSHLDAPConnector:
    """SSH port-forward to DC LDAP; delegates directory ops to LDAPConnector on localhost."""

    def __init__(self, domain_config: dict[str, Any]) -> None:
        self.cfg = copy.deepcopy(domain_config)
        self._ssh: Any = None
        self._transport: Any = None
        self._tunnel_thread: threading.Thread | None = None
        self._server_sock: socket.socket | None = None
        self._stop = threading.Event()
        self._ldap: LDAPConnector | None = None
        self._last_error = ""
        self._active_server_label = ""
        self._active_server_endpoint = ""

    @property
    def is_connected(self) -> bool:
        return self._ldap is not None and self._ldap.is_connected

    @property
    def last_error(self) -> str:
        if self._last_error:
            return self._last_error
        if self._ldap:
            return self._ldap.last_error
        return ""

    def _ssh_password(self) -> str:
        sh = self.cfg.get("ssh") or {}
        return str(sh.get("_password_plain", "") or self.cfg.get("_ssh_password_plain", "")).strip()

    def connect(self) -> bool:
        self.disconnect()
        if self.cfg.get("mock_mode"):
            self._last_error = ""
            return True
        if paramiko is None:
            self._last_error = "paramiko is not installed."
            return False
        sh = self.cfg.get("ssh") or {}
        host = (sh.get("host") or "").strip()
        if not host:
            self._last_error = "SSH host is missing."
            return False
        port = int(sh.get("port", 22))
        user = (sh.get("user") or "").strip()
        pwd = self._ssh_password()
        key_path = (sh.get("private_key_path") or "").strip()
        if not user or (not pwd and not key_path):
            self._last_error = "SSH user and password or private key path required."
            return False
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            kwargs: dict[str, Any] = {
                "hostname": host,
                "port": port,
                "username": user,
                "timeout": 15,
                "banner_timeout": 20,
            }
            if key_path:
                kwargs["key_filename"] = key_path
            else:
                kwargs["password"] = pwd
            client.connect(**kwargs)
            self._ssh = client
            self._transport = client.get_transport()
            if not self._transport:
                self._last_error = "SSH transport unavailable."
                return False
        except Exception as e:  # noqa: BLE001
            self._last_error = format_ssh_error(e)
            return False

        local_port = int(sh.get("tunnel_local_port", 13890))
        remote_host = str(sh.get("tunnel_remote_host", "127.0.0.1"))
        remote_port = int(sh.get("tunnel_remote_port", 389))
        self._stop.clear()

        def tunnel_worker() -> None:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                srv.bind(("127.0.0.1", local_port))
                srv.listen(8)
                srv.settimeout(0.4)
            except Exception as e:  # noqa: BLE001
                self._last_error = str(e)
                return
            self._server_sock = srv
            while not self._stop.is_set():
                try:
                    csock, _ = srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                try:
                    chan = self._transport.open_channel("direct-tcpip", (remote_host, remote_port), ("127.0.0.1", local_port))
                except Exception:
                    try:
                        csock.close()
                    except Exception:
                        pass
                    continue
                threading.Thread(target=_forward_loop, args=(csock, chan), daemon=True).start()

        self._tunnel_thread = threading.Thread(target=tunnel_worker, daemon=True)
        self._tunnel_thread.start()
        time.sleep(0.6)

        tunnel_cfg = copy.deepcopy(self.cfg)
        tunnel_cfg["transport"] = "ldap"
        ldap_part = copy.deepcopy(self.cfg.get("ldap") or {})
        ldap_part["servers"] = [{"host": "127.0.0.1", "port": local_port, "label": "SSH-tunnel"}]
        ldap_part["_password_plain"] = str(ldap_part.get("_password_plain", "") or self.cfg.get("_ldap_password_plain", ""))
        tunnel_cfg["ldap"] = ldap_part

        self._ldap = LDAPConnector(tunnel_cfg)
        if self._ldap.connect():
            self._active_server_label = f"SSH→{host}:{port}"
            self._active_server_endpoint = f"{host}:{port}→127.0.0.1:{local_port}"
            self._last_error = ""
            return True
        self._last_error = self._ldap.last_error or "LDAP via SSH tunnel failed."
        self._cleanup_ssh()
        return False

    def _cleanup_ssh(self) -> None:
        self._stop.set()
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
        self._server_sock = None
        if self._ssh:
            try:
                self._ssh.close()
            except Exception:
                pass
        self._ssh = None
        self._transport = None

    def disconnect(self) -> None:
        if self._ldap:
            try:
                self._ldap.disconnect()
            except Exception:
                pass
        self._ldap = None
        self._cleanup_ssh()
        self._active_server_endpoint = ""

    def reconnect(self) -> bool:
        self.disconnect()
        return self.connect()

    def test_connection(self) -> tuple[bool, str, float]:
        t0 = time.perf_counter()
        if self.cfg.get("mock_mode"):
            return True, "Mock mode: no SSH connection.", 0.0
        ok = self.connect()
        ms = (time.perf_counter() - t0) * 1000.0
        if ok:
            msg = f"SSH tunnel established ({self.cfg.get('transport', 'ssh_ldap_tunnel')})"
            self.disconnect()
            return True, msg, ms
        self.disconnect()
        return False, self._last_error, ms

    def __getattr__(self, name: str) -> Any:
        if self._ldap is None:
            raise AttributeError(name)
        return getattr(self._ldap, name)


class _SshPsSessionAdapter:
    def __init__(self, ssh_client: Any) -> None:
        self._ssh = ssh_client

    def run_ps(self, script: str) -> Any:
        enc = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        cmd = f"powershell.exe -NoProfile -NonInteractive -EncodedCommand {enc}"
        _stdin, stdout, stderr = self._ssh.exec_command(cmd, timeout=120)
        rc = stdout.channel.recv_exit_status()
        out_b = stdout.read() or b""
        err_b = stderr.read() or b""
        return SimpleNamespace(status_code=rc, std_out=out_b, std_err=err_b)


class SSHPowerShellConnector(WinRMConnector):
    """Run the same AD PowerShell scripts as WinRM, but over SSH to the DC/bastion."""

    def __init__(self, domain_config: dict[str, Any]) -> None:
        super().__init__(domain_config)
        self._ssh_client: Any = None

    def connect(self) -> bool:
        if self._mock_mode:
            self._last_error = ""
            return True
        if paramiko is None:
            self._last_error = "paramiko is not installed."
            return False
        sh = self.cfg.get("ssh") or {}
        host = (sh.get("host") or "").strip()
        port = int(sh.get("port", 22))
        user = (sh.get("user") or "").strip()
        pwd = str(sh.get("_password_plain", "") or self.cfg.get("_ssh_password_plain", "")).strip()
        key_path = (sh.get("private_key_path") or "").strip()
        if not host or not user or (not pwd and not key_path):
            self._last_error = "SSH host, user, and password or key required."
            return False
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            kw: dict[str, Any] = {"hostname": host, "port": port, "username": user, "timeout": 20}
            if key_path:
                kw["key_filename"] = key_path
            else:
                kw["password"] = pwd
            client.connect(**kw)
            self._ssh_client = client
            self._session = _SshPsSessionAdapter(client)
            self._active_server_label = f"SSH-PS {host}"
            self._active_server_host = host
            self._active_server_endpoint = f"{host}:{port}"
            self._last_error = ""
            return True
        except Exception as e:  # noqa: BLE001
            self._last_error = format_ssh_error(e)
            self._session = None
            return False

    def disconnect(self) -> None:
        if self._ssh_client:
            try:
                self._ssh_client.close()
            except Exception:
                pass
        self._ssh_client = None
        self._session = None
        self._active_server_endpoint = ""

    def test_connection(self) -> tuple[bool, str, float]:
        if self._mock_mode:
            return True, "Mock mode: no SSH connection.", 0.0
        t0 = time.perf_counter()
        ok = self.connect()
        ms = (time.perf_counter() - t0) * 1000.0
        if ok:
            r = self._session.run_ps("Import-Module ActiveDirectory -ErrorAction Stop; 'OK'")
            ok2 = r.status_code == 0 and b"OK" in (r.std_out or b"")
            err = (r.std_err or b"").decode("utf-8", errors="replace").strip()
            self.disconnect()
            if ok2:
                return True, "SSH PowerShell session OK", ms
            return False, err or "PowerShell check failed.", ms
        return False, self._last_error, ms
