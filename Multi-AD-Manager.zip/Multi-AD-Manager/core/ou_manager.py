"""Organizational unit tree helpers."""

from __future__ import annotations

from typing import Any


class OUManager:
    def __init__(self, connector: Any) -> None:
        self.c = connector

    def tree(self):
        return self.c.get_ou_tree()
