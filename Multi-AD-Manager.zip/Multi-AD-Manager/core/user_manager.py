"""High-level user operations with optional audit hooks."""

from __future__ import annotations

from typing import Any, Callable


class UserManager:
    def __init__(self, connector: Any, audit: Callable[..., None] | None = None) -> None:
        self.c = connector
        self._audit = audit

    def list_users(self, base: str | None = None):
        return self.c.get_all_users(base)

    def get(self, sam: str):
        return self.c.get_user_by_sam(sam)

    def modify(self, user_dn: str, changes: dict) -> tuple[bool, str]:
        ok, msg = self.c.modify_user(user_dn, changes)
        if self._audit:
            self._audit(operation="modify_user", target=user_dn, success=ok, error=None if ok else msg, params=changes)
        return ok, msg

    def disable(self, user_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.disable_user(user_dn)
        if self._audit:
            self._audit(operation="disable_user", target=user_dn, success=ok, error=None if ok else msg, params={})
        return ok, msg

    def enable(self, user_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.enable_user(user_dn)
        if self._audit:
            self._audit(operation="enable_user", target=user_dn, success=ok, error=None if ok else msg, params={})
        return ok, msg

    def unlock(self, user_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.unlock_user(user_dn)
        if self._audit:
            self._audit(operation="unlock_user", target=user_dn, success=ok, error=None if ok else msg, params={})
        return ok, msg

    def reset_password(self, user_dn: str, new_password: str, *, must_change: bool = False) -> tuple[bool, str]:
        ok, msg = self.c.reset_password(user_dn, new_password, must_change=must_change)
        if self._audit:
            self._audit(
                operation="reset_password",
                target=user_dn,
                success=ok,
                error=None if ok else msg,
                params={"password_set": True, "must_change": must_change},
            )
        return ok, msg

    def move(self, user_dn: str, target_ou: str) -> tuple[bool, str]:
        ok, msg = self.c.move_user(user_dn, target_ou)
        if self._audit:
            self._audit(
                operation="move_user",
                target=user_dn,
                success=ok,
                error=None if ok else msg,
                params={"target_ou": target_ou},
            )
        return ok, msg

    def create(self, user_data: dict, ou_dn: str, groups: list[str]) -> tuple[bool, str]:
        ok, msg = self.c.create_user(user_data, ou_dn, groups)
        if self._audit:
            self._audit(
                operation="create_user",
                target=msg if ok else ou_dn,
                success=ok,
                error=None if ok else msg,
                params={"sam": user_data.get("sAMAccountName")},
            )
        return ok, msg

    def delete(self, user_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.delete_user(user_dn)
        if self._audit:
            self._audit(operation="delete_user", target=user_dn, success=ok, error=None if ok else msg, params={})
        return ok, msg
