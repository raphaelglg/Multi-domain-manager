"""LDAP (ldap3) connector — same public surface as WinRMConnector where used by the UI."""

from __future__ import annotations

import copy
import ssl
import uuid
from typing import Any

from core.ad_constants import (
    UAC_ACCOUNTDISABLE,
    UAC_DONT_EXPIRE_PASSWD,
    UAC_NORMAL_ACCOUNT,
    UAC_PASSWD_NOTREQD,
    UAC_SMARTCARD_REQUIRED,
)
from core.ad_tree import build_ou_hierarchy
from core.connector_errors import format_ldap_error
from core.domain_config import ldap_effective_ssl_flags
from core.winrm_connector import _mock_computers, _mock_groups, _mock_ou_tree, _mock_users

try:
    from ldap3 import ALL, MODIFY_ADD, MODIFY_DELETE, MODIFY_REPLACE, NTLM, SIMPLE, SUBTREE, Connection, Server, Tls
    from ldap3.core.exceptions import LDAPException
    from ldap3.utils.conv import escape_filter_chars
except ImportError:
    Connection = None  # type: ignore[misc, assignment]
    Server = None
    LDAPException = Exception  # type: ignore[misc, assignment]
    escape_filter_chars = lambda x: x  # type: ignore[assignment]


class LDAPConnector:
    """Bind to AD LDAP/LDAPS and perform directory operations."""

    def __init__(self, domain_config: dict[str, Any]) -> None:
        self.cfg = copy.deepcopy(domain_config)
        self._conn: Any = None
        self._last_error = ""
        self._mock_mode = bool(self.cfg.get("mock_mode"))
        self._active_server_label = ""
        self._active_server_endpoint = ""
        self._active_server_host = ""

    @property
    def is_connected(self) -> bool:
        if self._mock_mode:
            return True
        return self._conn is not None and bool(self._conn.bound)

    @property
    def last_error(self) -> str:
        return self._last_error

    def _ldap_password(self) -> str:
        ldap = self.cfg.get("ldap") or {}
        return (
            str(ldap.get("_password_plain", "")).strip()
            or str(self.cfg.get("_ldap_password_plain", "")).strip()
            or str(self.cfg.get("_bind_password_plain", "")).strip()
        )

    def _bind_user(self) -> str:
        ldap = self.cfg.get("ldap") or {}
        return (ldap.get("bind_user") or self.cfg.get("bind_user") or "").strip()

    def _servers(self) -> list[dict[str, Any]]:
        ldap = self.cfg.get("ldap") or {}
        return list(ldap.get("servers") or [])

    def _auth(self) -> Any:
        u = self._bind_user()
        if "\\" in u:
            return NTLM
        return SIMPLE

    def connect(self) -> bool:
        if self._mock_mode:
            self._last_error = ""
            return True
        if Connection is None:
            self._last_error = "ldap3 is not installed."
            return False
        user = self._bind_user()
        pwd = self._ldap_password()
        if not user or not pwd:
            self._last_error = "LDAP bind user or password missing."
            return False
        use_ssl, use_start_tls = ldap_effective_ssl_flags(self.cfg)
        ldap = self.cfg.get("ldap") or {}
        validate = bool(ldap.get("validate_ssl", self.cfg.get("validate_ssl", False)))
        self.disconnect()
        for s in self._servers():
            host = (s.get("host") or "").strip()
            if not host:
                continue
            port = int(s.get("port") or (636 if use_ssl else 389))
            try:
                tls = None
                if use_ssl or use_start_tls:
                    tls = Tls(
                        validate=ssl.CERT_REQUIRED if validate else ssl.CERT_NONE,
                    )
                server = Server(
                    host,
                    port=port,
                    use_ssl=use_ssl,
                    tls=tls,
                    get_info=ALL,
                    connect_timeout=int(self.cfg.get("connection_timeout_sec", 15)),
                )
                conn = Connection(
                    server,
                    user=user,
                    password=pwd,
                    authentication=self._auth(),
                    auto_bind=False,
                    receive_timeout=max(30, int(self.cfg.get("connection_timeout_sec", 30))),
                )
                conn.open()
                if use_start_tls:
                    conn.start_tls()
                if not conn.bind():
                    self._last_error = str(conn.result)
                    continue
                self._conn = conn
                self._active_server_label = (s.get("label") or host).strip()
                self._active_server_host = host
                self._active_server_endpoint = f"{host}:{port}"
                self._last_error = ""
                return True
            except LDAPException as e:  # type: ignore[misc]
                self._last_error = format_ldap_error(e)
            except Exception as e:  # noqa: BLE001
                self._last_error = format_ldap_error(e)
        self._conn = None
        return False

    def disconnect(self) -> None:
        if self._conn:
            try:
                self._conn.unbind()
            except Exception:
                pass
        self._conn = None
        self._active_server_endpoint = ""
        self._active_server_host = ""

    def reconnect(self) -> bool:
        self.disconnect()
        return self.connect()

    def test_connection(self) -> tuple[bool, str, float]:
        import time

        if self._mock_mode:
            return True, "Mock mode: no LDAP connection.", 0.0
        t0 = time.perf_counter()
        ok = self.connect()
        ms = (time.perf_counter() - t0) * 1000.0
        if ok and self._conn:
            try:
                dns = str(self._conn.server.name) if self._conn.server else "connected"
            except Exception:
                dns = "connected"
            self.disconnect()
            return True, f"Connected: {dns}", ms
        self.disconnect()
        return False, self._last_error or "LDAP connection failed.", ms

    def _search(
        self,
        search_filter: str,
        attributes: list[str],
        search_base: str | None = None,
        *,
        scope=SUBTREE,
        paged_size: int = 1000,
    ) -> list[dict[str, Any]]:
        if self._mock_mode or not self._conn:
            return []
        base = search_base or self.cfg.get("base_dn") or ""
        try:
            skw: dict[str, Any] = {}
            if paged_size and paged_size > 0:
                skw["paged_size"] = paged_size
            self._conn.search(
                search_base=base,
                search_filter=search_filter,
                search_scope=scope,
                attributes=attributes,
                **skw,
            )
            rows: list[dict[str, Any]] = []
            for entry in self._conn.entries:
                row: dict[str, Any] = {}
                for attr in attributes:
                    if attr == "*":
                        for a in entry.entry_attributes:
                            row[a] = self._attr_val(entry, a)
                        continue
                    row[attr] = self._attr_val(entry, attr)
                rows.append(row)
            return rows
        except LDAPException as e:  # type: ignore[misc]
            self._last_error = format_ldap_error(e)
            return []

    def _attr_val(self, entry: Any, attr: str) -> Any:
        try:
            v = entry[attr].value
        except Exception:
            return "" if attr != "memberOf" else []
        if attr.lower() == "memberof" and v is None:
            return []
        if isinstance(v, list):
            if attr.lower() in ("memberof", "member"):
                return [str(x) for x in v]
            if len(v) == 1:
                return str(v[0])
            return ";".join(str(x) for x in v)
        return "" if v is None else str(v)

    def get_all_users(self, search_base: str | None = None) -> list[dict[str, Any]]:
        base = self._base(search_base)
        if self._mock_mode:
            return _mock_users(base, self.cfg.get("domain_name", "mock.local"))
        attrs = [
            "sAMAccountName",
            "givenName",
            "sn",
            "displayName",
            "userPrincipalName",
            "mail",
            "telephoneNumber",
            "title",
            "department",
            "company",
            "description",
            "distinguishedName",
            "memberOf",
            "userAccountControl",
            "lastLogonTimestamp",
            "whenCreated",
            "whenChanged",
            "objectGUID",
        ]
        flt = "(&(objectCategory=person)(objectClass=user))"
        rows = self._search(flt, attrs, base)
        for u in rows:
            if isinstance(u.get("memberOf"), str) and u["memberOf"]:
                u["memberOf"] = [x for x in str(u["memberOf"]).split(";") if x]
            elif u.get("memberOf") in (None, ""):
                u["memberOf"] = []
            try:
                uac = int(str(u.get("userAccountControl", 0) or 0))
            except ValueError:
                uac = 0
            u["userAccountControl"] = str(uac)
        return rows

    def get_user_by_sam(self, sam: str) -> dict[str, Any]:
        base = self._base(None)
        if self._mock_mode:
            for u in _mock_users(base, self.cfg.get("domain_name", "mock.local")):
                if str(u.get("sAMAccountName", "")).lower() == sam.lower():
                    return u
            return {}
        e = escape_filter_chars(sam)
        flt = f"(&(objectCategory=person)(objectClass=user)(sAMAccountName={e}))"
        attrs = [
            "sAMAccountName",
            "givenName",
            "sn",
            "displayName",
            "userPrincipalName",
            "mail",
            "telephoneNumber",
            "title",
            "department",
            "company",
            "description",
            "distinguishedName",
            "memberOf",
            "userAccountControl",
            "lastLogonTimestamp",
            "whenCreated",
            "whenChanged",
            "objectGUID",
            "manager",
            "mobile",
            "streetAddress",
            "l",
            "st",
            "postalCode",
            "co",
            "wWWHomePage",
            "profilePath",
            "scriptPath",
            "userWorkstations",
            "accountExpires",
        ]
        rows = self._search(flt, attrs, base)
        if not rows:
            return {}
        u = rows[0]
        if isinstance(u.get("memberOf"), str) and u["memberOf"]:
            u["memberOf"] = [x for x in str(u["memberOf"]).split(";") if x]
        elif not isinstance(u.get("memberOf"), list):
            u["memberOf"] = []
        u["Manager"] = u.get("manager", "")
        u["MobilePhone"] = u.get("mobile", "")
        u["StreetAddress"] = u.get("streetAddress", "")
        u["City"] = u.get("l", "")
        u["State"] = u.get("st", "")
        u["PostalCode"] = u.get("postalCode", "")
        u["Country"] = u.get("co", "")
        u["HomePage"] = u.get("wWWHomePage", "")
        u["ProfilePath"] = u.get("profilePath", "")
        u["ScriptPath"] = u.get("scriptPath", "")
        u["LogonWorkstations"] = u.get("userWorkstations", "")
        u["AccountExpirationDate"] = u.get("accountExpires", "")
        return u

    def _base(self, search_base: str | None) -> str:
        return (search_base or self.cfg.get("base_dn") or "").strip()

    def create_user(self, user_data: dict[str, Any], ou_dn: str, groups: list[str]) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK: user created in {ou_dn}"
        if not self._conn:
            return False, "Not connected."
        raw_sam = str(user_data.get("sAMAccountName", "")).strip()
        disp = str(user_data.get("displayName") or raw_sam or "user").strip()
        dn = f"CN={disp},{ou_dn}"
        upn = (user_data.get("userPrincipalName") or "").strip() or f"{raw_sam}@{self.cfg.get('domain_name', 'local')}"
        attrs: dict[str, list[Any]] = {
            "objectClass": ["top", "person", "organizationalPerson", "user"],
            "sAMAccountName": [raw_sam],
            "userPrincipalName": [upn],
            "givenName": [str(user_data.get("givenName", ""))],
            "sn": [str(user_data.get("sn", ""))],
            "displayName": [disp],
        }
        if user_data.get("mail"):
            attrs["mail"] = [str(user_data["mail"])]
        for k, ad in (
            ("title", "title"),
            ("department", "department"),
            ("company", "company"),
            ("description", "description"),
        ):
            if user_data.get(k):
                attrs[ad] = [str(user_data[k])]
        # Disabled + password-not-required until unicodePwd is set (common LDAP pattern).
        uac = UAC_NORMAL_ACCOUNT | UAC_ACCOUNTDISABLE | UAC_PASSWD_NOTREQD
        if user_data.get("password_never_expires"):
            uac |= UAC_DONT_EXPIRE_PASSWD
        attrs["userAccountControl"] = [str(uac)]
        try:
            if not self._conn.add(dn, attributes=attrs):
                return False, str(self._conn.result)
            pwd = str(user_data.get("password") or "")
            if pwd:
                pw_enc = ('"' + pwd + '"').encode("utf-16-le")
                if not self._conn.modify(dn, {"unicodePwd": [(MODIFY_REPLACE, [pw_enc])]}):
                    return False, format_ldap_error(Exception(self._conn.result))
            final_uac = UAC_NORMAL_ACCOUNT
            if user_data.get("disabled"):
                final_uac |= UAC_ACCOUNTDISABLE
            if user_data.get("password_never_expires"):
                final_uac |= UAC_DONT_EXPIRE_PASSWD
            if not self._conn.modify(dn, {"userAccountControl": [(MODIFY_REPLACE, [str(final_uac)])]}):
                return False, str(self._conn.result)
            for gdn in groups:
                if not self._conn.modify(gdn, {"member": [(MODIFY_ADD, [dn])]}):
                    return False, str(self._conn.result)
            return True, dn
        except LDAPException as e:  # type: ignore[misc]
            return False, format_ldap_error(e)
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def modify_user(self, user_dn: str, changes: dict[str, Any]) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        mapping = {
            "givenName": "givenName",
            "sn": "sn",
            "displayName": "displayName",
            "mail": "mail",
            "telephoneNumber": "telephoneNumber",
            "title": "title",
            "department": "department",
            "company": "company",
            "description": "description",
            "userPrincipalName": "userPrincipalName",
            "streetAddress": "streetAddress",
            "city": "l",
            "state": "st",
            "postalCode": "postalCode",
            "country": "co",
            "homePage": "wWWHomePage",
            "profilePath": "profilePath",
            "scriptPath": "scriptPath",
            "logonWorkstations": "userWorkstations",
        }
        mods: dict[str, list[tuple[int, list[str]]]] = {}
        for k, ad in mapping.items():
            if k in changes:
                mods[ad] = [(MODIFY_REPLACE, [str(changes[k])])]
        if "manager" in changes:
            mv = str(changes.get("manager") or "").strip()
            if mv:
                mods["manager"] = [(MODIFY_REPLACE, [mv])]
            else:
                mods["manager"] = [(MODIFY_DELETE, [])]  # type: ignore[list-item]
        try:
            uac_keys = ("passwordNeverExpires", "smartcardLogonRequired", "userAccountControl")
            u_row: dict[str, Any] | None = None
            if any(k in changes for k in uac_keys):
                u_row = self._by_dn(user_dn, ["userAccountControl"])
                if not u_row:
                    return False, "User not found"
            if "userAccountControl" in changes:
                mods["userAccountControl"] = [(MODIFY_REPLACE, [str(int(changes["userAccountControl"]))])]
            elif u_row is not None:
                uac = int(str(u_row.get("userAccountControl", UAC_NORMAL_ACCOUNT) or UAC_NORMAL_ACCOUNT))
                if "passwordNeverExpires" in changes:
                    if changes["passwordNeverExpires"]:
                        uac |= UAC_DONT_EXPIRE_PASSWD
                    else:
                        uac &= ~UAC_DONT_EXPIRE_PASSWD
                if "smartcardLogonRequired" in changes:
                    if changes["smartcardLogonRequired"]:
                        uac |= UAC_SMARTCARD_REQUIRED
                    else:
                        uac &= ~UAC_SMARTCARD_REQUIRED
                mods["userAccountControl"] = [(MODIFY_REPLACE, [str(uac)])]
            if not mods:
                return True, "Nothing to change."
            if not self._conn.modify(user_dn, mods):
                return False, str(self._conn.result)
            return True, str(self._conn.result.get("description", ""))
        except LDAPException as e:  # type: ignore[misc]
            return False, format_ldap_error(e)
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def _by_dn(self, dn: str, attrs: list[str]) -> dict[str, Any]:
        flt = f"(distinguishedName={escape_filter_chars(dn)})"
        r = self._search(flt, attrs, self._base(None))
        return r[0] if r else {}

    def disable_user(self, user_dn: str) -> tuple[bool, str]:
        u = self._by_dn(user_dn, ["userAccountControl"])
        if not u:
            return False, "User not found"
        uac = int(str(u.get("userAccountControl", 0) or 0)) | UAC_ACCOUNTDISABLE
        return self.modify_user(user_dn, {"userAccountControl": uac})

    def enable_user(self, user_dn: str) -> tuple[bool, str]:
        u = self._by_dn(user_dn, ["userAccountControl"])
        if not u:
            return False, "User not found"
        uac = int(str(u.get("userAccountControl", 0) or 0)) & ~UAC_ACCOUNTDISABLE
        return self.modify_user(user_dn, {"userAccountControl": uac})

    def unlock_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        try:
            if not self._conn.modify(user_dn, {"lockoutTime": [(MODIFY_REPLACE, ["0"])]}):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def delete_user(self, user_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        try:
            if not self._conn.delete(user_dn):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def reset_password(self, user_dn: str, new_password: str, *, must_change: bool = False) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        pw_enc = ('"' + new_password + '"').encode("utf-16-le")
        try:
            if not self._conn.modify(user_dn, {"unicodePwd": [(MODIFY_REPLACE, [pw_enc])]}):
                return False, format_ldap_error(Exception(self._conn.result))
            if must_change:
                if not self._conn.modify(user_dn, {"pwdLastSet": [(MODIFY_REPLACE, ["0"])]}):
                    return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def move_user(self, user_dn: str, target_ou_dn: str) -> tuple[bool, str]:
        return self.move_object(user_dn, target_ou_dn)

    def move_object(self, object_dn: str, target_ou_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        parts = object_dn.split(",", 1)
        if not parts:
            return False, "Invalid DN"
        rdn = parts[0]
        try:
            if not self._conn.modify_dn(object_dn, rdn, new_superior=target_ou_dn):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def create_ou(self, name: str, parent_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK OU {name}"
        if not self._conn:
            return False, "Not connected."
        dn = f"OU={name},{parent_dn}"
        attrs: dict[str, list[Any]] = {
            "objectClass": ["top", "organizationalUnit"],
            "ou": [name],
        }
        try:
            if not self._conn.add(dn, attributes=attrs):
                return False, str(self._conn.result)
            return True, dn
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def delete_group(self, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        try:
            if not self._conn.delete(group_dn):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def _group_type_value(self, scope: str, category: str) -> int:
        scope_bits = {"Global": 2, "DomainLocal": 4, "Universal": 8}.get(scope, 2)
        if str(category).lower() == "distribution":
            return scope_bits
        return int(0x80000000 | scope_bits)

    def create_group(
        self, name: str, ou_dn: str, scope: str, category: str, description: str = ""
    ) -> tuple[bool, str]:
        if self._mock_mode:
            return True, f"MOCK group {name}"
        if not self._conn:
            return False, "Not connected."
        dn = f"CN={name},{ou_dn}"
        gt = self._group_type_value(scope, category)
        attrs: dict[str, list[Any]] = {
            "objectClass": ["top", "group"],
            "sAMAccountName": [name],
            "groupType": [str(gt)],
        }
        if description:
            attrs["description"] = [description]
        try:
            if not self._conn.add(dn, attributes=attrs):
                return False, str(self._conn.result)
            return True, dn
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def modify_group(self, group_identity: str, changes: dict[str, Any]) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        ident = group_identity
        mods: dict[str, list[tuple[int, list[str]]]] = {}
        if "description" in changes:
            mods["description"] = [(MODIFY_REPLACE, [str(changes["description"])])]
        if "name" in changes and str(changes.get("name", "")).strip():
            mods["name"] = [(MODIFY_REPLACE, [str(changes["name"]).strip()])]
        if not mods:
            return True, "Nothing to change."
        try:
            if not self._conn.modify(ident, mods):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def get_group_parent_groups(self, group_identity: str) -> list[dict[str, Any]]:
        if self._mock_mode:
            return []
        rows = self._search(
            f"(&(objectClass=group)(distinguishedName={escape_filter_chars(group_identity)}))",
            ["memberOf"],
            self._base(None),
        )
        if not rows:
            return []
        mos = rows[0].get("memberOf") or []
        if isinstance(mos, str):
            mos = [mos] if mos else []
        out: list[dict[str, Any]] = []
        for mo in mos:
            g = self._search(
                f"(distinguishedName={escape_filter_chars(str(mo))})",
                ["name", "distinguishedName", "sAMAccountName"],
                self._base(None),
            )
            if g:
                x = g[0]
                out.append(
                    {
                        "Name": x.get("name", ""),
                        "DistinguishedName": x.get("distinguishedName", ""),
                        "SamAccountName": x.get("sAMAccountName", ""),
                    }
                )
        return out

    def get_all_groups(self) -> list[dict[str, Any]]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_groups(base)
        attrs = [
            "name",
            "cn",
            "sAMAccountName",
            "groupType",
            "description",
            "distinguishedName",
            "member",
        ]
        rows = self._search("(&(objectClass=group)(objectCategory=group))", attrs, base)
        out: list[dict[str, Any]] = []
        for g in rows:
            members = g.get("member")
            mc = 0
            if isinstance(members, str) and members:
                mc = len([x for x in members.split(";") if x])
            elif isinstance(members, list):
                mc = len(members)
            try:
                gt = int(str(g.get("groupType", 0) or 0))
            except ValueError:
                gt = 0
            scope_map = {2: "Global", 4: "DomainLocal", 8: "Universal"}
            scope_flag = abs(gt) & 0xF
            g["cn"] = g.get("name") or g.get("cn", "")
            g["samAccountName"] = g.get("sAMAccountName", "")
            g["member_count"] = mc
            g["groupCategory"] = "Security" if gt < 0 else "Distribution"
            g["groupScope"] = scope_map.get(scope_flag, "Global")
            out.append(g)
        return out

    def get_group_members(self, group_dn: str, *, recursive: bool = False) -> list[dict[str, Any]]:
        if self._mock_mode:
            return _mock_users(self._base(None), self.cfg.get("domain_name", "mock.local"))
        rows = self._search(
            f"(&(objectClass=group)(distinguishedName={escape_filter_chars(group_dn)}))",
            ["member"],
            self._base(None),
        )
        if not rows:
            return []
        members = rows[0].get("member") or []
        if isinstance(members, str):
            members = [members] if members else []
        if not isinstance(members, list):
            members = []
        out: list[dict[str, Any]] = []
        for mdn in members:
            if not mdn:
                continue
            obj = self._search(
                f"(distinguishedName={escape_filter_chars(str(mdn))})",
                ["cn", "sAMAccountName", "distinguishedName", "objectClass"],
                self._base(None),
            )
            if not obj:
                continue
            o = obj[0]
            ocs = o.get("objectClass", "")
            if isinstance(ocs, str):
                oclist = [ocs]
            elif isinstance(ocs, list):
                oclist = [str(x) for x in ocs]
            else:
                oclist = []
            out.append(
                {
                    "cn": o.get("cn", ""),
                    "sAMAccountName": o.get("sAMAccountName", ""),
                    "distinguishedName": o.get("distinguishedName", ""),
                    "objectClass": oclist,
                }
            )
        if recursive:
            expanded: list[dict[str, Any]] = []
            seen: set[str] = set()
            for m in out:
                ocs = m.get("objectClass") or []
                if "group" in [x.lower() for x in ocs]:
                    gdn = m.get("distinguishedName", "")
                    if gdn and gdn not in seen:
                        seen.add(gdn)
                        expanded.extend(self.get_group_members(gdn, recursive=True))
                else:
                    expanded.append(m)
            return expanded
        return out

    def add_user_to_group(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        try:
            if not self._conn.modify(group_dn, {"member": [(MODIFY_ADD, [user_dn])]}):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def remove_user_from_group(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        if self._mock_mode:
            return True, "MOCK"
        if not self._conn:
            return False, "Not connected."
        try:
            if not self._conn.modify(group_dn, {"member": [(MODIFY_DELETE, [user_dn])]}):
                return False, str(self._conn.result)
            return True, "ok"
        except Exception as e:  # noqa: BLE001
            return False, format_ldap_error(e)

    def get_ou_children_objects(self, ou_dn: str) -> list[dict[str, Any]]:
        if self._mock_mode:
            base = self._base(None)
            out: list[dict[str, Any]] = []
            needle = ou_dn.upper()
            for u in _mock_users(base, self.cfg.get("domain_name", "mock.local")):
                dn = (u.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": u["distinguishedName"], "name": u.get("displayName") or u.get("sAMAccountName"), "kind": "user"})
            for c in _mock_computers(base):
                dn = (c.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": c["distinguishedName"], "name": c.get("name"), "kind": "computer"})
            for g in _mock_groups(base):
                dn = (g.get("distinguishedName") or "").upper()
                if needle in dn and dn.endswith(needle):
                    out.append({"dn": g["distinguishedName"], "name": g.get("name"), "kind": "group"})
            return out
        from ldap3 import LEVEL as ONELEVEL  # type: ignore[import-not-found]

        rows = self._search(
            "(|(objectClass=user)(objectClass=computer)(objectClass=group))",
            ["distinguishedName", "name", "objectClass"],
            ou_dn,
            scope=ONELEVEL,
            paged_size=-1,
        )
        out2: list[dict[str, Any]] = []
        for r in rows:
            dn = r.get("distinguishedName", "")
            if not dn or dn.upper() == ou_dn.upper():
                continue
            ocs = r.get("objectClass", "")
            if isinstance(ocs, str):
                ocs_l = [ocs]
            else:
                ocs_l = [str(x) for x in (ocs or [])]
            kind = "object"
            olower = [x.lower() for x in ocs_l]
            if "group" in olower:
                kind = "group"
            elif "computer" in olower:
                kind = "computer"
            elif "user" in olower and "person" in olower:
                kind = "user"
            out2.append({"dn": dn, "name": r.get("name", ""), "kind": kind})
        return out2

    def get_ou_tree(self) -> list[dict[str, Any]]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_ou_tree(base)
        rows = self._search("(objectClass=organizationalUnit)", ["distinguishedName"], base)
        dns = [str(r.get("distinguishedName", "")) for r in rows if r.get("distinguishedName")]
        return build_ou_hierarchy(dns, base)

    def get_computers(self) -> list[dict[str, Any]]:
        base = self._base(None)
        if self._mock_mode:
            return _mock_computers(base)
        attrs = [
            "name",
            "distinguishedName",
            "operatingSystem",
            "lastLogonTimestamp",
            "whenChanged",
        ]
        rows = self._search("(&(objectCategory=computer)(objectClass=computer))", attrs, base)
        return rows

    def get_domain_info(self) -> dict[str, Any]:
        rows = self._search("(objectClass=domainDNS)", ["dc", "distinguishedName"], self._base(None))
        return rows[0] if rows else {}

    def get_all_attributes(self, object_dn: str) -> dict[str, Any]:
        flt = f"(distinguishedName={escape_filter_chars(object_dn)})"
        rows = self._search(flt, ["*"], self._base(None))
        return rows[0] if rows else {}
