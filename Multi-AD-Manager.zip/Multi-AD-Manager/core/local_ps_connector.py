"""Active Directory via local PowerShell (RSAT) targeting a domain FQDN with -Server."""

from __future__ import annotations

import subprocess
from typing import Any

from core.connector_errors import format_local_ps_error
from core.winrm_connector import WinRMConnector


class LocalPSConnector(WinRMConnector):
    """Same cmdlet surface as WinRMConnector; commands run locally via powershell.exe."""

    def __init__(self, domain_config: dict[str, Any]) -> None:
        super().__init__(domain_config)
        self._local_connected = False

    @property
    def is_connected(self) -> bool:  # type: ignore[override]
        if self._mock_mode:
            return True
        return self._local_connected

    def _domain_server(self) -> str:
        return (self.cfg.get("domain_name") or "").strip()

    def _exec_powershell(self, script: str) -> tuple[bool, str]:
        fqdn = self._domain_server()
        if not fqdn:
            return False, "Domain FQDN is missing in configuration."
        from core.ps_inject import inject_ad_server

        body = inject_ad_server(script, fqdn)
        full = f"Import-Module ActiveDirectory -ErrorAction Stop\n{body}"
        try:
            proc = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    full,
                ],
                capture_output=True,
                text=True,
                timeout=max(45, int(self.cfg.get("connection_timeout_sec", 30))),
            )
            if proc.returncode == 0:
                return True, (proc.stdout or "").strip()
            err = (proc.stderr or proc.stdout or "").strip()
            self._last_error = format_local_ps_error(err)
            return False, err
        except subprocess.TimeoutExpired:
            self._last_error = "PowerShell command timed out."
            return False, self._last_error
        except FileNotFoundError:
            self._last_error = "PowerShell not found on this system."
            return False, self._last_error
        except Exception as e:  # noqa: BLE001
            self._last_error = format_local_ps_error("", e)
            return False, str(e)

    def connect(self) -> bool:
        if self._mock_mode:
            self._last_error = ""
            self._local_connected = True
            return True
        ok, out = self._exec_powershell("'OK'")
        self._local_connected = ok
        if not ok:
            self._last_error = format_local_ps_error(out)
        else:
            self._active_server_label = "Local PS"
            self._active_server_endpoint = self._domain_server()
            self._active_server_host = self._domain_server()
        return ok

    def disconnect(self) -> None:
        self._local_connected = False
        super().disconnect()

    def test_connection(self) -> tuple[bool, str, float]:
        import time

        if self._mock_mode:
            return True, "Mock mode: no local PowerShell connection.", 0.0
        t0 = time.perf_counter()
        ok, out = self._exec_powershell("(Get-ADDomain).DNSRoot")
        ms = (time.perf_counter() - t0) * 1000.0
        if ok:
            return True, f"Connected: {out}", ms
        return False, format_local_ps_error(out), ms

    def _run_ps(self, script: str) -> tuple[bool, str]:
        if self._mock_mode:
            return super()._run_ps(script)
        if not self._local_connected:
            return False, "Not connected."
        return self._exec_powershell(script)
