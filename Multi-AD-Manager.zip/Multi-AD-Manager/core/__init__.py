# Core LDAP / domain logic package.
