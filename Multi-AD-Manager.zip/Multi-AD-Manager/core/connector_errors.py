"""Map low-level transport errors to analyst-friendly messages."""

from __future__ import annotations


def format_ldap_error(exc: BaseException) -> str:
    msg = str(exc).lower()
    raw = str(exc)
    if "invalidcredentials" in msg or "49" in raw or "data 52e" in msg:
        return "Invalid bind credentials for LDAP."
    if "server down" in msg or "ldap_server_down" in msg or "can't contact" in msg:
        return "LDAP server unreachable. Check host and port."
    if "unwilling" in msg or "ldap_unwilling_to_perform" in msg or "0000052d" in msg:
        return "Operation not allowed. Check permissions or use LDAPS for password operations."
    if "insufficient_access" in msg or "50" in raw and "access" in msg:
        return "Insufficient permissions in Active Directory."
    if "ssl" in msg or "tls" in msg or "certificate" in msg:
        return "SSL/TLS error. Try disabling certificate validation or use StartTLS."
    return raw[:500]


def format_ssh_error(exc: BaseException) -> str:
    msg = str(exc).lower()
    raw = str(exc)
    mod = type(exc).__name__
    if "Authentication" in mod or "authentication failed" in msg:
        return "SSH authentication failed. Check username and password/key."
    if "NoValidConnections" in mod or "connection refused" in msg or "errno 111" in msg:
        return "Cannot connect to SSH host. Check IP and port."
    if "timeout" in msg:
        return "SSH connection timed out."
    if "channel" in msg and "fail" in msg:
        return "SSH tunnel channel failed. Check firewall rules."
    return raw[:500]


def format_local_ps_error(stderr: str, exc: BaseException | None = None) -> str:
    s = (stderr or "").lower()
    if "activedirectory" in s and ("not found" in s or "could not be loaded" in s or "not loaded" in s):
        return "ActiveDirectory PowerShell module not found. Install RSAT."
    if "access is denied" in s or "denied" in s and "access" in s:
        return "Insufficient permissions. Run as a user with AD read/write rights."
    if "cannot find" in s and "server" in s:
        return "Cannot reach domain controller. Check network connectivity."
    if exc:
        return str(exc)[:500]
    return (stderr or "PowerShell error.")[:500]


def format_adws_error(msg: str) -> str:
    m = (msg or "").lower()
    if "9389" in m or "ad web" in m or "refused" in m or "timed out" in m:
        return "ADWS port 9389 unreachable. Ensure AD Web Services is running on the DC."
    return (msg or "ADWS connection failed.")[:500]
