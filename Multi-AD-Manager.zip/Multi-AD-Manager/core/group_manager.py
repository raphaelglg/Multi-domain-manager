"""Group membership helpers."""

from __future__ import annotations

from typing import Any, Callable


class GroupManager:
    def __init__(self, connector: Any, audit: Callable[..., None] | None = None) -> None:
        self.c = connector
        self._audit = audit

    def list_groups(self):
        return self.c.get_all_groups()

    def members(self, group_dn: str, *, recursive: bool = False):
        return self.c.get_group_members(group_dn, recursive=recursive)

    def modify_group(self, group_dn: str, changes: dict) -> tuple[bool, str]:
        ok, msg = self.c.modify_group(group_dn, changes)
        if self._audit:
            self._audit(
                operation="modify_group",
                target=group_dn,
                success=ok,
                error=None if ok else msg,
                params=changes,
            )
        return ok, msg

    def create(self, name: str, ou_dn: str, scope: str, category: str, description: str = "") -> tuple[bool, str]:
        ok, msg = self.c.create_group(name, ou_dn, scope, category, description)
        if self._audit:
            self._audit(
                operation="create_group",
                target=name,
                success=ok,
                error=None if ok else msg,
                params={"ou": ou_dn, "scope": scope, "category": category},
            )
        return ok, msg

    def add_member(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.add_user_to_group(user_dn, group_dn)
        if self._audit:
            self._audit(
                operation="add_group_member",
                target=group_dn,
                success=ok,
                error=None if ok else msg,
                params={"member": user_dn},
            )
        return ok, msg

    def remove_member(self, user_dn: str, group_dn: str) -> tuple[bool, str]:
        ok, msg = self.c.remove_user_from_group(user_dn, group_dn)
        if self._audit:
            self._audit(
                operation="remove_group_member",
                target=group_dn,
                success=ok,
                error=None if ok else msg,
                params={"member": user_dn},
            )
        return ok, msg
