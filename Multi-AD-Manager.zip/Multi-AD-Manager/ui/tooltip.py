"""Lightweight hover tooltips for CTk widgets."""

from __future__ import annotations

from typing import Any

import customtkinter as ctk


class ToolTip:
    def __init__(self, widget: Any, text: str) -> None:
        self.widget = widget
        self.text = text
        self._win: ctk.CTkToplevel | None = None
        widget.bind("<Enter>", self._show, add="+")
        widget.bind("<Leave>", self._hide, add="+")

    def set_text(self, text: str) -> None:
        self.text = text

    def _show(self, _evt=None) -> None:
        if self._win is not None:
            return
        x = self.widget.winfo_rootx() + 12
        y = self.widget.winfo_rooty() + 12
        self._win = ctk.CTkToplevel(self.widget)
        self._win.wm_overrideredirect(True)
        self._win.geometry(f"+{x}+{y}")
        ctk.CTkLabel(self._win, text=self.text, corner_radius=6, padx=8, pady=6).pack()

    def _hide(self, _evt=None) -> None:
        if self._win is not None:
            try:
                self._win.destroy()
            except Exception:
                pass
            self._win = None
