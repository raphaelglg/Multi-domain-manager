"""Top status strip for per-domain connectivity."""

from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from core.domain_config import transport_display_name
from ui.tooltip import ToolTip


class DomainStatusBar(ctk.CTkFrame):
    def __init__(
        self,
        master,
        *,
        on_reconnect: Callable[[str], None],
        get_snapshot: Callable[[], dict],
    ) -> None:
        super().__init__(master, height=64)
        self.on_reconnect = on_reconnect
        self.get_snapshot = get_snapshot
        self._cards: dict[str, dict] = {}
        self._pulse_state = False
        try:
            self._container = ctk.CTkScrollableFrame(self, height=56, orientation="horizontal")
        except Exception:
            self._container = ctk.CTkScrollableFrame(self, height=56)
        self._container.pack(fill="x", padx=6, pady=4)
        self._alert = ctk.CTkLabel(self, text="", text_color=("red", "orange"))
        self._alert.pack(fill="x", padx=8, pady=(0, 4))
        self._pulse()

    def _pulse(self) -> None:
        self._pulse_state = not self._pulse_state
        snap = self.get_snapshot()
        any_off = any(v.get("state") in ("offline", "error") for v in snap.values())
        if any_off and self._pulse_state:
            self._alert.configure(text="⚠ One or more domains are offline or in error state.")
        else:
            self._alert.configure(text="")
        self.after(900, self._pulse)

    def refresh(self, domains: list[dict]) -> None:
        snap = self.get_snapshot()
        for w in self._container.winfo_children():
            w.destroy()
        self._cards.clear()
        for d in domains:
            did = d.get("id")
            if not did:
                continue
            st = snap.get(did, {})
            state = st.get("state", "offline")
            color = {
                "online": ("#2ecc71", "#27ae60"),
                "offline": ("#e74c3c", "#c0392b"),
                "reconnecting": ("#f1c40f", "#f39c12"),
                "error": ("#e67e22", "#d35400"),
                "disabled": ("#95a5a6", "#7f8c8d"),
            }.get(state, ("#95a5a6", "#7f8c8d"))
            card = ctk.CTkFrame(self._container, width=220, height=52, fg_color=("gray90", "gray20"))
            card.pack(side="left", padx=6, pady=2)
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=6)
            dot = ctk.CTkLabel(row, text="●", text_color=color, width=20)
            dot.pack(side="left")
            title = ctk.CTkLabel(row, text=d.get("client_name") or d.get("domain_name") or did, anchor="w")
            title.pack(side="left", fill="x", expand=True)
            tlabel = st.get("transport") or transport_display_name(d.get("transport"))
            ep = st.get("active_endpoint", "") or ""
            srv = st.get("active_server", "") or ""
            active_line = f"{ep} ({srv})".strip() if ep and srv else (ep or srv or "—")
            tip = ToolTip(
                card,
                f"{d.get('domain_name')}\n"
                f"Transport: {tlabel}\n"
                f"State: {state}\n"
                f"Active server: {active_line}\n"
                f"Latency: {st.get('latency_ms', 0):.1f} ms\n"
                f"Last check: {st.get('last_sync', '')}\n"
                f"{st.get('message', '')}",
            )

            def reconnect(x=did) -> None:
                self.on_reconnect(x)

            ctk.CTkButton(row, text="↻", width=32, command=reconnect).pack(side="right", padx=(4, 0))
            self._cards[did] = {"card": card, "tip": tip}
