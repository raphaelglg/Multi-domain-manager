"""Main CustomTkinter shell."""

from __future__ import annotations

import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

import customtkinter as ctk

from core.domain_manager import DomainManager
from ui.dialogs.add_domain_dialog import AddDomainDialog
from ui.domain_status_bar import DomainStatusBar
from ui.sidebar import Sidebar
from ui.tabs.audit_tab import AuditTab
from ui.tabs.computers_tab import ComputersTab
from ui.tabs.create_user_tab import CreateUserTab
from ui.tabs.groups_tab import GroupsTab
from ui.tabs.ous_tab import OUTab
from ui.tabs.users_tab import UsersTab
from ui.toast import show_toast
from utils import crypto_vault
from utils.audit_logger import AuditLogger, append_error_log, append_runtime_log


class AdManagerApp(ctk.CTk):
    def __init__(self, project_root: Path) -> None:
        super().__init__()
        self.project_root = project_root
        self.title("AD Multi-Domain Manager")
        self.geometry("1320x860")

        self.dm = DomainManager(project_root)
        self.audit = AuditLogger(project_root / "data" / "audit.sqlite")
        self.selected_domain_id: str | None = None
        self._last_health: dict[str, dict] = {}
        self._master_key: bytes | None = None
        self._domain_event_pending = False
        self._reconnect_inflight: set[str] = set()

        ctk.set_appearance_mode("System")
        self._build_lock_ui()

    # --- master / vault -------------------------------------------------
    def _build_lock_ui(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        frame = ctk.CTkFrame(self)
        frame.pack(expand=True, fill="both", padx=24, pady=24)
        first = not crypto_vault.has_vault(self.project_root)
        ctk.CTkLabel(frame, text="AD Multi-Domain Manager", font=ctk.CTkFont(size=22, weight="bold")).pack(pady=(10, 6))
        if first:
            ctk.CTkLabel(
                frame,
                text="First run: set a master password to encrypt locally stored credentials.",
                wraplength=520,
                justify="left",
            ).pack(pady=6)
            self.mp1 = ctk.CTkEntry(frame, placeholder_text="Master password", show="*")
            self.mp1.pack(fill="x", pady=4)
            self.mp2 = ctk.CTkEntry(frame, placeholder_text="Confirm master password", show="*")
            self.mp2.pack(fill="x", pady=4)

            def create_vault() -> None:
                a, b = self.mp1.get(), self.mp2.get()
                if len(a) < 8:
                    show_toast(self, "Master password is too short (min. 8 characters).")
                    return
                if a != b:
                    show_toast(self, "Passwords do not match.")
                    return
                crypto_vault.create_vault(self.project_root, a)
                self._master_key = crypto_vault.load_master_key(self.project_root, a)
                self._enter_main()

            ctk.CTkButton(frame, text="Create vault and continue", command=create_vault).pack(pady=12)
        else:
            ctk.CTkLabel(frame, text="Enter your master password to unlock stored credentials.", wraplength=520, justify="left").pack(
                pady=6
            )
            self.mp = ctk.CTkEntry(frame, placeholder_text="Master password", show="*")
            self.mp.pack(fill="x", pady=6)

            def unlock() -> None:
                key = crypto_vault.load_master_key(self.project_root, self.mp.get())
                if not key:
                    show_toast(self, "Invalid master password.")
                    return
                self._master_key = key
                self._enter_main()

            ctk.CTkButton(frame, text="Unlock", command=unlock).pack(pady=12)

    def lock_session(self) -> None:
        self._master_key = None
        self.dm.set_master_key(None)
        self.dm.disconnect_all()
        self._build_lock_ui()

    # --- main UI --------------------------------------------------------
    def _enter_main(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self.dm.set_master_key(self._master_key)
        self.dm.load_domains()
        self.dm.debug_credentials()

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self.status_bar = DomainStatusBar(self, on_reconnect=self._reconnect, get_snapshot=lambda: self.dm.status_snapshot())
        self.status_bar.grid(row=0, column=0, columnspan=2, sticky="ew")

        self.sidebar = Sidebar(
            self,
            on_select=self._select_domain,
            on_add_domain=self._open_add_domain,
            on_edit_domain=self._open_edit_domain,
            on_remove_domain=self._remove_domain,
            on_settings=self._open_settings,
            get_status=lambda did: self.dm.status_snapshot().get(did, {}).get("state", "offline"),
        )
        self.sidebar.grid(row=1, column=0, sticky="nsew")

        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=1, column=1, sticky="nsew", padx=(0, 8), pady=8)
        for name in ("Users", "Groups", "OUs", "Computers", "Create User", "Audit"):
            self.tabview.add(name)

        self.users_tab = UsersTab(self.tabview.tab("Users"), app=self)
        self.users_tab.pack(expand=True, fill="both")
        self.groups_tab = GroupsTab(self.tabview.tab("Groups"), app=self)
        self.groups_tab.pack(expand=True, fill="both")
        self.ou_tab = OUTab(self.tabview.tab("OUs"), app=self)
        self.ou_tab.pack(expand=True, fill="both")
        self.comp_tab = ComputersTab(self.tabview.tab("Computers"), app=self)
        self.comp_tab.pack(expand=True, fill="both")
        self.create_tab = CreateUserTab(self.tabview.tab("Create User"), app=self)
        self.create_tab.pack(expand=True, fill="both")
        self.audit_tab = AuditTab(self.tabview.tab("Audit"), app=self)
        self.audit_tab.pack(expand=True, fill="both")

        self._refresh_sidebar_status()
        self.status_bar.refresh(self.dm.domains())
        self._last_health = dict(self.dm.status_snapshot())
        self._select_domain(None)
        self.dm.add_listener(self._schedule_domain_event)
        self.dm.start_health_check_loop(30)
        self._connect_all_domains_async()

    def _connect_all_domains_async(self) -> None:
        """Avoid blocking UI during unlock while WinRM connects/retries."""
        append_runtime_log(self.project_root, "connect_all_async:start")
        self.status_bar.refresh(self.dm.domains())

        def worker() -> None:
            try:
                self.dm.connect_all()
                append_runtime_log(self.project_root, "connect_all_async:done")
            except Exception as e:  # noqa: BLE001
                append_error_log(self.project_root, "connect_all_async", e)
                append_runtime_log(self.project_root, f"connect_all_async:error:{type(e).__name__}:{e}")
            finally:
                try:
                    self.after(0, self._after_connect_all)
                except tk.TclError:
                    pass

        threading.Thread(target=worker, name="connect-all-domains", daemon=True).start()

    def _after_connect_all(self) -> None:
        self._schedule_domain_event()
        selected = self.selected_domain_id
        if selected:
            self._select_domain(selected)
            return
        for d in self.dm.domains():
            did = d.get("id")
            if not did:
                continue
            st = self.dm.status_snapshot().get(did, {})
            if st.get("state") == "online":
                self._select_domain(did)
                break

    def _on_domain_event(self) -> None:
        append_runtime_log(self.project_root, "domain_event:refresh_ui:start")
        snap = self.dm.status_snapshot()
        for did, st in snap.items():
            prev = self._last_health.get(did, {}).get("state")
            cur = st.get("state")
            if prev and prev != cur:
                label = did
                for d in self.dm.domains():
                    if d.get("id") == did:
                        label = d.get("client_name") or d.get("domain_name") or did
                        break
                if cur == "online":
                    show_toast(self, f"Domain online: {label}")
                elif cur in ("offline", "error"):
                    show_toast(self, f"Domain unavailable: {label}")
        self._last_health = dict(snap)
        if self.selected_domain_id is None:
            for d in self.dm.domains():
                did = d.get("id")
                if not did:
                    continue
                st = snap.get(did, {})
                if st.get("state") == "online":
                    self._select_domain(did)
                    break
        self._refresh_sidebar_status()
        self.status_bar.refresh(self.dm.domains())
        append_runtime_log(self.project_root, "domain_event:refresh_ui:done")

    def _schedule_domain_event(self) -> None:
        """Ensure UI refresh runs on Tk main thread only."""
        if self._domain_event_pending:
            return
        self._domain_event_pending = True
        try:
            self.after(0, self._run_domain_event_on_main)
        except tk.TclError:
            # App/window may be closing; ignore late background notifications.
            self._domain_event_pending = False

    def _run_domain_event_on_main(self) -> None:
        self._domain_event_pending = False
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        self._on_domain_event()

    def _refresh_sidebar_status(self) -> None:
        try:
            self.sidebar.rebuild(self.dm.domains())
        except Exception as e:  # noqa: BLE001
            append_error_log(self.project_root, "sidebar rebuild", e)
            append_runtime_log(self.project_root, f"sidebar rebuild:error:{type(e).__name__}:{e}")

    def _reconnect(self, domain_id: str) -> None:
        self._reconnect_domain_async(domain_id)

    def _select_domain(self, domain_id: str | None) -> None:
        self.selected_domain_id = domain_id
        tabs = (
            getattr(self, "users_tab", None),
            getattr(self, "groups_tab", None),
            getattr(self, "ou_tab", None),
            getattr(self, "comp_tab", None),
            getattr(self, "create_tab", None),
        )
        for tab in tabs:
            if tab is None:
                continue
            if hasattr(tab, "reload"):
                tab.reload()

    def _open_add_domain(self) -> None:
        if not self._master_key:
            show_toast(self, "Session is locked.")
            return

        def on_saved(cfg: dict) -> None:
            self.dm.add_domain(cfg)
            self._refresh_sidebar_status()
            self.status_bar.refresh(self.dm.domains())
            self._reconnect_domain_async(cfg["id"])

        AddDomainDialog(self, project_root=self.project_root, master_key=self._master_key, on_saved=on_saved)

    def _open_edit_domain(self, domain_id: str) -> None:
        if not self._master_key:
            show_toast(self, "Session is locked.")
            return
        existing = self.dm.get_domain(domain_id)
        if not existing:
            show_toast(self, "Selected domain not found.")
            return

        def on_saved(cfg: dict) -> None:
            self.dm.update_domain(domain_id, cfg)
            self._refresh_sidebar_status()
            self.status_bar.refresh(self.dm.domains())
            self._reconnect_domain_async(domain_id)

        AddDomainDialog(
            self,
            project_root=self.project_root,
            master_key=self._master_key,
            existing=existing,
            on_saved=on_saved,
        )

    def _remove_domain(self, domain_id: str) -> None:
        if not self._master_key:
            show_toast(self, "Session is locked.")
            return
        existing = self.dm.get_domain(domain_id)
        if not existing:
            show_toast(self, "Selected domain not found.")
            return
        label = existing.get("client_name") or existing.get("domain_name") or domain_id
        if not messagebox.askyesno("Delete Domain", f"Delete domain '{label}'?", parent=self):
            return
        self.dm.remove_domain(domain_id)
        if self.selected_domain_id == domain_id:
            self._select_domain(None)
        self._refresh_sidebar_status()
        self.status_bar.refresh(self.dm.domains())
        show_toast(self, "Domain deleted.")

    def _reconnect_domain_async(self, domain_id: str) -> None:
        """Reconnect a domain without blocking the UI thread."""
        if domain_id in self._reconnect_inflight:
            append_runtime_log(self.project_root, f"reconnect_async:skip_inflight:{domain_id}")
            return
        self._reconnect_inflight.add(domain_id)
        append_runtime_log(self.project_root, f"reconnect_async:start:{domain_id}")

        def worker() -> None:
            ok = False
            try:
                ok = self.dm.reconnect_domain(domain_id)
                append_runtime_log(self.project_root, f"reconnect_async:done:{domain_id}:ok={ok}")
            except Exception as e:  # noqa: BLE001
                append_error_log(self.project_root, f"reconnect_async {domain_id}", e)
                append_runtime_log(self.project_root, f"reconnect_async:error:{domain_id}:{type(e).__name__}:{e}")
            finally:
                try:
                    self.after(0, lambda: self._after_reconnect(domain_id, ok))
                except tk.TclError:
                    pass

        threading.Thread(target=worker, name=f"reconnect-{domain_id}", daemon=True).start()

    def _after_reconnect(self, domain_id: str, ok: bool) -> None:
        self._reconnect_inflight.discard(domain_id)
        self._refresh_sidebar_status()
        self.status_bar.refresh(self.dm.domains())
        # Ensure current tab datasets are refreshed after reconnect.
        self._select_domain(self.selected_domain_id)
        if ok:
            show_toast(self, "Domain reconnected.")
        else:
            show_toast(self, "Failed to reconnect domain.")
            status = self.dm.status_snapshot().get(domain_id, {})
            reason = status.get("message") or "Unknown error while connecting."
            messagebox.showerror(
                "Domain Connection Failed",
                f"Could not connect to the domain after saving changes.\n\nReason:\n{reason}",
                parent=self,
            )
        append_runtime_log(self.project_root, f"reconnect_async:ui_done:{domain_id}:ok={ok}")

    def _open_settings(self) -> None:
        win = ctk.CTkToplevel(self)
        win.title("Settings")
        win.geometry("420x260")
        ctk.CTkLabel(win, text="Appearance").pack(anchor="w", padx=12, pady=(12, 4))
        mode = ctk.CTkOptionMenu(win, values=["System", "Light", "Dark"])

        def apply_mode(v: str) -> None:
            ctk.set_appearance_mode(v)

        mode.configure(command=apply_mode)
        mode.set("System")
        mode.pack(fill="x", padx=12)

        ctk.CTkButton(win, text="Lock session (clear memory)", command=lambda: (win.destroy(), self.lock_session())).pack(
            padx=12, pady=16, fill="x"
        )
        ctk.CTkButton(win, text="Close", command=win.destroy).pack(padx=12, pady=6, fill="x")

    def ensure_online(self, domain_id: str) -> bool:
        d = self.dm.get_domain(domain_id)
        if d and d.get("mock_mode"):
            return True
        st = self.dm.status_snapshot().get(domain_id, {}).get("state")
        if st == "online":
            return True
        try:
            return self.dm.get_connector(domain_id).is_connected
        except Exception:
            return False

    def make_audit_cb(self, domain_id: str):
        d = self.dm.get_domain(domain_id) or {}

        def _cb(*, operation: str, target: str | None, success: bool, error: str | None, params: dict | None) -> None:
            self.audit.log(
                operation=operation,
                target=target,
                success=success,
                error=error,
                params=params,
                domain_id=domain_id,
                domain_name=d.get("domain_name"),
            )

        return _cb

    def log_audit(self, operation: str, domain_id: str, target: str, ok: bool, err: str | None = None, params=None) -> None:
        d = self.dm.get_domain(domain_id) or {}
        self.audit.log(
            operation=operation,
            target=target,
            success=ok,
            error=err,
            params=params,
            domain_id=domain_id,
            domain_name=d.get("domain_name"),
        )

    def open_create_user_tab(self, ou_dn: str | None) -> None:
        self.tabview.set("Create User")
        self.create_tab.set_preset_ou(ou_dn)

    def focus_users_tab(self, sam: str) -> None:
        self.tabview.set("Users")
        if hasattr(self.users_tab, "focus_sam"):
            self.users_tab.focus_sam(sam)
