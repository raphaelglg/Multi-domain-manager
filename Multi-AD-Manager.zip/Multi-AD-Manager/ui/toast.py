"""Small transient notifications."""

from __future__ import annotations

import customtkinter as ctk


def show_toast(parent, message: str, *, ms: int = 2800) -> None:
    tw = ctk.CTkToplevel(parent)
    tw.overrideredirect(True)
    tw.attributes("-topmost", True)
    x = parent.winfo_rootx() + parent.winfo_width() - 360
    y = parent.winfo_rooty() + 40
    tw.geometry(f"+{max(10, x)}+{y}")
    ctk.CTkLabel(tw, text=message, padx=12, pady=10, corner_radius=8).pack()
    parent.after(ms, tw.destroy)
