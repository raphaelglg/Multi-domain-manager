"""Left navigation for domain selection."""

from __future__ import annotations

from typing import Callable

import customtkinter as ctk


class Sidebar(ctk.CTkFrame):
    def __init__(
        self,
        master,
        *,
        on_select: Callable[[str | None], None],
        on_add_domain: Callable[[], None],
        on_edit_domain: Callable[[str], None],
        on_remove_domain: Callable[[str], None],
        on_settings: Callable[[], None],
        get_status: Callable[[str], str],
    ) -> None:
        super().__init__(master, width=240)
        self.on_select = on_select
        self.on_add_domain = on_add_domain
        self.on_edit_domain = on_edit_domain
        self.on_remove_domain = on_remove_domain
        self.on_settings = on_settings
        self.get_status = get_status
        self._selected: str | None = None
        self._buttons: dict[str | None, ctk.CTkButton] = {}

        ctk.CTkLabel(self, text="Domains", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=10, pady=(10, 4))
        self.list_frame = ctk.CTkScrollableFrame(self, label_text="")
        self.list_frame.pack(fill="both", expand=True, padx=6, pady=6)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=6, pady=8)
        ctk.CTkButton(foot, text="+ Add Domain", command=self.on_add_domain).pack(fill="x", pady=2)
        ctk.CTkButton(foot, text="Edit Selected Domain", command=self._edit_selected).pack(fill="x", pady=2)
        ctk.CTkButton(foot, text="Delete Selected Domain", command=self._remove_selected).pack(fill="x", pady=2)
        ctk.CTkButton(foot, text="Settings", command=self.on_settings).pack(fill="x", pady=2)

    def rebuild(self, domains: list[dict]) -> None:
        for w in self.list_frame.winfo_children():
            w.destroy()
        self._buttons.clear()

        def mk_handler(did: str | None):
            def _h() -> None:
                self._selected = did
                self.on_select(did)
                self._paint_selection()

            return _h

        b_all = ctk.CTkButton(self.list_frame, text="● All Domains", anchor="w", command=mk_handler(None))
        b_all.pack(fill="x", pady=2)
        self._buttons[None] = b_all

        for d in domains:
            did = d.get("id")
            if not did:
                continue
            st = self.get_status(did)
            label = f"[{st}] {d.get('client_name') or d.get('domain_name')}"
            btn = ctk.CTkButton(self.list_frame, text=label, anchor="w", command=mk_handler(did))
            btn.pack(fill="x", pady=2)
            self._buttons[did] = btn
        if self._selected is not None and self._selected not in self._buttons:
            self._selected = None
        self._paint_selection()

    def _paint_selection(self) -> None:
        for key, btn in self._buttons.items():
            if key == self._selected:
                btn.configure(fg_color=("gray75", "gray25"))
            else:
                btn.configure(fg_color=("gray85", "gray17"))

    def _edit_selected(self) -> None:
        did = self._selected
        if did:
            self.on_edit_domain(did)

    def _remove_selected(self) -> None:
        did = self._selected
        if did:
            self.on_remove_domain(did)
