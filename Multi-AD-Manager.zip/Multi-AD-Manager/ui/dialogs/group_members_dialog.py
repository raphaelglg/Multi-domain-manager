"""View AD group members (direct or recursive) with export."""

from __future__ import annotations

import csv
import threading
from tkinter import filedialog, ttk

import customtkinter as ctk


class GroupMembersDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, title: str, load_members, initial_recursive: bool = False) -> None:
        super().__init__(parent)
        self.title(title)
        self.geometry("640x480")
        self.transient(parent)
        self._load_members = load_members
        self._recursive = ctk.BooleanVar(value=initial_recursive)

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=8)
        ctk.CTkRadioButton(top, text="Direct members", variable=self._recursive, value=False, command=self._reload).pack(
            side="left", padx=6
        )
        ctk.CTkRadioButton(top, text="Recursive members", variable=self._recursive, value=True, command=self._reload).pack(
            side="left", padx=6
        )
        ctk.CTkButton(top, text="Reload", width=100, command=self._reload).pack(side="right", padx=4)
        ctk.CTkButton(top, text="Export CSV", width=110, command=self._export).pack(side="right", padx=4)

        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=10, pady=4)
        cols = ("name", "sam", "dn", "cls")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", height=18)
        for c, h, w in (
            ("name", "Name", 180),
            ("sam", "Logon name", 120),
            ("dn", "DN", 260),
            ("cls", "Class", 80),
        ):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, stretch=True)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        self._status = ctk.CTkLabel(self, text="", anchor="w")
        self._status.pack(fill="x", padx=10, pady=4)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Close", command=self.destroy).pack(side="right")

        self._cache: list[dict] = []
        self._reload()

    def _reload(self) -> None:
        self._status.configure(text="Loading…")

        def work() -> list[dict]:
            try:
                return self._load_members(bool(self._recursive.get()))
            except Exception:
                return []

        def done(rows: list[dict]) -> None:
            self._cache = rows
            for i in self.tree.get_children():
                self.tree.delete(i)
            for m in rows:
                ocs = m.get("objectClass") or []
                if isinstance(ocs, str):
                    ocs = [ocs]
                cls = ocs[-1] if ocs else ""
                self.tree.insert(
                    "",
                    "end",
                    values=(
                        m.get("cn", ""),
                        m.get("sAMAccountName", ""),
                        m.get("distinguishedName", ""),
                        cls,
                    ),
                )
            self._status.configure(text=f"{len(rows)} member(s).")

        def runner() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=runner, daemon=True).start()

    def _export(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["Name", "Logon name", "DN", "Class"])
            for m in self._cache:
                ocs = m.get("objectClass") or []
                if isinstance(ocs, str):
                    ocs = [ocs]
                cls = ocs[-1] if ocs else ""
                w.writerow([m.get("cn", ""), m.get("sAMAccountName", ""), m.get("distinguishedName", ""), cls])
