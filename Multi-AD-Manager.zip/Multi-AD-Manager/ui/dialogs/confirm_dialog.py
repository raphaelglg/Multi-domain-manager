"""Simple confirmation dialog."""

from __future__ import annotations

import customtkinter as ctk


def ask_confirm(parent, title: str, message: str) -> bool:
    result = {"ok": False}

    win = ctk.CTkToplevel(parent)
    win.title(title)
    win.transient(parent)
    win.grab_set()
    win.geometry("420x180")

    ctk.CTkLabel(win, text=message, wraplength=380, justify="left").pack(padx=16, pady=(16, 8), fill="x")

    btns = ctk.CTkFrame(win, fg_color="transparent")
    btns.pack(pady=12)

    def on_yes() -> None:
        result["ok"] = True
        win.destroy()

    def on_no() -> None:
        result["ok"] = False
        win.destroy()

    ctk.CTkButton(btns, text="Cancel", width=120, command=on_no).pack(side="left", padx=8)
    ctk.CTkButton(btns, text="OK", width=120, command=on_yes).pack(side="left", padx=8)

    parent.wait_window(win)
    return bool(result["ok"])
