"""Add/remove group memberships for a user."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Callable

import customtkinter as ctk

from core.group_manager import GroupManager

if TYPE_CHECKING:
    from ui.app import AdManagerApp


def _cn_from_dn(dn: str) -> str:
    if not dn:
        return ""
    first = dn.split(",")[0]
    if first.upper().startswith("CN="):
        return first[3:]
    return first


class ManageGroupsDialog(ctk.CTkToplevel):
    def __init__(
        self,
        parent,
        *,
        app: "AdManagerApp",
        domain_id: str,
        user_sam: str,
        user_dn: str,
        initial_member_of: list[str],
        on_done: Callable[[], None] | None = None,
    ) -> None:
        super().__init__(parent)
        self.app = app
        self._domain_id = domain_id
        self._user_sam = user_sam
        self._user_dn = user_dn
        self._on_done = on_done
        self._snap: set[str] = set(initial_member_of or [])
        self._current: set[str] = set(self._snap)
        self._all_groups: list[dict] = []

        self.title(f"Groups — {user_sam}")
        self.geometry("760x480")
        self.transient(parent)

        mid = ctk.CTkFrame(self, fg_color="transparent")
        mid.pack(fill="both", expand=True, padx=10, pady=8)

        left = ctk.CTkFrame(mid)
        left.pack(side="left", fill="both", expand=True, padx=(0, 6))
        ctk.CTkLabel(left, text="Current groups").pack(anchor="w")
        self.left_list = ctk.CTkScrollableFrame(left, height=320)
        self.left_list.pack(fill="both", expand=True, pady=4)
        ctk.CTkLabel(left, text="Use the − button next to a group to remove it.", font=ctk.CTkFont(size=11)).pack(anchor="w")

        right = ctk.CTkFrame(mid)
        right.pack(side="left", fill="both", expand=True, padx=(6, 0))
        ctk.CTkLabel(right, text="Search in domain").pack(anchor="w")
        self.q = ctk.CTkEntry(right, placeholder_text="Group name…")
        self.q.pack(fill="x", pady=4)
        self.q.bind("<KeyRelease>", lambda _e: self._render_right())
        self.right_list = ctk.CTkScrollableFrame(right, height=320)
        self.right_list.pack(fill="both", expand=True, pady=4)
        ctk.CTkLabel(right, text="Double-click or use the + button to add", font=ctk.CTkFont(size=11)).pack(anchor="w")

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(foot, text="Apply changes", command=self._apply).pack(side="right", padx=4)

        self._render_left()
        threading.Thread(target=self._load_groups, daemon=True).start()

    def _load_groups(self) -> None:
        rows: list[dict] = []

        def work() -> None:
            nonlocal rows
            try:
                con = self.app.dm.get_connector(self._domain_id)
                if con.is_connected:
                    rows = con.get_all_groups()
            except Exception:
                rows = []

        def done() -> None:
            self._all_groups = rows
            self._render_right()

        work()
        self.after(0, done)

    def _render_left(self) -> None:
        for w in self.left_list.winfo_children():
            w.destroy()
        for gdn in sorted(self._current, key=lambda x: _cn_from_dn(x).lower()):
            row = ctk.CTkFrame(self.left_list, fg_color="transparent")
            row.pack(fill="x", pady=1)
            lab = ctk.CTkLabel(row, text=_cn_from_dn(gdn), anchor="w")
            lab.pack(side="left", fill="x", expand=True)
            ctk.CTkButton(row, text="−", width=28, command=lambda d=gdn: self._remove(d)).pack(side="right")

    def _remove(self, gdn: str) -> None:
        self._current.discard(gdn)
        self._render_left()

    def _render_right(self) -> None:
        for w in self.right_list.winfo_children():
            w.destroy()
        q = self.q.get().strip().lower()
        shown = 0
        for g in self._all_groups:
            gdn = g.get("distinguishedName") or ""
            if not gdn or gdn in self._current:
                continue
            name = (g.get("name") or g.get("cn") or "").lower()
            sam = str(g.get("samAccountName") or "").lower()
            if q and q not in name and q not in sam and q not in gdn.lower():
                continue
            shown += 1
            if shown > 150:
                break
            label = g.get("name") or g.get("cn") or gdn
            btn = ctk.CTkButton(
                self.right_list,
                text=f"+ {label}",
                anchor="w",
                command=lambda d=gdn: self._add(d),
            )
            btn.pack(fill="x", pady=1)

    def _add(self, gdn: str) -> None:
        self._current.add(gdn)
        self._render_left()
        self._render_right()

    def _apply(self) -> None:
        if not self.app.ensure_online(self._domain_id):
            return
        con = self.app.dm.get_connector(self._domain_id)
        gm = GroupManager(con, audit=self.app.make_audit_cb(self._domain_id))
        initial = set(self._snap)
        now = set(self._current)
        for gdn in now - initial:
            gm.add_member(self._user_dn, gdn)
        for gdn in initial - now:
            gm.remove_member(self._user_dn, gdn)
        if self._on_done:
            self._on_done()
        self.destroy()
