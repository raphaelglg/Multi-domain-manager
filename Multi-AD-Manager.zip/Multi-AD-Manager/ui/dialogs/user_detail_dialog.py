"""Read-only / quick actions for a user entry."""

from __future__ import annotations

import customtkinter as ctk
from tkinter import simpledialog

from core.ad_constants import UAC_ACCOUNTDISABLE, _filetime_to_iso
from ui.dialogs.confirm_dialog import ask_confirm


class UserDetailDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, user: dict, actions) -> None:
        super().__init__(parent)
        self.user = user
        self.actions = actions
        self.title(user.get("displayName") or user.get("sAMAccountName") or "User")
        self.geometry("720x560")
        self.transient(parent)

        body = ctk.CTkScrollableFrame(self)
        body.pack(fill="both", expand=True, padx=10, pady=10)

        def add_row(k: str, v: str) -> None:
            row = ctk.CTkFrame(body, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=k + ":", width=180, anchor="w").pack(side="left")
            ctk.CTkLabel(row, text=v or "", anchor="w").pack(side="left", fill="x", expand=True)

        uac = int(user.get("userAccountControl") or 0)
        disabled = bool(uac & UAC_ACCOUNTDISABLE)
        add_row("Login (sAM)", user.get("sAMAccountName", ""))
        add_row("UPN", user.get("userPrincipalName", ""))
        add_row("Email", user.get("mail", ""))
        add_row("OU", ",".join((user.get("distinguishedName") or "").split(",")[1:]))
        add_row("Status", "Disabled" if disabled else "Enabled")
        add_row("Last logon", _filetime_to_iso(user.get("lastLogonTimestamp")))
        add_row("Created", str(user.get("whenCreated", "")))
        add_row("Modified", str(user.get("whenChanged", "")))
        add_row("Groups", str(len(user.get("memberOf") or [])))

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=10, pady=10)
        ctk.CTkButton(footer, text="Close", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(footer, text="Enable / Disable", command=self._toggle).pack(side="left", padx=4)
        ctk.CTkButton(footer, text="Reset password…", command=self._reset).pack(side="left", padx=4)

    def _toggle(self) -> None:
        if self.actions and self.actions.get("toggle"):
            self.actions["toggle"](self.user)
            self.destroy()

    def _reset(self) -> None:
        pwd = simpledialog.askstring("New password", "Enter the new password:", show="*", parent=self)
        if pwd and ask_confirm(self, "Confirm", "Reset this account's password?"):
            if self.actions and self.actions.get("reset"):
                self.actions["reset"](self.user, pwd)
            self.destroy()
