from __future__ import annotations

import tkinter as tk

import customtkinter as ctk


class EditComputerDialog(ctk.CTkToplevel):
    def __init__(self, parent, connector, computer_name: str, domain_manager, domain_id: str):
        super().__init__(parent)
        self.connector = connector
        self.computer_name = computer_name
        self.domain_manager = domain_manager
        self.domain_id = domain_id
        self.title(f"Edit Computer - {computer_name}")
        self.geometry("700x580")
        self.resizable(True, True)
        self.grab_set()
        self.focus()

        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - 350
        y = (self.winfo_screenheight() // 2) - 290
        self.geometry(f"+{x}+{y}")

        self._computer_data: dict = {}
        self._load_computer_data()
        self._build_ui()

    def _load_computer_data(self) -> None:
        self._computer_data = self.connector.get_computer_by_name(self.computer_name)

    def _build_ui(self) -> None:
        ctk.CTkLabel(
            self,
            text=f"Edit Computer: {self.computer_name}",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(pady=(16, 4), padx=20, anchor="w")

        self.tabview = ctk.CTkTabview(self)
        self.tabview.pack(fill="both", expand=True, padx=16, pady=8)
        self.tabview.add("General")
        self.tabview.add("Location & Owner")
        self.tabview.add("Groups")

        self._build_tab_general()
        self._build_tab_location()
        self._build_tab_groups()

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(4, 16))
        ctk.CTkButton(
            btn_frame, text="Cancel", width=120, fg_color="transparent", border_width=1, command=self.destroy
        ).pack(side="right", padx=6)
        ctk.CTkButton(btn_frame, text="Save Changes", width=140, command=self._on_save).pack(side="right", padx=6)

        self.status_label = ctk.CTkLabel(btn_frame, text="", text_color="gray")
        self.status_label.pack(side="left", padx=6)

    def _field(self, parent, label: str, attr_key: str, placeholder: str = "") -> ctk.CTkEntry:
        ctk.CTkLabel(parent, text=label, anchor="w").pack(fill="x", padx=12, pady=(8, 0))
        entry = ctk.CTkEntry(parent, placeholder_text=placeholder or label)
        entry.pack(fill="x", padx=12, pady=(2, 0))
        value = self._computer_data.get(attr_key, "")
        if value and value != "None":
            entry.insert(0, str(value))
        return entry

    def _build_tab_general(self) -> None:
        tab = self.tabview.tab("General")
        self.entry_name = self._field(tab, "Computer Name (read-only)", "Name")
        self.entry_name.configure(state="disabled")
        self.entry_dns = self._field(tab, "DNS Hostname", "DNSHostName")
        self.entry_description = self._field(tab, "Description", "Description")
        self.entry_os = self._field(tab, "Operating System (read-only)", "OperatingSystem")
        self.entry_os.configure(state="disabled")
        self.entry_os_version = self._field(tab, "OS Version (read-only)", "OperatingSystemVersion")
        self.entry_os_version.configure(state="disabled")

        ctk.CTkLabel(tab, text="Account Status", anchor="w").pack(fill="x", padx=12, pady=(12, 0))
        self.enabled_var = ctk.BooleanVar(value=str(self._computer_data.get("Enabled", True)).lower() == "true")
        ctk.CTkSwitch(tab, text="Enabled", variable=self.enabled_var).pack(anchor="w", padx=14, pady=4)

    def _build_tab_location(self) -> None:
        tab = self.tabview.tab("Location & Owner")
        self.entry_location = self._field(tab, "Physical Location", "Location", "e.g. Building A, Room 101")
        self.entry_managed_by = self._field(
            tab, "Managed By (DN)", "ManagedBy", "e.g. CN=John,OU=TI,DC=domain,DC=local"
        )

        ctk.CTkLabel(tab, text="Current OU (read-only)", anchor="w").pack(fill="x", padx=12, pady=(12, 0))
        ou_entry = ctk.CTkEntry(tab, state="disabled")
        ou_entry.pack(fill="x", padx=12, pady=(2, 0))
        ou_val = self._computer_data.get("OUPath", self._computer_data.get("DistinguishedName", ""))
        ou_entry.configure(state="normal")
        ou_entry.insert(0, str(ou_val))
        ou_entry.configure(state="disabled")

        ctk.CTkLabel(
            tab,
            text='To move to another OU use "Move to OU" button in the toolbar.',
            text_color="gray",
            font=ctk.CTkFont(size=12),
        ).pack(anchor="w", padx=14, pady=6)

    def _build_tab_groups(self) -> None:
        tab = self.tabview.tab("Groups")
        ctk.CTkLabel(tab, text="Member of groups:", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=12, pady=(10, 4))

        frame_current = ctk.CTkFrame(tab)
        frame_current.pack(fill="both", expand=True, padx=12, pady=4)
        self.groups_listbox = tk.Listbox(
            frame_current,
            selectmode="extended",
            bg="#2b2b2b",
            fg="white",
            selectbackground="#1f538d",
            relief="flat",
            font=("Consolas", 11),
        )
        self.groups_listbox.pack(fill="both", expand=True, padx=4, pady=4)

        self._current_groups = self.connector.get_computer_groups(self.computer_name)
        for g in self._current_groups:
            self.groups_listbox.insert("end", g.get("Name", ""))

        add_frame = ctk.CTkFrame(tab, fg_color="transparent")
        add_frame.pack(fill="x", padx=12, pady=6)
        self.entry_add_group = ctk.CTkEntry(add_frame, placeholder_text="Search group name...")
        self.entry_add_group.pack(side="left", fill="x", expand=True, padx=(0, 6))
        ctk.CTkButton(add_frame, text="+ Add", width=80, command=self._on_add_group).pack(side="left", padx=(0, 4))
        ctk.CTkButton(
            add_frame, text="- Remove", width=90, fg_color="#C0392B", hover_color="#A93226", command=self._on_remove_group
        ).pack(side="left")

    def _on_add_group(self) -> None:
        group_name = self.entry_add_group.get().strip()
        if not group_name:
            return
        ok, msg = self.connector.add_computer_to_group(self.computer_name, group_name)
        if ok:
            self.groups_listbox.insert("end", group_name)
            self.entry_add_group.delete(0, "end")
            self.status_label.configure(text=f"Added to {group_name}", text_color="#27AE60")
        else:
            self.status_label.configure(text=f"Error: {msg[:80]}", text_color="#E74C3C")

    def _on_remove_group(self) -> None:
        selected = self.groups_listbox.curselection()
        if not selected:
            return
        group_name = self.groups_listbox.get(selected[0])
        ok, msg = self.connector.remove_computer_from_group(self.computer_name, group_name)
        if ok:
            self.groups_listbox.delete(selected[0])
            self.status_label.configure(text=f"Removed from {group_name}", text_color="#27AE60")
        else:
            self.status_label.configure(text=f"Error: {msg[:80]}", text_color="#E74C3C")

    def _on_save(self) -> None:
        changes: dict = {}
        dns = self.entry_dns.get().strip()
        if dns != str(self._computer_data.get("DNSHostName", "")):
            changes["dnsHostName"] = dns
        desc = self.entry_description.get().strip()
        if desc != str(self._computer_data.get("Description", "") or ""):
            changes["description"] = desc
        loc = self.entry_location.get().strip()
        if loc != str(self._computer_data.get("Location", "") or ""):
            changes["location"] = loc
        managed = self.entry_managed_by.get().strip()
        if managed != str(self._computer_data.get("ManagedBy", "") or ""):
            changes["managedBy"] = managed

        current_enabled = str(self._computer_data.get("Enabled", True)).lower() == "true"
        if self.enabled_var.get() != current_enabled:
            changes["enabled"] = self.enabled_var.get()

        if not changes:
            self.status_label.configure(text="No changes to save.", text_color="gray")
            return

        self.status_label.configure(text="Saving...", text_color="gray")
        self.update()
        ok, msg = self.connector.modify_computer(self.computer_name, changes)
        if ok:
            self.status_label.configure(text="Saved successfully.", text_color="#27AE60")
            self.after(1200, self.destroy)
        else:
            self.status_label.configure(text=f"Error: {msg[:100]}", text_color="#E74C3C")
