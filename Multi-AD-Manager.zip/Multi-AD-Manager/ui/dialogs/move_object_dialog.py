"""Pick target OU from tree to move an AD object."""

from __future__ import annotations

import threading
from typing import Callable

import customtkinter as ctk
from tkinter import ttk

from ui.dialogs.confirm_dialog import ask_confirm


def _insert_ou_tree(tree: ttk.Treeview, parent: str, node: dict) -> None:
    dn = node.get("dn", "")
    name = node.get("name") or dn
    iid = tree.insert(parent, "end", text=f"📁 {name}", values=(dn,), open=False)
    for ch in node.get("children") or []:
        _insert_ou_tree(tree, iid, ch)


class MoveObjectDialog(ctk.CTkToplevel):
    def __init__(
        self,
        parent,
        *,
        title: str,
        current_dn: str,
        load_tree: Callable[[], list[dict]],
        on_move: Callable[[str], None],
    ) -> None:
        super().__init__(parent)
        self._on_move = on_move
        self._current = (current_dn or "").upper()
        self.title(title)
        self.geometry("520x480")
        self.transient(parent)

        ctk.CTkLabel(self, text="Select the destination OU and click Move.", anchor="w").pack(
            fill="x", padx=10, pady=(8, 4)
        )

        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=10, pady=4)
        self.tree = ttk.Treeview(frame, columns=("dn",), show="tree")
        self.tree.column("dn", width=0, stretch=False)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self._hint = ctk.CTkLabel(self, text="Loading OUs…", anchor="w")
        self._hint.pack(fill="x", padx=10, pady=4)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(foot, text="Move", command=self._do_move).pack(side="right", padx=4)

        threading.Thread(target=self._load, args=(load_tree,), daemon=True).start()

    def _load(self, load_tree: Callable[[], list[dict]]) -> None:
        try:
            roots = load_tree()
        except Exception:
            roots = []

        def done() -> None:
            for i in self.tree.get_children():
                self.tree.delete(i)
            for root in roots:
                _insert_ou_tree(self.tree, "", root)
            self._walk_highlight("", self._current)
            self._hint.configure(text="Current OU is highlighted in the tree when visible.")

        self.after(0, done)

    def _walk_highlight(self, parent: str, target_upper: str) -> None:
        for iid in self.tree.get_children(parent):
            vals = self.tree.item(iid, "values")
            dn = (vals[0] if vals else "") or ""
            if dn.upper() == target_upper:
                self.tree.item(iid, text="📁 ➤ " + self.tree.item(iid, "text").replace("📁 ", ""))
            self._walk_highlight(iid, target_upper)

    def _do_move(self) -> None:
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        target = vals[0] if vals else ""
        if not target:
            return
        if not ask_confirm(self, "Move", f"Move object to:\n{target} ?"):
            return
        self._on_move(target)
        self.destroy()
