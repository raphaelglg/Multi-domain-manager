"""Edit AD group attributes and members."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

import customtkinter as ctk

from core.group_manager import GroupManager
from ui.dialogs.user_pick_dialog import UserPickDialog

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class EditGroupDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, app: "AdManagerApp", domain_id: str, group: dict, on_saved) -> None:
        super().__init__(parent)
        self.app = app
        self._domain_id = domain_id
        self._g = dict(group)
        self._on_saved = on_saved
        self._gid = str(group.get("distinguishedName") or group.get("name", ""))
        self.title(f"Edit group — {group.get('name', '')}")
        self.geometry("700x520")
        self.transient(parent)

        tabs = ctk.CTkTabview(self)
        tabs.pack(fill="both", expand=True, padx=10, pady=8)
        t1 = tabs.add("General")
        t2 = tabs.add("Members")
        t3 = tabs.add("Member of")

        self._f_name = self._row(t1, "Name")
        self._f_desc = self._row(t1, "Description", multiline=True)
        row_sc = ctk.CTkFrame(t1, fg_color="transparent")
        row_sc.pack(fill="x", pady=4)
        ctk.CTkLabel(row_sc, text="Scope", width=140, anchor="w").pack(side="left")
        self._scope = ctk.CTkOptionMenu(row_sc, values=["DomainLocal", "Global", "Universal"])
        self._scope.pack(side="left", fill="x", expand=True, padx=4)
        row_cat = ctk.CTkFrame(t1, fg_color="transparent")
        row_cat.pack(fill="x", pady=4)
        ctk.CTkLabel(row_cat, text="Category", width=140, anchor="w").pack(side="left")
        self._cat = ctk.CTkOptionMenu(row_cat, values=["Security", "Distribution"])
        self._cat.pack(side="left", fill="x", expand=True, padx=4)

        self._f_name.insert(0, str(group.get("name") or group.get("cn", "")))
        desc = str(group.get("description", ""))
        self._f_desc.insert("1.0", desc)
        self._scope.set(str(group.get("groupScope") or self._scope_from_type(group.get("groupType"))))
        self._cat.set(str(group.get("groupCategory") or self._cat_from_type(group.get("groupType"))))

        self._mem_list = ctk.CTkScrollableFrame(t2, height=300)
        self._mem_list.pack(fill="both", expand=True, padx=4, pady=4)
        bt = ctk.CTkFrame(t2, fg_color="transparent")
        bt.pack(fill="x", pady=4)
        ctk.CTkButton(bt, text="Add user…", command=self._add_member).pack(side="left", padx=4)

        self._parent_list = ctk.CTkScrollableFrame(t3, height=320)
        self._parent_list.pack(fill="both", expand=True, padx=4, pady=4)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(foot, text="Save attributes", command=self._save_attrs).pack(side="right", padx=4)

        self._reload_members()
        threading.Thread(target=self._reload_parents, daemon=True).start()

    def _scope_from_type(self, gt: object) -> str:
        try:
            gti = int(str(gt))
            kind = gti & 0x00000007
            return {2: "Global", 4: "DomainLocal", 8: "Universal"}.get(kind, "Global")
        except Exception:
            return "Global"

    def _cat_from_type(self, gt: object) -> str:
        try:
            gti = int(str(gt))
            return "Security" if gti & 0x80000000 else "Distribution"
        except Exception:
            return "Security"

    def _row(self, parent, label: str, *, multiline: bool = False):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=3)
        ctk.CTkLabel(row, text=label, width=140, anchor="w").pack(side="left")
        if multiline:
            w = ctk.CTkTextbox(row, height=48)
            w.pack(side="left", fill="x", expand=True, padx=4)
            return w
        w = ctk.CTkEntry(row)
        w.pack(side="left", fill="x", expand=True, padx=4)
        return w

    def _reload_members(self) -> None:
        for w in self._mem_list.winfo_children():
            w.destroy()

        def work() -> list[dict]:
            try:
                con = self.app.dm.get_connector(self._domain_id)
                return con.get_group_members(self._gid, recursive=False)
            except Exception:
                return []

        def done(rows: list[dict]) -> None:
            for m in rows:
                dn = m.get("distinguishedName", "")
                label = m.get("cn") or m.get("sAMAccountName") or dn
                row = ctk.CTkFrame(self._mem_list, fg_color="transparent")
                row.pack(fill="x", pady=1)
                ctk.CTkLabel(row, text=label, anchor="w").pack(side="left", fill="x", expand=True)
                ocs = [str(x).lower() for x in (m.get("objectClass") or [])]
                if "user" in ocs:
                    ctk.CTkButton(
                        row,
                        text="−",
                        width=28,
                        command=lambda d=dn: self._remove_member(d),
                    ).pack(side="right")

        def runner() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=runner, daemon=True).start()

    def _reload_parents(self) -> None:
        def work() -> list[dict]:
            try:
                con = self.app.dm.get_connector(self._domain_id)
                return con.get_group_parent_groups(self._gid)
            except Exception:
                return []

        def done(rows: list[dict]) -> None:
            for w in self._parent_list.winfo_children():
                w.destroy()
            for p in rows:
                ctk.CTkLabel(self._parent_list, text=p.get("Name") or p.get("DistinguishedName", ""), anchor="w").pack(
                    fill="x", pady=2
                )

        def runner2() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=runner2, daemon=True).start()

    def _remove_member(self, user_dn: str) -> None:
        if not self.app.ensure_online(self._domain_id):
            return
        gm = GroupManager(self.app.dm.get_connector(self._domain_id), audit=self.app.make_audit_cb(self._domain_id))
        gm.remove_member(user_dn, self._gid)
        self._reload_members()

    def _add_member(self) -> None:
        def on_pick(u: dict) -> None:
            if not self.app.ensure_online(self._domain_id):
                return
            gm = GroupManager(self.app.dm.get_connector(self._domain_id), audit=self.app.make_audit_cb(self._domain_id))
            gm.add_member(u.get("distinguishedName", ""), self._gid)
            self._reload_members()

        UserPickDialog(self, app=self.app, domain_id=self._domain_id, on_pick=on_pick)

    def _save_attrs(self) -> None:
        if not self.app.ensure_online(self._domain_id):
            return
        gm = GroupManager(self.app.dm.get_connector(self._domain_id), audit=self.app.make_audit_cb(self._domain_id))
        changes: dict = {}
        nm = self._f_name.get().strip()
        if nm and nm != str(self._g.get("name", "")):
            changes["name"] = nm
        desc = self._f_desc.get("1.0", "end").strip()
        if desc != str(self._g.get("description", "")):
            changes["description"] = desc
        if self._scope.get() != str(self._g.get("groupScope") or ""):
            changes["groupScope"] = self._scope.get()
        if self._cat.get() != str(self._g.get("groupCategory") or ""):
            changes["groupCategory"] = self._cat.get()
        if changes:
            ok, msg = gm.modify_group(self._gid, changes)
            if not ok:
                from ui.toast import show_toast

                show_toast(self, msg[:240])
                return
        self._on_saved()
        from ui.toast import show_toast

        show_toast(self, "Group updated.")
        self.destroy()
