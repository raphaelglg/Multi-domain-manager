"""Reset AD user password with complexity hint and optional must-change."""

from __future__ import annotations

import re
from typing import Callable

import customtkinter as ctk

from ui.dialogs.confirm_dialog import ask_confirm


def _password_score(pwd: str) -> tuple[int, str]:
    score = 0
    hints: list[str] = []
    if len(pwd) >= 8:
        score += 1
    else:
        hints.append("min. 8 characters")
    if re.search(r"[A-Z]", pwd):
        score += 1
    else:
        hints.append("uppercase letter")
    if re.search(r"[a-z]", pwd):
        score += 1
    else:
        hints.append("lowercase letter")
    if re.search(r"\d", pwd):
        score += 1
    else:
        hints.append("digit")
    if re.search(r"[^A-Za-z0-9]", pwd):
        score += 1
    else:
        hints.append("symbol")
    label = "Strong" if score >= 5 else "Medium" if score >= 3 else "Weak"
    detail = ", missing: " + ", ".join(hints) if hints else ""
    return score, f"{label}{detail}"


class ResetPasswordDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, display_name: str, on_confirm: Callable[[str, bool], None]) -> None:
        super().__init__(parent)
        self._on_confirm = on_confirm
        self.title(f"Reset password — {display_name}")
        self.geometry("440x320")
        self.transient(parent)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=14, pady=12)

        self.p1 = ctk.CTkEntry(body, placeholder_text="New password", show="*")
        self.p1.pack(fill="x", pady=4)
        self.p2 = ctk.CTkEntry(body, placeholder_text="Confirm password", show="*")
        self.p2.pack(fill="x", pady=4)

        self._show = False

        def toggle_show() -> None:
            self._show = not self._show
            vis = "" if self._show else "*"
            self.p1.configure(show=vis)
            self.p2.configure(show=vis)
            btn_show.configure(text="Hide" if self._show else "Show")

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", pady=4)
        btn_show = ctk.CTkButton(row, text="Show", width=100, command=toggle_show)
        btn_show.pack(side="left")

        self.must_change = ctk.CTkCheckBox(body, text="User must change password at next logon")
        self.must_change.pack(anchor="w", pady=8)

        self.lbl = ctk.CTkLabel(body, text="", anchor="w", justify="left")
        self.lbl.pack(fill="x", pady=6)
        self.p1.bind("<KeyRelease>", lambda _e: self._update_meter())
        self.p2.bind("<KeyRelease>", lambda _e: self._update_meter())
        self._update_meter()

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=14, pady=10)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(foot, text="Confirm reset", command=self._submit).pack(side="right", padx=4)

    def _update_meter(self) -> None:
        a, b = self.p1.get(), self.p2.get()
        if not a:
            self.lbl.configure(text="")
            return
        sc, msg = _password_score(a)
        warn = " — passwords do not match" if b and a != b else ""
        self.lbl.configure(text=f"Strength ({sc}/5): {msg}{warn}")

    def _submit(self) -> None:
        a, b = self.p1.get(), self.p2.get()
        if len(a) < 8:
            self.lbl.configure(text="Password is too short (min. 8).")
            return
        if a != b:
            self.lbl.configure(text="Confirmation does not match.")
            return
        if not ask_confirm(self, "Confirm", "Reset this account's password?"):
            return
        self._on_confirm(a, bool(self.must_change.get()))
        self.destroy()
