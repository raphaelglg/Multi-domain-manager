"""Add / edit domain configuration (multi-transport: WinRM, LDAP, SSH, local PS, ADWS)."""

from __future__ import annotations

import threading
import uuid
from pathlib import Path
from tkinter import messagebox
from typing import Any

import customtkinter as ctk

from core.transport_factory import get_connector
from utils import crypto_vault
from utils.audit_logger import append_error_log

TRANSPORT_OPTIONS: list[tuple[str, str]] = [
    ("winrm_http", "WinRM HTTP (port 5985)"),
    ("winrm_https", "WinRM HTTPS (port 5986)"),
    ("winrm_custom", "WinRM (custom port)"),
    ("ldap", "LDAP (port 389)"),
    ("ldaps", "LDAPS (port 636)"),
    ("ldap_starttls", "LDAP with StartTLS"),
    ("ldap_custom", "LDAP / LDAPS (custom port)"),
    ("ssh_ldap_tunnel", "SSH tunnel → LDAP"),
    ("ssh_powershell", "SSH → PowerShell"),
    ("powershell_local", "Local PowerShell (this machine)"),
    ("adws", "ADWS (port 9389)"),
]


class AddDomainDialog(ctk.CTkToplevel):
    def __init__(
        self,
        parent,
        *,
        project_root: Path,
        master_key: bytes,
        existing: dict | None = None,
        on_saved=None,
    ) -> None:
        super().__init__(parent)
        self._winrm_rows: list[dict[str, Any]] = []
        self._ldap_rows: list[dict[str, Any]] = []
        self._adws_rows: list[dict[str, Any]] = []
        self._ui_ready = False
        self.project_root = project_root
        self.master_key = master_key
        self.existing = existing
        self.on_saved = on_saved
        self.result: dict | None = None

        self.title("Edit Domain Connection" if existing else "Add Domain Connection")
        self.geometry("820x820")
        self.transient(parent)
        self.grab_set()
        self.status = ctk.CTkLabel(self, text="", anchor="w")

        scroll = ctk.CTkScrollableFrame(self, height=640)
        scroll.pack(fill="both", expand=True, padx=8, pady=4)

        self.client = ctk.CTkEntry(scroll, placeholder_text="Client name (e.g. Contoso)")
        self.client.pack(fill="x", padx=4, pady=4)
        self.fqdn = ctk.CTkEntry(scroll, placeholder_text="Domain FQDN (e.g. corp.example.local)")
        self.fqdn.pack(fill="x", padx=4, pady=4)
        self.base_dn = ctk.CTkEntry(scroll, placeholder_text="Base DN (e.g. DC=corp,DC=example,DC=local)")
        self.base_dn.pack(fill="x", padx=4, pady=4)
        self.fqdn.bind("<FocusOut>", self._auto_fill_base_dn)
        self.fqdn.bind("<Return>", self._auto_fill_base_dn)

        self._transport_keys = [x[0] for x in TRANSPORT_OPTIONS]
        self._transport_labels = [x[1] for x in TRANSPORT_OPTIONS]
        self.transport = ctk.CTkOptionMenu(scroll, values=self._transport_labels, command=lambda _v: self._on_transport_change())
        self.transport.pack(fill="x", padx=4, pady=6)
        ctk.CTkLabel(scroll, text="Connection method", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=4)

        # --- WinRM ---
        self._frm_winrm = ctk.CTkFrame(scroll, fg_color=("gray92", "gray18"))
        self._frm_winrm.pack(fill="x", padx=4, pady=4)
        ctk.CTkLabel(self._frm_winrm, text="WinRM", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=6, pady=4)
        self.winrm_servers = ctk.CTkScrollableFrame(self._frm_winrm, label_text="Domain controllers", height=120)
        self.winrm_servers.pack(fill="x", padx=6, pady=4)
        wr_bt = ctk.CTkFrame(self._frm_winrm, fg_color="transparent")
        wr_bt.pack(fill="x", padx=6)
        ctk.CTkButton(wr_bt, text="+ Add DC", width=120, command=lambda: self._add_winrm_row()).pack(side="left", padx=2)
        self.winrm_https = ctk.CTkSwitch(self._frm_winrm, text="HTTPS / TLS (5986)")
        self.winrm_https.pack(anchor="w", padx=8, pady=2)
        self.winrm_validate = ctk.CTkSwitch(self._frm_winrm, text="Validate TLS certificate (HTTPS)")
        self.winrm_validate.pack(anchor="w", padx=8, pady=2)
        self.winrm_validate.deselect()
        self.winrm_user = ctk.CTkEntry(self._frm_winrm, placeholder_text="WinRM user (DOMAIN\\user or user@domain)")
        self.winrm_user.pack(fill="x", padx=8, pady=4)
        self.winrm_pass = ctk.CTkEntry(self._frm_winrm, placeholder_text="WinRM password (leave blank to keep saved)", show="*")
        self.winrm_pass.pack(fill="x", padx=8, pady=4)

        # --- LDAP ---
        self._frm_ldap = ctk.CTkFrame(scroll, fg_color=("gray92", "gray18"))
        self._frm_ldap.pack(fill="x", padx=4, pady=4)
        ctk.CTkLabel(self._frm_ldap, text="LDAP", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=6, pady=4)
        self.ldap_servers = ctk.CTkScrollableFrame(self._frm_ldap, label_text="LDAP servers", height=100)
        self.ldap_servers.pack(fill="x", padx=6, pady=4)
        ld_bt = ctk.CTkFrame(self._frm_ldap, fg_color="transparent")
        ld_bt.pack(fill="x", padx=6)
        ctk.CTkButton(ld_bt, text="+ Add server", width=120, command=lambda: self._add_ldap_row()).pack(side="left", padx=2)
        self.ldap_custom_ssl = ctk.CTkSwitch(self._frm_ldap, text="Use SSL on custom port (LDAPS-style)")
        self.ldap_custom_ssl.pack(anchor="w", padx=8, pady=2)
        self.ldap_custom_tls = ctk.CTkSwitch(self._frm_ldap, text="Use StartTLS (custom LDAP only)")
        self.ldap_custom_tls.pack(anchor="w", padx=8, pady=2)
        self.ldap_validate = ctk.CTkSwitch(self._frm_ldap, text="Validate LDAPS / StartTLS certificate")
        self.ldap_validate.pack(anchor="w", padx=8, pady=2)
        self.ldap_bind = ctk.CTkEntry(self._frm_ldap, placeholder_text="Bind user (full DN or DOMAIN\\user)")
        self.ldap_bind.pack(fill="x", padx=8, pady=4)
        self.ldap_pass = ctk.CTkEntry(self._frm_ldap, placeholder_text="LDAP password", show="*")
        self.ldap_pass.pack(fill="x", padx=8, pady=4)
        ctk.CTkLabel(
            self._frm_ldap,
            text="Note: Creating users or resetting passwords over LDAP requires LDAPS (636) or a signing-safe channel.",
            wraplength=720,
            justify="left",
            font=ctk.CTkFont(size=11),
        ).pack(fill="x", padx=8, pady=4)

        # --- SSH ---
        self._frm_ssh = ctk.CTkFrame(scroll, fg_color=("gray92", "gray18"))
        self._frm_ssh.pack(fill="x", padx=4, pady=4)
        ctk.CTkLabel(self._frm_ssh, text="SSH", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=6, pady=4)
        self.ssh_host = ctk.CTkEntry(self._frm_ssh, placeholder_text="SSH host (bastion or DC)")
        self.ssh_host.pack(fill="x", padx=8, pady=2)
        self.ssh_port = ctk.CTkEntry(self._frm_ssh, placeholder_text="SSH port (22)")
        self.ssh_port.insert(0, "22")
        self.ssh_port.pack(fill="x", padx=8, pady=2)
        self.ssh_user = ctk.CTkEntry(self._frm_ssh, placeholder_text="SSH username")
        self.ssh_user.pack(fill="x", padx=8, pady=2)
        self.ssh_pass = ctk.CTkEntry(self._frm_ssh, placeholder_text="SSH password", show="*")
        self.ssh_pass.pack(fill="x", padx=8, pady=2)
        self.ssh_key = ctk.CTkEntry(self._frm_ssh, placeholder_text="Private key path (.pem), optional instead of password")
        self.ssh_key.pack(fill="x", padx=8, pady=2)
        self._frm_tunnel = ctk.CTkFrame(self._frm_ssh, fg_color="transparent")
        self._frm_tunnel.pack(fill="x", padx=8, pady=4)
        ctk.CTkLabel(self._frm_tunnel, text="SSH tunnel → LDAP").pack(anchor="w")
        self.tunnel_local = ctk.CTkEntry(self._frm_tunnel, placeholder_text="Local tunnel port (e.g. 13890)")
        self.tunnel_local.insert(0, "13890")
        self.tunnel_local.pack(fill="x", pady=2)
        self.tunnel_rhost = ctk.CTkEntry(self._frm_tunnel, placeholder_text="Remote LDAP host (usually 127.0.0.1 on DC)")
        self.tunnel_rhost.insert(0, "127.0.0.1")
        self.tunnel_rhost.pack(fill="x", pady=2)
        self.tunnel_rport = ctk.CTkEntry(self._frm_tunnel, placeholder_text="Remote LDAP port (389)")
        self.tunnel_rport.insert(0, "389")
        self.tunnel_rport.pack(fill="x", pady=2)

        # --- Local PS ---
        self._frm_local = ctk.CTkFrame(scroll, fg_color=("gray92", "gray18"))
        self._frm_local.pack(fill="x", padx=4, pady=4)
        ctk.CTkLabel(self._frm_local, text="Local PowerShell", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=6, pady=4)
        ctk.CTkLabel(
            self._frm_local,
            text="Uses the current Windows session credentials. Requires RSAT / ActiveDirectory module and network reachability to the domain. No stored password for this mode.",
            wraplength=720,
            justify="left",
            font=ctk.CTkFont(size=11),
        ).pack(fill="x", padx=8, pady=4)

        # --- ADWS ---
        self._frm_adws = ctk.CTkFrame(scroll, fg_color=("gray92", "gray18"))
        self._frm_adws.pack(fill="x", padx=4, pady=4)
        ctk.CTkLabel(self._frm_adws, text="ADWS", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=6, pady=4)
        self.adws_servers = ctk.CTkScrollableFrame(self._frm_adws, label_text="Controllers (ADWS + WinRM)", height=100)
        self.adws_servers.pack(fill="x", padx=6, pady=4)
        ad_bt = ctk.CTkFrame(self._frm_adws, fg_color="transparent")
        ad_bt.pack(fill="x", padx=6)
        ctk.CTkButton(ad_bt, text="+ Add DC", width=120, command=lambda: self._add_adws_row()).pack(side="left", padx=2)
        self.adws_user = ctk.CTkEntry(self._frm_adws, placeholder_text="User (same account used for WinRM to 5985)")
        self.adws_user.pack(fill="x", padx=8, pady=4)
        self.adws_pass = ctk.CTkEntry(self._frm_adws, placeholder_text="Password", show="*")
        self.adws_pass.pack(fill="x", padx=8, pady=4)
        ctk.CTkLabel(
            self._frm_adws,
            text="ADWS uses TCP 9389 on the DC. WinRM (5985/5986) is still used to run PowerShell; both must be reachable.",
            wraplength=720,
            justify="left",
            font=ctk.CTkFont(size=11),
        ).pack(fill="x", padx=8, pady=4)

        self.color = ctk.CTkEntry(scroll, placeholder_text="Tag color (#RRGGBB)")
        self.color.pack(fill="x", padx=4, pady=6)
        self.color.insert(0, "#4A90D9")

        self.status.pack(fill="x", padx=12, pady=4)
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=12, pady=8)
        ctk.CTkButton(footer, text="Test connection", command=self._test).pack(side="left", padx=4)
        ctk.CTkButton(footer, text="Save", command=self._save).pack(side="right", padx=4)
        ctk.CTkButton(footer, text="Close", command=self.destroy).pack(side="right", padx=4)

        if existing:
            self._load_existing(existing)
        else:
            self._add_winrm_row("192.168.1.10", 5985, "Primary DC")
            self._add_ldap_row("192.168.1.10", 389, "DC")
            self._add_adws_row("192.168.1.10", 9389, 5985, "DC01")
        self._on_transport_change()
        self._ui_ready = True

    def _transport_key(self) -> str:
        label = self.transport.get()
        try:
            i = self._transport_labels.index(label)
            return self._transport_keys[i]
        except ValueError:
            return "winrm_http"

    def _set_transport_key(self, key: str) -> None:
        if key in self._transport_keys:
            i = self._transport_keys.index(key)
            self.transport.set(self._transport_labels[i])

    def _generated_base_dn_from_fqdn(self) -> str:
        domain = self.fqdn.get().strip().strip(".")
        if not domain:
            return ""
        parts = [p for p in domain.split(".") if p]
        return ",".join([f"DC={p}" for p in parts]) if parts else ""

    def _auto_fill_base_dn(self, _event=None) -> None:
        generated = self._generated_base_dn_from_fqdn()
        if not generated:
            return
        current = self.base_dn.get().strip()
        if not current or "," not in current:
            self.base_dn.delete(0, "end")
            self.base_dn.insert(0, generated)

    def _validate_base_dn(self) -> tuple[bool, str]:
        base_dn = self.base_dn.get().strip()
        if not base_dn:
            return False, "Base DN is required."
        if "," not in base_dn:
            suggested = self._generated_base_dn_from_fqdn()
            if suggested:
                self.base_dn.delete(0, "end")
                self.base_dn.insert(0, suggested)
                return True, "OK"
            return (
                False,
                f"Invalid Base DN: '{base_dn}'. Use format like DC=domain,DC=local.",
            )
        for part in [p.strip() for p in base_dn.split(",") if p.strip()]:
            up = part.upper()
            if not (up.startswith("DC=") or up.startswith("OU=") or up.startswith("CN=")):
                return False, f"Invalid Base DN part: '{part}'. Each part must start with DC=, OU=, or CN=."
        return True, "OK"

    def _on_transport_change(self) -> None:
        t = self._transport_key()
        self._frm_tunnel.pack_forget()
        for f in (
            self._frm_winrm,
            self._frm_ldap,
            self._frm_ssh,
            self._frm_local,
            self._frm_adws,
        ):
            f.pack_forget()
        if t in ("winrm_http", "winrm_https", "winrm_custom"):
            self._frm_winrm.pack(fill="x", padx=4, pady=4)
            if t == "winrm_https":
                self.winrm_https.select()
            elif t == "winrm_http":
                self.winrm_https.deselect()
        if t in ("ldap", "ldaps", "ldap_starttls", "ldap_custom"):
            self._frm_ldap.pack(fill="x", padx=4, pady=4)
        if t in ("ssh_ldap_tunnel", "ssh_powershell"):
            self._frm_ssh.pack(fill="x", padx=4, pady=4)
            if t == "ssh_ldap_tunnel":
                self._frm_tunnel.pack(fill="x", padx=8, pady=4)
                self._frm_ldap.pack(fill="x", padx=4, pady=4)
        if t == "powershell_local":
            self._frm_local.pack(fill="x", padx=4, pady=4)
        if t == "adws":
            self._frm_adws.pack(fill="x", padx=4, pady=4)

    def _add_winrm_row(self, host: str = "", port: int = 0, label: str = "") -> None:
        row = ctk.CTkFrame(self.winrm_servers, fg_color="transparent")
        row.pack(fill="x", pady=2)
        h = ctk.CTkEntry(row, placeholder_text="Host", width=200)
        h.insert(0, host)
        h.pack(side="left", padx=2)
        use_https = bool(self.winrm_https.get()) if hasattr(self, "winrm_https") else False
        default_p = 5986 if use_https else 5985
        pe = ctk.CTkEntry(row, placeholder_text="Port", width=70)
        pe.insert(0, str(port or default_p))
        pe.pack(side="left", padx=2)
        lb = ctk.CTkEntry(row, placeholder_text="Label", width=100)
        lb.insert(0, label)
        lb.pack(side="left", padx=2)

        def remove() -> None:
            row.destroy()
            self._winrm_rows[:] = [r for r in self._winrm_rows if r["frame"] is not row]

        ctk.CTkButton(row, text="–", width=28, command=remove).pack(side="left", padx=2)
        self._winrm_rows.append({"frame": row, "host": h, "port": pe, "label": lb})

    def _add_ldap_row(self, host: str = "", port: int = 389, label: str = "") -> None:
        row = ctk.CTkFrame(self.ldap_servers, fg_color="transparent")
        row.pack(fill="x", pady=2)
        h = ctk.CTkEntry(row, placeholder_text="Host", width=200)
        h.insert(0, host)
        h.pack(side="left", padx=2)
        pe = ctk.CTkEntry(row, placeholder_text="Port", width=70)
        pe.insert(0, str(port))
        pe.pack(side="left", padx=2)
        lb = ctk.CTkEntry(row, placeholder_text="Label", width=100)
        lb.insert(0, label)
        lb.pack(side="left", padx=2)

        def remove() -> None:
            row.destroy()
            self._ldap_rows[:] = [r for r in self._ldap_rows if r["frame"] is not row]

        ctk.CTkButton(row, text="–", width=28, command=remove).pack(side="left", padx=2)
        self._ldap_rows.append({"frame": row, "host": h, "port": pe, "label": lb})

    def _add_adws_row(self, host: str = "", adws_port: int = 9389, winrm_port: int = 5985, label: str = "") -> None:
        row = ctk.CTkFrame(self.adws_servers, fg_color="transparent")
        row.pack(fill="x", pady=2)
        h = ctk.CTkEntry(row, placeholder_text="Host", width=160)
        h.insert(0, host)
        h.pack(side="left", padx=2)
        p9389 = ctk.CTkEntry(row, placeholder_text="ADWS", width=56)
        p9389.insert(0, str(adws_port))
        p9389.pack(side="left", padx=2)
        p5985 = ctk.CTkEntry(row, placeholder_text="WinRM", width=56)
        p5985.insert(0, str(winrm_port))
        p5985.pack(side="left", padx=2)
        lb = ctk.CTkEntry(row, placeholder_text="Label", width=90)
        lb.insert(0, label)
        lb.pack(side="left", padx=2)

        def remove() -> None:
            row.destroy()
            self._adws_rows[:] = [r for r in self._adws_rows if r["frame"] is not row]

        ctk.CTkButton(row, text="–", width=28, command=remove).pack(side="left", padx=2)
        self._adws_rows.append({"frame": row, "host": h, "port_adws": p9389, "port_winrm": p5985, "label": lb})

    def _collect_winrm_servers(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        use_https = bool(self.winrm_https.get())
        for r in self._winrm_rows:
            try:
                port = int(r["port"].get().strip() or ("5986" if use_https else "5985"))
            except ValueError:
                port = 5986 if use_https else 5985
            host = r["host"].get().strip()
            if host:
                out.append({"host": host, "port": port, "label": r["label"].get().strip() or host})
        return out

    def _collect_ldap_servers(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for r in self._ldap_rows:
            try:
                port = int(r["port"].get().strip() or "389")
            except ValueError:
                port = 389
            host = r["host"].get().strip()
            if host:
                out.append({"host": host, "port": port, "label": r["label"].get().strip() or host})
        return out

    def _collect_adws_servers(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for r in self._adws_rows:
            try:
                p_ad = int(r["port_adws"].get().strip() or "9389")
                p_wr = int(r["port_winrm"].get().strip() or "5985")
            except ValueError:
                p_ad, p_wr = 9389, 5985
            host = r["host"].get().strip()
            if host:
                out.append(
                    {
                        "host": host,
                        "port": p_ad,
                        "winrm_port": p_wr,
                        "label": r["label"].get().strip() or host,
                    }
                )
        return out

    def _effective_winrm_password(self) -> str:
        p = self.winrm_pass.get()
        if p:
            return p
        ex = self.existing or {}
        for enc in (
            ex.get("winrm_password_encrypted"),
            ex.get("bind_password_encrypted"),
            (ex.get("winrm") or {}).get("password_encrypted"),
        ):
            if enc:
                try:
                    return crypto_vault.decrypt_secret(enc, self.master_key)
                except Exception:
                    pass
        return ""

    def _effective_ldap_password(self) -> str:
        p = self.ldap_pass.get()
        if p:
            return p
        ld = (self.existing or {}).get("ldap") or {}
        enc = ld.get("password_encrypted") or (self.existing or {}).get("bind_password_encrypted")
        if enc:
            try:
                return crypto_vault.decrypt_secret(enc, self.master_key)
            except Exception:
                return ""
        return ""

    def _effective_ssh_password(self) -> str:
        p = self.ssh_pass.get()
        if p:
            return p
        sh = (self.existing or {}).get("ssh") or {}
        enc = sh.get("password_encrypted")
        if enc:
            try:
                return crypto_vault.decrypt_secret(enc, self.master_key)
            except Exception:
                return ""
        return ""

    def _effective_adws_password(self) -> str:
        p = self.adws_pass.get()
        if p:
            return p
        ad = (self.existing or {}).get("adws") or {}
        enc = ad.get("password_encrypted") or (self.existing or {}).get("winrm_password_encrypted")
        if enc:
            try:
                return crypto_vault.decrypt_secret(enc, self.master_key)
            except Exception:
                return ""
        return ""

    def _load_existing(self, d: dict) -> None:
        self.client.insert(0, d.get("client_name", ""))
        self.fqdn.insert(0, d.get("domain_name", ""))
        self.base_dn.insert(0, d.get("base_dn", ""))
        self._set_transport_key(str(d.get("transport") or "winrm_http"))
        wr = d.get("winrm") or {}
        user = wr.get("user") or d.get("winrm_user") or d.get("bind_user", "")
        self.winrm_user.insert(0, user)
        if wr.get("use_https") or d.get("use_https"):
            self.winrm_https.select()
        else:
            self.winrm_https.deselect()
        if wr.get("validate_ssl") or d.get("validate_ssl"):
            self.winrm_validate.select()
        else:
            self.winrm_validate.deselect()
        for w in self.winrm_servers.winfo_children():
            w.destroy()
        self._winrm_rows.clear()
        for s in wr.get("servers") or d.get("dc_servers") or []:
            self._add_winrm_row(s.get("host", ""), int(s.get("port") or s.get("port_winrm") or 5985), s.get("label", ""))
        ld = d.get("ldap") or {}
        for w in self.ldap_servers.winfo_children():
            w.destroy()
        self._ldap_rows.clear()
        for s in ld.get("servers") or []:
            self._add_ldap_row(s.get("host", ""), int(s.get("port", 389)), s.get("label", ""))
        self.ldap_bind.insert(0, ld.get("bind_user") or d.get("bind_user", ""))
        if ld.get("use_ssl"):
            self.ldap_custom_ssl.select()
        if ld.get("use_start_tls"):
            self.ldap_custom_tls.select()
        if ld.get("validate_ssl"):
            self.ldap_validate.select()
        sh = d.get("ssh") or {}
        self.ssh_host.insert(0, sh.get("host", ""))
        self.ssh_port.delete(0, "end")
        self.ssh_port.insert(0, str(sh.get("port", 22)))
        self.ssh_user.insert(0, sh.get("user", ""))
        self.ssh_key.insert(0, sh.get("private_key_path", ""))
        self.tunnel_local.delete(0, "end")
        self.tunnel_local.insert(0, str(sh.get("tunnel_local_port", 13890)))
        self.tunnel_rhost.delete(0, "end")
        self.tunnel_rhost.insert(0, str(sh.get("tunnel_remote_host", "127.0.0.1")))
        self.tunnel_rport.delete(0, "end")
        self.tunnel_rport.insert(0, str(sh.get("tunnel_remote_port", 389)))
        ad = d.get("adws") or {}
        for w in self.adws_servers.winfo_children():
            w.destroy()
        self._adws_rows.clear()
        for s in ad.get("servers") or []:
            self._add_adws_row(
                s.get("host", ""),
                int(s.get("port", 9389)),
                int(s.get("winrm_port", 5985)),
                s.get("label", ""),
            )
        self.adws_user.insert(0, ad.get("user") or user)
        self.color.delete(0, "end")
        self.color.insert(0, d.get("color_tag", "#4A90D9"))

    def _build_payload(self, *, for_test: bool) -> dict[str, Any]:
        t = self._transport_key()
        did = (self.existing or {}).get("id") or str(uuid.uuid4())
        base: dict[str, Any] = {
            "id": did,
            "client_name": self.client.get().strip(),
            "domain_name": self.fqdn.get().strip(),
            "base_dn": self.base_dn.get().strip(),
            "transport": t,
            "color_tag": self.color.get().strip() or "#4A90D9",
            "enabled": True,
            "mock_mode": bool((self.existing or {}).get("mock_mode", False)),
            "connection_timeout_sec": int((self.existing or {}).get("connection_timeout_sec", 30)),
        }
        if t in ("winrm_http", "winrm_https", "winrm_custom"):
            use_https = t == "winrm_https" or (t == "winrm_custom" and bool(self.winrm_https.get()))
            servers = self._collect_winrm_servers()
            wp = self._effective_winrm_password() if for_test else self.winrm_pass.get() or self._effective_winrm_password()
            base["use_https"] = use_https
            base["validate_ssl"] = bool(self.winrm_validate.get())
            base["winrm_user"] = self.winrm_user.get().strip()
            base["_winrm_password_plain"] = wp
            base["_bind_password_plain"] = wp
            base["winrm"] = {
                "servers": [{"host": s["host"], "port": s["port"], "label": s["label"]} for s in servers],
                "user": self.winrm_user.get().strip(),
                "use_https": use_https,
                "validate_ssl": bool(self.winrm_validate.get()),
            }
            base["dc_servers"] = [{"host": s["host"], "port_winrm": s["port"], "label": s["label"]} for s in servers]
        if t in ("ldap", "ldaps", "ldap_starttls", "ldap_custom", "ssh_ldap_tunnel"):
            servers = self._collect_ldap_servers()
            lp = self._effective_ldap_password() if for_test else (self.ldap_pass.get() or self._effective_ldap_password())
            use_ssl = t == "ldaps" or (t == "ldap_custom" and bool(self.ldap_custom_ssl.get()))
            use_st = t == "ldap_starttls" or (t == "ldap_custom" and bool(self.ldap_custom_tls.get()))
            base["ldap"] = {
                "servers": servers,
                "bind_user": self.ldap_bind.get().strip(),
                "use_ssl": use_ssl,
                "use_start_tls": use_st,
                "validate_ssl": bool(self.ldap_validate.get()),
            }
            base["_ldap_password_plain"] = lp
            base["bind_user"] = self.ldap_bind.get().strip()
            base["_bind_password_plain"] = lp
        if t in ("ssh_ldap_tunnel", "ssh_powershell"):
            sp = self._effective_ssh_password() if for_test else self.ssh_pass.get() or self._effective_ssh_password()
            try:
                sh_port = int(self.ssh_port.get().strip() or "22")
            except ValueError:
                sh_port = 22
            base["ssh"] = {
                "host": self.ssh_host.get().strip(),
                "port": sh_port,
                "user": self.ssh_user.get().strip(),
                "private_key_path": self.ssh_key.get().strip(),
                "tunnel_local_port": int(self.tunnel_local.get().strip() or "13890"),
                "tunnel_remote_host": self.tunnel_rhost.get().strip() or "127.0.0.1",
                "tunnel_remote_port": int(self.tunnel_rport.get().strip() or "389"),
            }
            base["_ssh_password_plain"] = sp
        if t == "adws":
            ap = self._effective_adws_password() if for_test else self.adws_pass.get() or self._effective_adws_password()
            servers = self._collect_adws_servers()
            base["adws"] = {
                "servers": servers,
                "user": self.adws_user.get().strip(),
                "validate_ssl": bool(self.winrm_validate.get()),
            }
            base["_winrm_password_plain"] = ap
            base["_adws_password_plain"] = ap
            base["winrm_user"] = self.adws_user.get().strip()
        return base

    def _test(self) -> None:
        if not self._ui_ready:
            self._set_status("Please wait until the form finishes loading.")
            return
        self._auto_fill_base_dn()
        ok_dn, msg_dn = self._validate_base_dn()
        if not ok_dn:
            self._set_status(msg_dn)
            return
        self._set_status("Testing…")
        try:
            cfg = self._build_payload(for_test=True)
            if not cfg.get("client_name") or not cfg.get("domain_name") or not cfg.get("base_dn"):
                self._set_status("Please fill client name, FQDN, and base DN.")
                return
            t = cfg["transport"]
            err = self._validate_for_transport(t, cfg, for_test=True)
            if err:
                self._set_status(err)
                return

            def work() -> None:
                try:
                    con = get_connector(cfg)
                    ok, msg, ms = con.test_connection()
                    try:
                        con.disconnect()
                    except Exception:
                        pass
                    self.after(0, lambda: self._test_done(ok, msg, ms))
                except Exception as e:  # noqa: BLE001
                    self.after(0, lambda: self._test_done(False, str(e), 0.0))

            threading.Thread(target=work, daemon=True).start()
        except Exception as e:  # noqa: BLE001
            append_error_log(self.project_root, "add_domain test", e)
            self._set_status(str(e))

    def _validate_for_transport(self, t: str, cfg: dict[str, Any], *, for_test: bool) -> str:
        if t in ("winrm_http", "winrm_https", "winrm_custom"):
            if not cfg.get("winrm", {}).get("servers"):
                return "Add at least one WinRM target."
            if not cfg.get("winrm_user") or not cfg.get("_winrm_password_plain"):
                return "WinRM user and password are required."
        if t in ("ldap", "ldaps", "ldap_starttls", "ldap_custom"):
            if not cfg.get("ldap", {}).get("servers"):
                return "Add at least one LDAP server."
            if not cfg.get("ldap", {}).get("bind_user") or not cfg.get("_ldap_password_plain"):
                return "LDAP bind user and password are required."
        if t == "ssh_ldap_tunnel":
            if not cfg.get("ldap", {}).get("bind_user") or not cfg.get("_ldap_password_plain"):
                return "LDAP bind user and password are required for SSH tunnel mode."
        if t in ("ssh_ldap_tunnel", "ssh_powershell"):
            sh = cfg.get("ssh") or {}
            if not sh.get("host") or not sh.get("user"):
                return "SSH host and user are required."
            if not cfg.get("_ssh_password_plain") and not (sh.get("private_key_path") or "").strip():
                return "SSH password or private key path is required."
        if t == "adws":
            if not cfg.get("adws", {}).get("servers"):
                return "Add at least one ADWS controller."
            if not cfg.get("adws", {}).get("user") or not cfg.get("_winrm_password_plain"):
                return "ADWS user and password are required."
        return ""

    def _test_done(self, ok: bool, msg: str, ms: float) -> None:
        self._set_status(f"{'OK' if ok else 'Failed'} — {msg} — {ms:.1f} ms")
        if not ok:
            messagebox.showerror("Connection test failed", msg, parent=self)

    def _save(self) -> None:
        if not self._ui_ready:
            return
        try:
            self._auto_fill_base_dn()
            ok_dn, msg_dn = self._validate_base_dn()
            if not ok_dn:
                self._set_status(msg_dn)
                return
            cfg = self._build_payload(for_test=False)
            if not cfg["client_name"] or not cfg["domain_name"] or not cfg["base_dn"]:
                self._set_status("Please fill client name, FQDN, and base DN.")
                return
            t = cfg["transport"]
            err = self._validate_for_transport(t, cfg, for_test=False)
            if err:
                self._set_status(err)
                return
            # Encrypt secrets for persistence
            if t in ("winrm_http", "winrm_https", "winrm_custom"):
                wp = self.winrm_pass.get() or self._effective_winrm_password()
                if not wp:
                    self._set_status("WinRM password is required to save.")
                    return
                blob = crypto_vault.encrypt_secret(wp, self.master_key)
                cfg["winrm_password_encrypted"] = blob
                cfg["winrm"]["password_encrypted"] = blob
            if t in ("ldap", "ldaps", "ldap_starttls", "ldap_custom", "ssh_ldap_tunnel"):
                lp = self.ldap_pass.get() or self._effective_ldap_password()
                if not lp:
                    self._set_status("LDAP password is required to save.")
                    return
                lb = crypto_vault.encrypt_secret(lp, self.master_key)
                cfg["ldap"]["password_encrypted"] = lb
                cfg["bind_password_encrypted"] = lb
            if t in ("ssh_ldap_tunnel", "ssh_powershell"):
                sp = self.ssh_pass.get() or self._effective_ssh_password()
                if not sp and not self.ssh_key.get().strip():
                    self._set_status("SSH password or key path is required to save.")
                    return
                if sp:
                    cfg["ssh"]["password_encrypted"] = crypto_vault.encrypt_secret(sp, self.master_key)
            if t == "adws":
                ap = self.adws_pass.get() or self._effective_adws_password()
                if not ap:
                    self._set_status("Password is required to save.")
                    return
                b = crypto_vault.encrypt_secret(ap, self.master_key)
                cfg["adws"]["password_encrypted"] = b
                cfg["winrm_password_encrypted"] = b
                cfg.setdefault("winrm", {})
                cfg["winrm"]["password_encrypted"] = b
                cfg["winrm"]["user"] = self.adws_user.get().strip()
            # Strip runtime plaintext keys before handing off
            for k in list(cfg.keys()):
                if str(k).startswith("_"):
                    del cfg[k]
            if isinstance(cfg.get("winrm"), dict):
                cfg["winrm"].pop("_password_plain", None)
            if isinstance(cfg.get("ldap"), dict):
                cfg["ldap"].pop("_password_plain", None)
            if isinstance(cfg.get("ssh"), dict):
                cfg["ssh"].pop("_password_plain", None)
            if isinstance(cfg.get("adws"), dict):
                cfg["adws"].pop("_password_plain", None)
            self.result = cfg
            if self.on_saved:
                self.on_saved(cfg)
            self._set_status("Domain saved.")
            self.destroy()
        except Exception as e:  # noqa: BLE001
            append_error_log(self.project_root, "add_domain save", e)
            self._set_status(str(e))

    def _set_status(self, text: str) -> None:
        try:
            self.status.configure(text=text)
        except Exception:  # noqa: BLE001
            pass
