"""Generic AD object attribute viewer (key / value tree)."""

from __future__ import annotations

from tkinter import filedialog, ttk

import customtkinter as ctk


def _flatten(obj: object, prefix: str = "") -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    if isinstance(obj, dict):
        for k in sorted(obj.keys(), key=lambda x: str(x).lower()):
            v = obj[k]
            key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
            rows.extend(_flatten(v, key))
    elif isinstance(obj, (list, tuple)):
        if not obj:
            rows.append((prefix or "value", ""))
        else:
            for i, v in enumerate(obj):
                key = f"{prefix}[{i}]" if prefix else f"[{i}]"
                rows.extend(_flatten(v, key))
    else:
        rows.append((prefix or "value", "" if obj is None else str(obj)))
    return rows


class ObjectDetailDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, title: str, payload: dict) -> None:
        super().__init__(parent)
        self.title(title)
        self.geometry("800x600")
        self.transient(parent)

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=6)
        self.filter_e = ctk.CTkEntry(top, placeholder_text="Filter attribute…")
        self.filter_e.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.filter_e.bind("<KeyRelease>", lambda _e: self._apply_filter())
        ctk.CTkButton(top, text="Export TXT", width=110, command=self._export_txt).pack(side="right")

        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=8, pady=4)
        cols = ("attr", "val")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", height=22)
        self.tree.heading("attr", text="Attribute")
        self.tree.heading("val", text="Value")
        self.tree.column("attr", width=240, stretch=False)
        self.tree.column("val", width=520, stretch=True)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        self.tree.bind("<Double-1>", self._copy_val)

        self._all_rows = _flatten(payload)
        self._apply_filter()

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=8, pady=8)
        ctk.CTkButton(foot, text="Close", command=self.destroy).pack(side="right")

    def _apply_filter(self) -> None:
        q = self.filter_e.get().strip().lower()
        for i in self.tree.get_children():
            self.tree.delete(i)
        for k, v in self._all_rows:
            if q and q not in k.lower() and q not in v.lower():
                continue
            self.tree.insert("", "end", values=(k, v))

    def _copy_val(self, _evt=None) -> None:
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        if len(vals) >= 2:
            self.clipboard_clear()
            self.clipboard_append(vals[1])

    def _export_txt(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Texto", "*.txt")])
        if not path:
            return
        lines = [f"{k}\t{v}" for k, v in self._all_rows]
        with open(path, "w", encoding="utf-8") as f:
            for k, v in self._all_rows:
                f.write(f"{k}\t{v}\n")
