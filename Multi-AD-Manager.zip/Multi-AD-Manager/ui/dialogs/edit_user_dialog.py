"""Edit AD user (multi-tab) and save via WinRM."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

import customtkinter as ctk

from core.ad_constants import UAC_ACCOUNTDISABLE, UAC_DONT_EXPIRE_PASSWD, UAC_SMARTCARD_REQUIRED
from core.user_manager import UserManager
from ui.dialogs.user_pick_dialog import UserPickDialog

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class EditUserDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, app: "AdManagerApp", domain_id: str, user: dict, on_saved) -> None:
        super().__init__(parent)
        self.app = app
        self._domain_id = domain_id
        self._user = dict(user)
        self._on_saved = on_saved
        self._sam = str(user.get("sAMAccountName") or "").strip()
        self.title(f"Edit user — {self._sam}")
        self.geometry("720x560")
        self.transient(parent)

        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=8)

        t1 = self.tabs.add("General")
        t2 = self.tabs.add("Contact")
        t3 = self.tabs.add("Organization")
        t4 = self.tabs.add("Account")
        t5 = self.tabs.add("Groups")

        self._f_given = self._row(t1, "First name (givenName)")
        self._f_sn = self._row(t1, "Last name (sn)")
        self._f_disp = self._row(t1, "Display name")
        self._f_upn = self._row(t1, "UPN")
        row_sam = ctk.CTkFrame(t1, fg_color="transparent")
        row_sam.pack(fill="x", pady=3)
        ctk.CTkLabel(row_sam, text="Logon name (sAM)", width=180, anchor="w").pack(side="left")
        ctk.CTkLabel(row_sam, text=self._sam, anchor="w").pack(side="left", fill="x", expand=True, padx=4)
        self._f_desc = self._row(t1, "Description", multiline=True)

        self._f_mail = self._row(t2, "Email")
        self._f_tel = self._row(t2, "Phone")
        self._f_mobile = self._row(t2, "Mobile")
        self._f_office = self._row(t2, "Office / extension")
        self._f_street = self._row(t2, "Street address")
        self._f_city = self._row(t2, "City")
        self._f_state = self._row(t2, "State / province")
        self._f_postal = self._row(t2, "ZIP / postal code")
        self._f_country = self._row(t2, "Country")

        self._f_title = self._row(t3, "Title")
        self._f_dept = self._row(t3, "Department")
        self._f_comp = self._row(t3, "Company")
        mgr_row = ctk.CTkFrame(t3, fg_color="transparent")
        mgr_row.pack(fill="x", pady=4)
        ctk.CTkLabel(mgr_row, text="Manager (DN)", width=160, anchor="w").pack(side="left")
        self._f_manager = ctk.CTkEntry(mgr_row)
        self._f_manager.pack(side="left", fill="x", expand=True, padx=4)
        ctk.CTkButton(mgr_row, text="Browse…", width=90, command=self._browse_manager).pack(side="right")
        self._reports = ctk.CTkTextbox(t3, height=80)
        ctk.CTkLabel(t3, text="Direct reports (read-only)").pack(anchor="w", pady=(8, 0))
        self._reports.pack(fill="both", expand=False, pady=4)
        self._reports.configure(state="disabled")

        self._en = ctk.CTkCheckBox(t4, text="Account enabled")
        self._en.pack(anchor="w", pady=4)
        self._pne = ctk.CTkCheckBox(t4, text="Password never expires")
        self._pne.pack(anchor="w", pady=4)
        self._sc = ctk.CTkCheckBox(t4, text="Smart card required")
        self._sc.pack(anchor="w", pady=4)
        self._f_exp = self._row(t4, "Expires on (YYYY-MM-DD, empty = never)")
        self._f_ws = self._row(t4, "Logon workstations")
        self._f_prof = self._row(t4, "Profile path")
        self._f_script = self._row(t4, "Logon script")

        ctk.CTkLabel(t5, text="Groups: use “Manage groups” on the Users tab toolbar.", anchor="w").pack(
            fill="x", padx=4, pady=8
        )

        self._populate_from(self._user)
        threading.Thread(target=self._refresh_remote, daemon=True).start()

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right", padx=4)
        ctk.CTkButton(foot, text="Save", command=self._save).pack(side="right", padx=4)

    def _row(self, parent, label: str, *, multiline: bool = False):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=3)
        ctk.CTkLabel(row, text=label, width=180, anchor="w").pack(side="left")
        if multiline:
            w = ctk.CTkTextbox(row, height=52)
            w.pack(side="left", fill="x", expand=True, padx=4)
            return w
        w = ctk.CTkEntry(row)
        w.pack(side="left", fill="x", expand=True, padx=4)
        return w

    def _populate_from(self, u: dict) -> None:
        def set_e(ent, val: str) -> None:
            if isinstance(ent, ctk.CTkTextbox):
                ent.configure(state="normal")
                ent.delete("1.0", "end")
                ent.insert("1.0", val or "")
            else:
                ent.delete(0, "end")
                ent.insert(0, val or "")

        set_e(self._f_given, str(u.get("givenName", "")))
        set_e(self._f_sn, str(u.get("sn", "")))
        set_e(self._f_disp, str(u.get("displayName", "")))
        set_e(self._f_upn, str(u.get("userPrincipalName", "")))
        set_e(self._f_desc, str(u.get("description", "")))
        set_e(self._f_mail, str(u.get("mail", "")))
        set_e(self._f_tel, str(u.get("telephoneNumber", "")))
        set_e(self._f_mobile, str(u.get("MobilePhone") or u.get("mobile", "")))
        set_e(self._f_office, str(u.get("officePhone", "")))
        set_e(self._f_street, str(u.get("StreetAddress") or u.get("streetAddress", "")))
        set_e(self._f_city, str(u.get("City") or u.get("city", "")))
        set_e(self._f_state, str(u.get("State") or u.get("state", "")))
        set_e(self._f_postal, str(u.get("PostalCode") or u.get("postalCode", "")))
        set_e(self._f_country, str(u.get("Country") or u.get("country", "")))
        set_e(self._f_title, str(u.get("title", "")))
        set_e(self._f_dept, str(u.get("department", "")))
        set_e(self._f_comp, str(u.get("company", "")))
        set_e(self._f_manager, str(u.get("Manager") or u.get("manager", "")))
        set_e(self._f_exp, str(u.get("AccountExpirationDate") or u.get("accountExpirationDate", ""))[:10])
        set_e(self._f_ws, str(u.get("LogonWorkstations") or u.get("logonWorkstations", "")))
        set_e(self._f_prof, str(u.get("ProfilePath") or u.get("profilePath", "")))
        set_e(self._f_script, str(u.get("ScriptPath") or u.get("scriptPath", "")))

        uac = int(u.get("userAccountControl") or 0)
        if uac & UAC_ACCOUNTDISABLE:
            self._en.deselect()
        else:
            self._en.select()
        if uac & UAC_DONT_EXPIRE_PASSWD:
            self._pne.select()
        else:
            self._pne.deselect()
        if uac & UAC_SMARTCARD_REQUIRED:
            self._sc.select()
        else:
            self._sc.deselect()

    def _browse_manager(self) -> None:
        def on_pick(pu: dict) -> None:
            self._f_manager.delete(0, "end")
            self._f_manager.insert(0, pu.get("distinguishedName", ""))

        UserPickDialog(self, app=self.app, domain_id=self._domain_id, on_pick=on_pick)

    def _refresh_remote(self) -> None:
        fresh: dict = {}

        def work() -> None:
            nonlocal fresh
            try:
                if self.app.ensure_online(self._domain_id):
                    con = self.app.dm.get_connector(self._domain_id)
                    fresh = con.get_user_by_sam(self._sam) or {}
            except Exception:
                fresh = {}

        def done() -> None:
            if fresh:
                self._user.update(fresh)
                self._populate_from(self._user)

        work()
        self.after(0, done)

    def _txt(self, w) -> str:
        if isinstance(w, ctk.CTkTextbox):
            return w.get("1.0", "end").strip()
        return w.get().strip()

    def _save(self) -> None:
        if not self.app.ensure_online(self._domain_id):
            return
        mgr = UserManager(self.app.dm.get_connector(self._domain_id), audit=self.app.make_audit_cb(self._domain_id))
        ident = self._sam
        changes: dict = {}
        if self._txt(self._f_given) != str(self._user.get("givenName", "")):
            changes["givenName"] = self._txt(self._f_given)
        if self._txt(self._f_sn) != str(self._user.get("sn", "")):
            changes["sn"] = self._txt(self._f_sn)
        if self._txt(self._f_disp) != str(self._user.get("displayName", "")):
            changes["displayName"] = self._txt(self._f_disp)
        if self._txt(self._f_upn) != str(self._user.get("userPrincipalName", "")):
            changes["userPrincipalName"] = self._txt(self._f_upn)
        if self._txt(self._f_desc) != str(self._user.get("description", "")):
            changes["description"] = self._txt(self._f_desc)
        if self._txt(self._f_mail) != str(self._user.get("mail", "")):
            changes["mail"] = self._txt(self._f_mail)
        if self._txt(self._f_tel) != str(self._user.get("telephoneNumber", "")):
            changes["telephoneNumber"] = self._txt(self._f_tel)
        if self._txt(self._f_mobile) != str(self._user.get("MobilePhone") or self._user.get("mobile", "")):
            changes["mobilePhone"] = self._txt(self._f_mobile)
        if self._txt(self._f_office) != str(self._user.get("officePhone", "")):
            changes["officePhone"] = self._txt(self._f_office)
        for key, fld, oldk in (
            ("streetAddress", self._f_street, "StreetAddress"),
            ("city", self._f_city, "City"),
            ("state", self._f_state, "State"),
            ("postalCode", self._f_postal, "PostalCode"),
            ("country", self._f_country, "Country"),
        ):
            if self._txt(fld) != str(self._user.get(oldk) or self._user.get(key, "")):
                changes[key] = self._txt(fld)
        if self._txt(self._f_title) != str(self._user.get("title", "")):
            changes["title"] = self._txt(self._f_title)
        if self._txt(self._f_dept) != str(self._user.get("department", "")):
            changes["department"] = self._txt(self._f_dept)
        if self._txt(self._f_comp) != str(self._user.get("company", "")):
            changes["company"] = self._txt(self._f_comp)
        if self._txt(self._f_manager) != str(self._user.get("Manager") or self._user.get("manager", "")):
            changes["manager"] = self._txt(self._f_manager)

        exp_new = self._txt(self._f_exp)
        exp_old = str(self._user.get("AccountExpirationDate") or self._user.get("accountExpirationDate", ""))[:10]
        if exp_new != exp_old:
            changes["accountExpirationDate"] = exp_new
        if self._txt(self._f_ws) != str(self._user.get("LogonWorkstations") or self._user.get("logonWorkstations", "")):
            changes["logonWorkstations"] = self._txt(self._f_ws)
        if self._txt(self._f_prof) != str(self._user.get("ProfilePath") or self._user.get("profilePath", "")):
            changes["profilePath"] = self._txt(self._f_prof)
        if self._txt(self._f_script) != str(self._user.get("ScriptPath") or self._user.get("scriptPath", "")):
            changes["scriptPath"] = self._txt(self._f_script)

        uac0 = int(self._user.get("userAccountControl") or 0)
        pne_old = bool(uac0 & UAC_DONT_EXPIRE_PASSWD)
        pne_new = bool(self._pne.get())
        if pne_new != pne_old:
            changes["passwordNeverExpires"] = pne_new
        sc_old = bool(uac0 & UAC_SMARTCARD_REQUIRED)
        sc_new = bool(self._sc.get())
        if sc_new != sc_old:
            changes["smartcardLogonRequired"] = sc_new

        if changes:
            ok, msg = mgr.modify(ident, changes)
            if not ok:
                self.app.log_audit("modify_user", self._domain_id, ident, False, err=msg, params=changes)
                from ui.toast import show_toast

                show_toast(self, f"Error: {msg[:200]}")
                return

        dis_old = bool(uac0 & UAC_ACCOUNTDISABLE)
        dis_new = not bool(self._en.get())
        if dis_new != dis_old:
            if dis_new:
                mgr.disable(ident)
            else:
                mgr.enable(ident)

        self._on_saved()
        from ui.toast import show_toast

        show_toast(self, "User updated.")
        self.destroy()
