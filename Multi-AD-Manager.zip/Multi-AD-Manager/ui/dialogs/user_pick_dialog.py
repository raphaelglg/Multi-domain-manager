"""Pick another AD user (search + list)."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Callable

import customtkinter as ctk

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class UserPickDialog(ctk.CTkToplevel):
    def __init__(self, parent, *, app: "AdManagerApp", domain_id: str, on_pick: Callable[[dict], None]) -> None:
        super().__init__(parent)
        self.app = app
        self._domain_id = domain_id
        self._on_pick = on_pick
        self._rows: list[dict] = []
        self.title("Select user")
        self.geometry("520x420")
        self.transient(parent)

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=8)
        self.search = ctk.CTkEntry(top, placeholder_text="Filter by name or logon…")
        self.search.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(top, text="Search", width=90, command=self._filter).pack(side="right")
        self.search.bind("<KeyRelease>", lambda _e: self._filter())

        self.list = ctk.CTkScrollableFrame(self, height=280)
        self.list.pack(fill="both", expand=True, padx=10, pady=4)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(foot, text="Cancel", command=self.destroy).pack(side="right")

        self._status = ctk.CTkLabel(self, text="Loading…")
        self._status.pack(anchor="w", padx=10)

        threading.Thread(target=self._load, daemon=True).start()

    def _load(self) -> None:
        rows: list[dict] = []

        def work() -> None:
            nonlocal rows
            try:
                con = self.app.dm.get_connector(self._domain_id)
                if con.is_connected:
                    rows = con.get_all_users()
            except Exception:
                rows = []

        def done() -> None:
            self._rows = rows
            self._status.configure(text=f"{len(rows)} user(s) loaded.")
            self._filter()

        work()
        self.after(0, done)

    def _filter(self) -> None:
        for w in self.list.winfo_children():
            w.destroy()
        q = self.search.get().strip().lower()
        shown = 0
        for u in self._rows:
            blob = " ".join(
                [
                    str(u.get("displayName", "")),
                    str(u.get("sAMAccountName", "")),
                    str(u.get("mail", "")),
                ]
            ).lower()
            if q and q not in blob:
                continue
            shown += 1
            if shown > 200:
                break
            dn = u.get("distinguishedName", "")
            label = f"{u.get('displayName') or u.get('sAMAccountName','')}  ({u.get('sAMAccountName','')})"
            btn = ctk.CTkButton(
                self.list,
                text=label,
                anchor="w",
                command=lambda uu=u: self._pick(uu),
            )
            btn.pack(fill="x", pady=2)

    def _pick(self, u: dict) -> None:
        self._on_pick(u)
        self.destroy()
