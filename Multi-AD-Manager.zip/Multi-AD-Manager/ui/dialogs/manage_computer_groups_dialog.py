from __future__ import annotations

import threading
import tkinter as tk

import customtkinter as ctk


class ManageComputerGroupsDialog(ctk.CTkToplevel):
    def __init__(self, parent, connector, computer_name: str):
        super().__init__(parent)
        self.connector = connector
        self.computer_name = computer_name
        self.title(f"Manage Groups - {computer_name}")
        self.geometry("740x520")
        self.resizable(True, True)
        self.grab_set()
        self.focus()

        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - 370
        y = (self.winfo_screenheight() // 2) - 260
        self.geometry(f"+{x}+{y}")

        self._pending_add: list[str] = []
        self._pending_remove: list[str] = []
        self._current_groups: dict[str, dict] = {}
        self._build_ui()
        self._load_current_groups()

    def _build_ui(self) -> None:
        ctk.CTkLabel(
            self, text=f"Groups for: {self.computer_name}", font=ctk.CTkFont(size=15, weight="bold")
        ).pack(pady=(14, 6), padx=16, anchor="w")

        panels = ctk.CTkFrame(self, fg_color="transparent")
        panels.pack(fill="both", expand=True, padx=16, pady=4)
        panels.columnconfigure(0, weight=1)
        panels.columnconfigure(2, weight=1)

        left = ctk.CTkFrame(panels)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
        ctk.CTkLabel(left, text="Current groups", font=ctk.CTkFont(weight="bold")).pack(pady=6)
        self.current_listbox = tk.Listbox(
            left,
            selectmode="extended",
            bg="#2b2b2b",
            fg="white",
            selectbackground="#1f538d",
            relief="flat",
            font=("Consolas", 11),
        )
        self.current_listbox.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        ctk.CTkButton(
            left, text="- Remove selected", fg_color="#C0392B", hover_color="#A93226", command=self._stage_remove
        ).pack(pady=6, padx=6, fill="x")

        center = ctk.CTkFrame(panels, fg_color="transparent", width=40)
        center.grid(row=0, column=1, sticky="ns")
        ctk.CTkLabel(center, text="<=>", font=ctk.CTkFont(size=18)).pack(expand=True)

        right = ctk.CTkFrame(panels)
        right.grid(row=0, column=2, sticky="nsew", padx=(4, 0))
        ctk.CTkLabel(right, text="Search & add groups", font=ctk.CTkFont(weight="bold")).pack(pady=6)
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", self._on_search)
        ctk.CTkEntry(right, textvariable=self.search_var, placeholder_text="Type to search...").pack(
            fill="x", padx=6, pady=(0, 4)
        )
        self.search_listbox = tk.Listbox(
            right,
            selectmode="extended",
            bg="#2b2b2b",
            fg="white",
            selectbackground="#1f538d",
            relief="flat",
            font=("Consolas", 11),
        )
        self.search_listbox.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        ctk.CTkButton(right, text="+ Add selected", command=self._stage_add).pack(pady=6, padx=6, fill="x")

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(4, 14))
        self.status_label = ctk.CTkLabel(btn_frame, text="", text_color="gray")
        self.status_label.pack(side="left")
        ctk.CTkButton(
            btn_frame, text="Close", width=110, fg_color="transparent", border_width=1, command=self.destroy
        ).pack(side="right", padx=6)
        ctk.CTkButton(btn_frame, text="Apply Changes", width=140, command=self._apply_changes).pack(side="right", padx=6)

    def _load_current_groups(self) -> None:
        def _fetch() -> None:
            groups = self.connector.get_computer_groups(self.computer_name)
            self.after(0, lambda: self._populate_current(groups))

        threading.Thread(target=_fetch, daemon=True).start()

    def _populate_current(self, groups: list) -> None:
        self._current_groups = {g.get("Name", ""): g for g in groups}
        self.current_listbox.delete(0, "end")
        for name in sorted(self._current_groups.keys()):
            self.current_listbox.insert("end", name)

    def _on_search(self, *_args) -> None:
        query = self.search_var.get().strip()
        if len(query) < 2:
            return

        def _fetch() -> None:
            groups = self.connector.get_all_groups()
            filtered = [g.get("name", g.get("Name", "")) for g in groups if query.lower() in str(g.get("name", g.get("Name", ""))).lower()]
            self.after(0, lambda: self._populate_search(filtered))

        threading.Thread(target=_fetch, daemon=True).start()

    def _populate_search(self, names: list) -> None:
        self.search_listbox.delete(0, "end")
        for name in sorted(set(names)):
            self.search_listbox.insert("end", name)

    def _stage_add(self) -> None:
        for i in self.search_listbox.curselection():
            name = self.search_listbox.get(i)
            if name not in self._current_groups and name not in self._pending_add:
                self._pending_add.append(name)
                self.current_listbox.insert("end", f"{name} (+)")

    def _stage_remove(self) -> None:
        for i in reversed(self.current_listbox.curselection()):
            name = self.current_listbox.get(i).replace(" (+)", "")
            if name not in self._pending_remove:
                self._pending_remove.append(name)
            self.current_listbox.delete(i)

    def _apply_changes(self) -> None:
        errors = []
        for group in self._pending_add:
            ok, msg = self.connector.add_computer_to_group(self.computer_name, group)
            if not ok:
                errors.append(f"Add {group}: {msg}")
        for group in self._pending_remove:
            ok, msg = self.connector.remove_computer_from_group(self.computer_name, group)
            if not ok:
                errors.append(f"Remove {group}: {msg}")

        if errors:
            self.status_label.configure(text=f"Errors: {errors[0][:60]}", text_color="#E74C3C")
        else:
            total = len(self._pending_add) + len(self._pending_remove)
            self.status_label.configure(text=f"{total} change(s) applied.", text_color="#27AE60")
            self._pending_add.clear()
            self._pending_remove.clear()
            self._load_current_groups()
