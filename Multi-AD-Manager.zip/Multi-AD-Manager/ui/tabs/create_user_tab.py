"""Create user wizard with OU picker and group membership."""

from __future__ import annotations

import threading
import tkinter as tk
from typing import TYPE_CHECKING

import customtkinter as ctk

from ui.dialogs.confirm_dialog import ask_confirm
from ui.toast import show_toast

if TYPE_CHECKING:
    from ui.app import AdManagerApp


def _password_strength(pw: str) -> tuple[int, str]:
    score = 0
    if len(pw) >= 8:
        score += 1
    if len(pw) >= 12:
        score += 1
    if any(c.islower() for c in pw):
        score += 1
    if any(c.isupper() for c in pw):
        score += 1
    if any(c.isdigit() for c in pw):
        score += 1
    if any(not c.isalnum() for c in pw):
        score += 1
    labels = ["Very weak", "Weak", "Medium", "Good", "Strong"]
    idx = min(score, len(labels) - 1)
    return score, labels[idx]


def _flatten_ous(nodes: list[dict], trail: str = "") -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for n in nodes:
        name = n.get("name") or n.get("dn") or ""
        dn = n.get("dn") or ""
        label = f"{trail}{name}"
        rows.append((label, dn))
        rows.extend(_flatten_ous(n.get("children") or [], trail=f"{label} / "))
    return rows


class CreateUserTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app
        self._groups: list[dict] = []
        self._selected_groups: list[str] = []
        self._preset_ou: str | None = None
        self._ou_labels: list[str] = []
        self._ou_dns: list[str] = []

        self.grid_columnconfigure(0, weight=1)

        head = ctk.CTkFrame(self, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", padx=8, pady=6)
        self.domain = ctk.CTkOptionMenu(head, values=[], command=lambda _v: self._on_domain_change())
        self.domain.pack(side="left", padx=4)

        body = ctk.CTkScrollableFrame(self)
        body.grid(row=1, column=0, sticky="nsew", padx=8, pady=6)
        self.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(body, text="Target OU").pack(anchor="w")
        self.ou_menu = ctk.CTkOptionMenu(body, values=["(loading…)"])
        self.ou_menu.pack(fill="x")

        ctk.CTkLabel(body, text="First name").pack(anchor="w")
        self.given = ctk.CTkEntry(body)
        self.given.pack(fill="x")
        self.given.bind("<KeyRelease>", self._autofill)

        ctk.CTkLabel(body, text="Last name").pack(anchor="w")
        self.sn = ctk.CTkEntry(body)
        self.sn.pack(fill="x")
        self.sn.bind("<KeyRelease>", self._autofill)

        ctk.CTkLabel(body, text="Full name (displayName)").pack(anchor="w")
        self.display = ctk.CTkEntry(body)
        self.display.pack(fill="x")

        ctk.CTkLabel(body, text="Logon name (sAMAccountName)").pack(anchor="w")
        self.sam = ctk.CTkEntry(body)
        self.sam.pack(fill="x")

        ctk.CTkLabel(body, text="UPN").pack(anchor="w")
        self.upn = ctk.CTkEntry(body)
        self.upn.pack(fill="x")

        ctk.CTkLabel(body, text="Email").pack(anchor="w")
        self.mail = ctk.CTkEntry(body)
        self.mail.pack(fill="x")

        self.phone = ctk.CTkEntry(body, placeholder_text="Phone")
        self.phone.pack(fill="x", pady=2)
        self.title = ctk.CTkEntry(body, placeholder_text="Title")
        self.title.pack(fill="x", pady=2)
        self.dept = ctk.CTkEntry(body, placeholder_text="Department")
        self.dept.pack(fill="x", pady=2)
        self.company = ctk.CTkEntry(body, placeholder_text="Company")
        self.company.pack(fill="x", pady=2)
        self.desc = ctk.CTkEntry(body, placeholder_text="Description")
        self.desc.pack(fill="x", pady=2)

        ctk.CTkLabel(body, text="Password").pack(anchor="w")
        pwf = ctk.CTkFrame(body, fg_color="transparent")
        pwf.pack(fill="x")
        self.pw = ctk.CTkEntry(pwf, show="*")
        self.pw.pack(side="left", fill="x", expand=True)
        self.pw_toggle = ctk.CTkSwitch(pwf, text="Show", width=90, command=self._toggle_pw)
        self.pw_toggle.pack(side="right", padx=6)
        self.pw2 = ctk.CTkEntry(body, placeholder_text="Confirm password", show="*")
        self.pw2.pack(fill="x")
        self.pw_strength = ctk.CTkLabel(body, text="Strength: -")
        self.pw_strength.pack(anchor="w")
        self.pw.bind("<KeyRelease>", self._pw_meter)

        self.must_change = ctk.CTkCheckBox(body, text="User must change password at next logon")
        self.must_change.pack(anchor="w", pady=2)
        self.never_exp = ctk.CTkCheckBox(body, text="Password never expires")
        self.never_exp.pack(anchor="w", pady=2)
        self.acct_disabled = ctk.CTkCheckBox(body, text="Account disabled")
        self.acct_disabled.pack(anchor="w", pady=2)

        ctk.CTkLabel(body, text="Groups (search)").pack(anchor="w", pady=(8, 0))
        self.grp_search = ctk.CTkEntry(body, placeholder_text="Type to search groups in AD")
        self.grp_search.pack(fill="x")
        self.grp_search.bind("<KeyRelease>", self._debounce_search)

        grp_row = ctk.CTkFrame(body, fg_color="transparent")
        grp_row.pack(fill="both", expand=True, pady=6)
        self.grp_left = tk.Listbox(grp_row, height=10, exportselection=False)
        self.grp_right = tk.Listbox(grp_row, height=10, exportselection=False)
        self.grp_left.pack(side="left", fill="both", expand=True, padx=4)
        self.grp_right.pack(side="left", fill="both", expand=True, padx=4)
        self.grp_left.bind("<Double-Button-1>", lambda _e: self._move_right())
        self.grp_right.bind("<Double-Button-1>", lambda _e: self._move_left())

        ctk.CTkButton(body, text="Add selected group →", command=self._move_right).pack(fill="x")
        ctk.CTkButton(body, text="← Remove selected group", command=self._move_left).pack(fill="x")

        self.summary = ctk.CTkTextbox(body, height=120)
        self.summary.pack(fill="x", pady=8)
        ctk.CTkButton(body, text="Refresh summary", command=self._summary).pack(fill="x")
        ctk.CTkButton(body, text="Create user", command=self._create).pack(fill="x", pady=8)

        self._refresh_domain_options()

    def reload(self) -> None:
        self._refresh_domain_options()

    def set_preset_ou(self, ou_dn: str | None) -> None:
        self._preset_ou = ou_dn
        self._load_ou_menu()

    def _refresh_domain_options(self) -> None:
        labels = []
        self._domain_ids = []
        for d in self.app.dm.domains():
            labels.append(d.get("client_name") or d.get("domain_name"))
            self._domain_ids.append(d.get("id"))
        self.domain.configure(values=labels or ["(none)"])
        if labels:
            self.domain.set(labels[0])
        self._on_domain_change()

    def _current_domain_id(self) -> str | None:
        lab = self.domain.get()
        for did, d in zip(self._domain_ids, self.app.dm.domains(), strict=False):
            if (d.get("client_name") or d.get("domain_name")) == lab:
                return did
        return self._domain_ids[0] if self._domain_ids else None

    def _on_domain_change(self) -> None:
        self._load_ou_menu()
        self._load_groups_cache()

    def _load_ou_menu(self) -> None:
        did = self._current_domain_id()

        def work() -> list[dict]:
            if not did:
                return []
            try:
                con = self.app.dm.get_connector(did)
                if not con.is_connected:
                    return []
                return con.get_ou_tree()
            except Exception:
                return []

        def done(tree: list[dict]) -> None:
            flat = _flatten_ous(tree)
            self._ou_labels = [x[0] for x in flat]
            self._ou_dns = [x[1] for x in flat]
            if not self._ou_labels:
                self.ou_menu.configure(values=["(no OU)"])
                self.ou_menu.set("(no OU)")
                return
            self.ou_menu.configure(values=self._ou_labels)
            pick = self._ou_labels[0]
            if self._preset_ou:
                for lab, dn in zip(self._ou_labels, self._ou_dns, strict=False):
                    if dn.lower() == (self._preset_ou or "").lower():
                        pick = lab
                        break
            self.ou_menu.set(pick)

        def runner() -> None:
            data = work()
            self.after(0, lambda: done(data))

        threading.Thread(target=runner, daemon=True).start()

    def _selected_ou_dn(self) -> str:
        lab = self.ou_menu.get()
        for l, d in zip(self._ou_labels, self._ou_dns, strict=False):
            if l == lab:
                return d
        return ""

    def _toggle_pw(self) -> None:
        if self.pw_toggle.get():
            self.pw.configure(show="")
            self.pw2.configure(show="")
        else:
            self.pw.configure(show="*")
            self.pw2.configure(show="*")

    def _pw_meter(self, _evt=None) -> None:
        s, lab = _password_strength(self.pw.get())
        self.pw_strength.configure(text=f"Strength: {lab} ({s}/6)")

    def _autofill(self, _evt=None) -> None:
        g = self.given.get().strip()
        s = self.sn.get().strip()
        if g or s:
            self.display.delete(0, "end")
            self.display.insert(0, f"{g} {s}".strip())
        if g and s:
            sug = (g[0] + s).lower().replace(" ", "")
            if not self.sam.get().strip():
                self.sam.delete(0, "end")
                self.sam.insert(0, sug[:20])

    def _load_groups_cache(self) -> None:
        did = self._current_domain_id()

        def work() -> list[dict]:
            if not did:
                return []
            try:
                con = self.app.dm.get_connector(did)
                if not con.is_connected:
                    return []
                return con.get_all_groups()
            except Exception:
                return []

        def done(gs: list[dict]) -> None:
            self._groups = gs
            self._search_groups()

        def runner() -> None:
            data = work()
            self.after(0, lambda: done(data))

        threading.Thread(target=runner, daemon=True).start()

    def _debounce_search(self, _evt=None) -> None:
        self.after(350, self._search_groups)

    def _search_groups(self) -> None:
        q = self.grp_search.get().strip().lower()
        self.grp_left.delete(0, "end")
        for g in self._groups:
            if q and q not in (g.get("name", "").lower() + g.get("distinguishedName", "").lower()):
                continue
            if g.get("distinguishedName") in self._selected_groups:
                continue
            self.grp_left.insert("end", f"{g.get('name')} | {g.get('distinguishedName')}")

    def _move_right(self) -> None:
        sel = self.grp_left.curselection()
        if not sel:
            return
        text = self.grp_left.get(sel[0])
        dn = text.split("|", 1)[1].strip()
        if dn not in self._selected_groups:
            self._selected_groups.append(dn)
        self.grp_right.insert("end", text)
        self.grp_left.delete(sel[0])
        self._summary()

    def _move_left(self) -> None:
        sel = self.grp_right.curselection()
        if not sel:
            return
        text = self.grp_right.get(sel[0])
        dn = text.split("|", 1)[1].strip()
        self._selected_groups = [x for x in self._selected_groups if x != dn]
        self.grp_right.delete(sel[0])
        self._search_groups()
        self._summary()

    def _summary(self) -> None:
        lines = [
            f"Domain: {self.domain.get()}",
            f"OU: {self._selected_ou_dn()}",
            f"Name: {self.given.get()} {self.sn.get()} ({self.display.get()})",
            f"Logon / UPN: {self.sam.get()} / {self.upn.get()}",
            f"Email: {self.mail.get()}",
            f"Groups: {len(self._selected_groups)}",
        ]
        self.summary.delete("1.0", "end")
        self.summary.insert("1.0", "\n".join(lines))

    def _create(self) -> None:
        self._summary()
        if not ask_confirm(self.app, "Confirm", "Create the user with the summary shown?"):
            return
        did = self._current_domain_id()
        ou = self._selected_ou_dn()
        if not did or not ou:
            show_toast(self.app, "Select domain and OU.")
            return
        if not self.app.ensure_online(did):
            show_toast(self.app, "Domain is offline.")
            return
        p1, p2 = self.pw.get(), self.pw2.get()
        if p1 != p2:
            show_toast(self.app, "Passwords do not match.")
            return
        dcfg = self.app.dm.get_domain(did) or {}
        dom = dcfg.get("domain_name", "")
        if not self.upn.get().strip() and self.sam.get().strip():
            self.upn.delete(0, "end")
            self.upn.insert(0, f"{self.sam.get().strip()}@{dom}")
        if not self.display.get().strip():
            self.display.insert(0, f"{self.given.get().strip()} {self.sn.get().strip()}".strip())
        user_data = {
            "givenName": self.given.get().strip(),
            "sn": self.sn.get().strip(),
            "displayName": self.display.get().strip(),
            "sAMAccountName": self.sam.get().strip(),
            "userPrincipalName": self.upn.get().strip(),
            "mail": self.mail.get().strip(),
            "telephoneNumber": self.phone.get().strip(),
            "title": self.title.get().strip(),
            "department": self.dept.get().strip(),
            "company": self.company.get().strip(),
            "description": self.desc.get().strip(),
            "password": p1,
            "must_change_password": bool(self.must_change.get()),
            "password_never_expires": bool(self.never_exp.get()),
            "disabled": bool(self.acct_disabled.get()),
            "password_required": True,
        }
        from core.user_manager import UserManager

        mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
        ok, msg = mgr.create(user_data, ou, self._selected_groups)
        self.app.log_audit("create_user", did, msg if ok else ou, ok, err=None if ok else msg, params={"sam": user_data["sAMAccountName"]})
        if ok:
            show_toast(self.app, f"User created: {msg}")
            self.app.focus_users_tab(self.sam.get().strip())
        else:
            show_toast(self.app, f"Failed: {msg}")
