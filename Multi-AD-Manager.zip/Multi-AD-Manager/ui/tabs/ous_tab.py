"""OU hierarchy with lazy child objects and simple drag-move between OUs."""

from __future__ import annotations

import hashlib
import threading
from tkinter import Menu, simpledialog, ttk
from typing import TYPE_CHECKING

import customtkinter as ctk

from ui.dialogs.confirm_dialog import ask_confirm
from utils.audit_logger import append_error_log, append_runtime_log

if TYPE_CHECKING:
    from ui.app import AdManagerApp


def _mk_iid(dn: str) -> str:
    return hashlib.sha1(dn.encode("utf-8", errors="ignore")).hexdigest()


class OUTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app
        self._iid_to_dn: dict[str, str] = {}
        self._iid_kind: dict[str, str] = {}
        self._drag_dn: str | None = None
        self._drag_kind: str | None = None

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=6)
        ctk.CTkButton(top, text="+ New OU", width=110, command=self._create_ou_from_toolbar).pack(side="left", padx=4)
        ctk.CTkButton(top, text="↻ Reload tree", command=self.reload).pack(side="right", padx=4)

        self.tree = ttk.Treeview(self, show="tree")
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=6)
        vsb.pack(side="right", fill="y", padx=(0, 8), pady=6)

        self.tree.bind("<<TreeviewOpen>>", self._on_open)
        self.tree.bind("<ButtonPress-1>", self._on_press)
        self.tree.bind("<ButtonRelease-1>", self._on_release)
        self.tree.bind("<Button-3>", self._menu)

        self.reload()

    def _did(self) -> str | None:
        return self.app.selected_domain_id

    def _remember_iid(self, iid: str, dn: str, kind: str) -> None:
        self._iid_to_dn[iid] = dn
        self._iid_kind[iid] = kind

    def reload(self) -> None:
        did = self._did()
        for i in self.tree.get_children():
            self.tree.delete(i)
        self._iid_to_dn.clear()
        self._iid_kind.clear()
        if not did:
            return

        def work() -> list[dict]:
            try:
                try:
                    con = self.app.dm.get_connector(did)
                except Exception:
                    self.app.dm.connect_domain(did)
                    con = self.app.dm.get_connector(did)
                if not con.is_connected:
                    append_runtime_log(self.app.project_root, f"ous_tab:reload:{did}:connector_offline")
                    return []
                rows = con.get_ou_tree()
                append_runtime_log(self.app.project_root, f"ous_tab:reload:{did}:rows={len(rows)}")
                if not rows:
                    append_runtime_log(
                        self.app.project_root,
                        f"ous_tab:reload:{did}:last_error={getattr(con, 'last_error', '')}",
                    )
                return rows
            except Exception as e:  # noqa: BLE001
                append_error_log(self.app.project_root, f"ous_tab reload {did}", e)
                return []

        def done(tree: list[dict]) -> None:
            for root in tree:
                self._insert_node("", root, is_root=True)

        def runner() -> None:
            data = work()
            self.after(0, lambda: done(data))

        threading.Thread(target=runner, daemon=True).start()

    def _insert_node(self, parent: str, node: dict, *, is_root: bool) -> None:
        dn = node.get("dn", "")
        iid = _mk_iid(dn)
        self._remember_iid(iid, dn, "ou")
        label = node.get("name") or dn
        self.tree.insert(parent, "end", iid=iid, text=f"📁 {label}", open=False)
        if node.get("children"):
            for ch in node["children"]:
                self._insert_node(iid, ch, is_root=False)
        ph = f"{iid}.__ph"
        self._remember_iid(ph, "", "placeholder")
        self.tree.insert(iid, "end", iid=ph, text="(expand to load content)")

    def _on_open(self, _evt=None) -> None:
        sel = self.tree.focus()
        if not sel:
            return
        if self._iid_kind.get(sel) != "ou":
            return
        ou_dn = self._iid_to_dn.get(sel, "")
        # remove placeholder children
        for ch in list(self.tree.get_children(sel)):
            if self._iid_kind.get(ch) == "placeholder":
                self.tree.delete(ch)
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return

        def work() -> list[dict]:
            try:
                con = self.app.dm.get_connector(did)
                return con.get_ou_children_objects(ou_dn)
            except Exception as e:  # noqa: BLE001
                append_error_log(self.app.project_root, f"ous_tab children {did}", e)
                return []

        def done(rows: list[dict]) -> None:
            for obj in rows:
                dn = obj["dn"]
                iid = _mk_iid(dn)
                self._remember_iid(iid, dn, obj.get("kind", "object"))
                icon = {"user": "👤", "computer": "💻", "group": "👥"}.get(obj.get("kind", ""), "•")
                self.tree.insert(sel, "end", iid=iid, text=f"{icon} {obj.get('name')}")

        def runner() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=runner, daemon=True).start()

    def _on_press(self, event) -> None:
        row = self.tree.identify_row(event.y)
        if not row:
            self._drag_dn = None
            self._drag_kind = None
            return
        kind = self._iid_kind.get(row)
        dn = self._iid_to_dn.get(row)
        if kind in ("user", "computer", "group") and dn:
            self._drag_dn = dn
            self._drag_kind = kind
        else:
            self._drag_dn = None
            self._drag_kind = None

    def _on_release(self, event) -> None:
        if not self._drag_dn:
            return
        row = self.tree.identify_row(event.y)
        if not row:
            return
        if self._iid_kind.get(row) != "ou":
            return
        target = self._iid_to_dn.get(row, "")
        if not target or not ask_confirm(self, "Move object", f"Move to:\n{target} ?"):
            self._drag_dn = None
            self._drag_kind = None
            return
        did = self._did()
        if not did or not self.app.ensure_online(did):
            self._drag_dn = None
            self._drag_kind = None
            return
        con = self.app.dm.get_connector(did)
        ok, msg = con.move_object(self._drag_dn, target)
        self.app.log_audit("move_object", did, self._drag_dn, ok, err=msg, params={"target": target})
        self._drag_dn = None
        self._drag_kind = None
        self.reload()

    def _menu(self, event) -> None:
        row = self.tree.identify_row(event.y)
        if not row:
            return
        self.tree.selection_set(row)
        kind = self._iid_kind.get(row)
        dn = self._iid_to_dn.get(row, "")
        menu = Menu(self, tearoff=0)
        if kind == "ou":
            menu.add_command(label="Create sub-OU…", command=lambda: self._create_sub(dn))
            menu.add_command(label="Create user (open tab)", command=lambda: self.app.open_create_user_tab(dn))
            menu.add_command(label="Reload node", command=self.reload)
        menu.tk_popup(event.x_root, event.y_root)

    def _create_ou_from_toolbar(self) -> None:
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return
        dcfg = self.app.dm.get_domain(did) or {}
        base = dcfg.get("base_dn") or ""
        sel = self.tree.selection()
        parent_dn = base
        if sel:
            k = self._iid_kind.get(sel[0], "")
            if k == "ou":
                parent_dn = self._iid_to_dn.get(sel[0], base) or base
        name = simpledialog.askstring("New OU", "OU name:", parent=self)
        if not name or not name.strip():
            return
        con = self.app.dm.get_connector(did)
        ok, msg = con.create_ou(name.strip(), parent_dn)
        self.app.log_audit("create_ou", did, parent_dn, ok, err=msg, params={"name": name.strip()})
        self.reload()

    def _create_sub(self, parent_dn: str) -> None:
        name = simpledialog.askstring("New OU", "OU name:", parent=self)
        if not name:
            return
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return
        con = self.app.dm.get_connector(did)
        ok, msg = con.create_ou(name.strip(), parent_dn)
        self.app.log_audit("create_ou", did, parent_dn, ok, err=msg, params={"name": name})
        self.reload()
