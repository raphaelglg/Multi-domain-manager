"""Groups listing with toolbar, inline member expansion, and CRUD actions."""

from __future__ import annotations

import threading
from tkinter import Menu, simpledialog, ttk
from typing import TYPE_CHECKING

import customtkinter as ctk

from core.group_manager import GroupManager
from ui.dialogs.confirm_dialog import ask_confirm
from ui.dialogs.edit_group_dialog import EditGroupDialog
from ui.dialogs.group_members_dialog import GroupMembersDialog
from ui.dialogs.move_object_dialog import MoveObjectDialog
from ui.dialogs.object_detail_dialog import ObjectDetailDialog
from ui.dialogs.user_pick_dialog import UserPickDialog
from ui.toast import show_toast
from utils.audit_logger import append_error_log, append_runtime_log

if TYPE_CHECKING:
    from ui.app import AdManagerApp


def _group_scope_type(gt: str) -> tuple[str, str]:
    try:
        gti = int(gt)
    except Exception:
        return ("Unknown", "Unknown")
    sec = bool(gti & 0x80000000)
    gtype = "Security" if sec else "Distribution"
    kind = gti & 0x00000007
    scope = {1: "System", 2: "Global", 4: "DomainLocal", 8: "Universal"}.get(kind, "Unknown")
    return gtype, scope


class GroupsTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app
        self._cache: list[dict] = []

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=6)
        self.search = ctk.CTkEntry(top, placeholder_text="Search by name")
        self.search.pack(side="left", fill="x", expand=True, padx=4)
        self.search.bind("<KeyRelease>", lambda _e: self._fill())
        ctk.CTkButton(top, text="Apply search", width=100, command=self._fill).pack(side="right", padx=4)

        tb = ctk.CTkFrame(self, fg_color="transparent")
        tb.pack(fill="x", padx=8, pady=4)
        self._btns: dict[str, ctk.CTkButton] = {}
        for key, label, cmd, needs_one in (
            ("new", "+ New group", self._act_new, False),
            ("edit", "✎ Edit", self._act_edit, True),
            ("det", "👁 Details", self._act_details, True),
            ("mem", "👥 View members", self._act_members, True),
            ("move", "➜ Move to OU", self._act_move, True),
            ("del", "🗑 Delete", self._act_delete, True),
            ("rel", "↻ Reload", self.reload, False),
        ):
            b = ctk.CTkButton(tb, text=label, width=110, command=cmd)
            b.pack(side="left", padx=2, pady=2)
            self._btns[key] = b

        tree_frame = ctk.CTkFrame(self, fg_color="transparent")
        tree_frame.pack(fill="both", expand=True, padx=8, pady=6)
        self.tree = ttk.Treeview(tree_frame, columns=("meta",), show="tree headings", height=18, selectmode="browse")
        self.tree.heading("meta", text="Details")
        self.tree.column("meta", width=520, stretch=True)
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<<TreeviewOpen>>", self._on_open)
        self.tree.bind("<Button-3>", self._menu)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._tb_state())

        self.reload()

    def _did(self) -> str | None:
        return self.app.selected_domain_id

    def _tb_state(self) -> None:
        g = self._selected_group()
        for key, b in self._btns.items():
            if key == "rel" or key == "new":
                b.configure(state="normal")
            else:
                b.configure(state="normal" if g else "disabled")

    def _selected_group(self) -> dict | None:
        sel = self.tree.selection()
        if len(sel) != 1:
            return None
        row = sel[0]
        if self.tree.parent(row):
            return None
        return self._group_by_iid(row)

    def reload(self) -> None:
        did = self._did()
        if not did:
            self._cache = []
            self._fill()
            self._tb_state()
            return

        def work() -> list[dict]:
            try:
                try:
                    con = self.app.dm.get_connector(did)
                except Exception:
                    self.app.dm.connect_domain(did)
                    con = self.app.dm.get_connector(did)
                if not con.is_connected:
                    append_runtime_log(self.app.project_root, f"groups_tab:reload:{did}:connector_offline")
                    return []
                rows = con.get_all_groups()
                append_runtime_log(self.app.project_root, f"groups_tab:reload:{did}:rows={len(rows)}")
                if not rows:
                    append_runtime_log(
                        self.app.project_root,
                        f"groups_tab:reload:{did}:last_error={getattr(con, 'last_error', '')}",
                    )
                return rows
            except Exception as e:  # noqa: BLE001
                append_error_log(self.app.project_root, f"groups_tab reload {did}", e)
                return []

        def done(rows: list[dict]) -> None:
            self._cache = rows
            self._fill()
            self._tb_state()

        def runner() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=runner, daemon=True).start()

    def _fill(self) -> None:
        for i in self.tree.get_children():
            self.tree.delete(i)
        q = self.search.get().strip().lower()
        for g in self._cache:
            if q and q not in (g.get("name", "").lower() + str(g.get("cn", "")).lower() + str(g.get("samAccountName", "")).lower()):
                continue
            gtype, scope = _group_scope_type(str(g.get("groupType", "0")))
            text = f"{g.get('name')}  |  {gtype} / {scope}  |  members: {g.get('member_count', 0)}"
            iid = g.get("distinguishedName") or g.get("name")
            node = self.tree.insert("", "end", iid=iid, text=text, values=(g.get("description", ""),), open=False)
            self.tree.insert(node, "end", text="(expand to load members)", values=("",))

    def _on_open(self, _evt=None) -> None:
        sel = self.tree.focus()
        if not sel:
            return
        parent = self.tree.parent(sel)
        if parent:
            return
        for ch in self.tree.get_children(sel):
            self.tree.delete(ch)
        g = self._group_by_iid(sel)
        if not g:
            return
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return

        def work() -> list[dict]:
            try:
                con = self.app.dm.get_connector(did)
                return con.get_group_members(g["distinguishedName"])
            except Exception as e:  # noqa: BLE001
                append_error_log(self.app.project_root, f"groups_tab members {did}", e)
                return []

        def done(members: list[dict]) -> None:
            for m in members:
                label = m.get("cn") or m.get("sAMAccountName") or m.get("distinguishedName")
                self.tree.insert(sel, "end", text=f"↳ {label}", values=(m.get("distinguishedName", ""),))

        def runner() -> None:
            members = work()
            self.after(0, lambda: done(members))

        threading.Thread(target=runner, daemon=True).start()

    def _group_by_iid(self, iid: str) -> dict | None:
        for g in self._cache:
            if g.get("distinguishedName") == iid:
                return g
        return None

    def _act_new(self) -> None:
        did = self._did()
        if not did or not self.app.ensure_online(did):
            show_toast(self, "Select a connected domain.")
            return
        name = simpledialog.askstring("New group", "Group name:", parent=self)
        if not name or not name.strip():
            return
        dcfg = self.app.dm.get_domain(did) or {}
        base = dcfg.get("base_dn") or ""
        default_path = f"CN=Users,{base}" if base else ""
        path = simpledialog.askstring(
            "OU / container",
            "Container DN (e.g. CN=Users,DC=corp,DC=local):",
            parent=self,
            initialvalue=default_path,
        )
        if not path or not path.strip():
            return
        scope = simpledialog.askstring("Scope", "DomainLocal, Global, or Universal:", parent=self, initialvalue="Global")
        cat = simpledialog.askstring("Category", "Security or Distribution:", parent=self, initialvalue="Security")
        gm = GroupManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
        ok, msg = gm.create(name.strip(), path.strip(), (scope or "Global").strip(), (cat or "Security").strip(), "")
        self.app.log_audit("create_group", did, name.strip(), ok, err=msg)
        show_toast(self, "Group created." if ok else msg[:200])
        self.reload()

    def _act_edit(self) -> None:
        g = self._selected_group()
        if not g:
            return
        did = self._did()
        if not did:
            return
        EditGroupDialog(self, app=self.app, domain_id=did, group=g, on_saved=self.reload)

    def _act_details(self) -> None:
        g = self._selected_group()
        if not g:
            return
        ObjectDetailDialog(self, title=f"Group — {g.get('name')}", payload=g)

    def _act_members(self) -> None:
        g = self._selected_group()
        if not g:
            return
        did = self._did()
        if not did:
            return
        gid = g.get("distinguishedName") or ""

        def load(recursive: bool) -> list[dict]:
            con = self.app.dm.get_connector(did)
            return con.get_group_members(gid, recursive=recursive)

        GroupMembersDialog(self, title=f"Membros — {g.get('name')}", load_members=load)

    def _act_move(self) -> None:
        g = self._selected_group()
        if not g:
            return
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return
        gid = str(g.get("distinguishedName", ""))

        def load_tree() -> list[dict]:
            return self.app.dm.get_connector(did).get_ou_tree()

        def on_move(target: str) -> None:
            con = self.app.dm.get_connector(did)
            ok, msg = con.move_object(gid, target)
            self.app.log_audit("move_group", did, gid, ok, err=msg, params={"target": target})
            show_toast(self, "Group moved." if ok else msg[:200])
            self.reload()

        MoveObjectDialog(self, title=f"Move group — {g.get('name')}", current_dn=gid, load_tree=load_tree, on_move=on_move)

    def _act_delete(self) -> None:
        g = self._selected_group()
        if not g:
            return
        if not ask_confirm(self, "Delete", f"Delete group {g.get('name')}?"):
            return
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return
        con = self.app.dm.get_connector(did)
        ok, msg = con.delete_group(g["distinguishedName"])
        self.app.log_audit("delete_group", did, g["distinguishedName"], ok, err=msg)
        show_toast(self, "Group deleted." if ok else msg[:200])
        self.reload()

    def _menu(self, event) -> None:
        row = self.tree.identify_row(event.y)
        if not row:
            return
        self.tree.selection_set(row)
        if self.tree.parent(row):
            return
        g = self._group_by_iid(row)
        if not g:
            return
        menu = Menu(self, tearoff=0)
        menu.add_command(label="View members (tree)", command=lambda: self.tree.item(row, open=True))
        menu.add_command(label="Members (window)…", command=self._act_members)
        menu.add_command(label="Add member…", command=lambda: self._add_member(g))
        menu.add_command(label="Edit…", command=self._act_edit)
        menu.add_command(label="Delete group", command=self._act_delete)
        menu.tk_popup(event.x_root, event.y_root)

    def _add_member(self, g: dict) -> None:
        did = self._did()
        if not did or not self.app.ensure_online(did):
            return

        def on_pick(u: dict) -> None:
            gm = GroupManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
            gm.add_member(u.get("distinguishedName", ""), g["distinguishedName"])
            self.reload()

        UserPickDialog(self, app=self.app, domain_id=did, on_pick=on_pick)
