"""Computers tab with editing and management actions."""

from __future__ import annotations

import csv
import threading
import tkinter as tk
import tkinter.filedialog as fd
import tkinter.messagebox as mb
from tkinter import ttk
from typing import TYPE_CHECKING

import customtkinter as ctk

from core.ad_constants import _filetime_to_iso
from ui.dialogs.move_object_dialog import MoveObjectDialog
from ui.dialogs.object_detail_dialog import ObjectDetailDialog
from utils.audit_logger import append_error_log, append_runtime_log

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class ComputersTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app
        self.domain_manager = app.dm
        self._all_computers: list[dict] = []
        self._current_domain_id: str | None = None

        self._build_toolbar()
        self._build_table()
        self.refresh()

    def _build_toolbar(self) -> None:
        toolbar = ctk.CTkFrame(self, fg_color="transparent")
        toolbar.pack(fill="x", padx=12, pady=(10, 4))

        self.btn_edit = ctk.CTkButton(toolbar, text="Edit", width=90, state="disabled", command=self._on_edit)
        self.btn_edit.pack(side="left", padx=3)
        self.btn_details = ctk.CTkButton(toolbar, text="Details", width=90, state="disabled", command=self._on_details)
        self.btn_details.pack(side="left", padx=3)
        self.btn_toggle = ctk.CTkButton(
            toolbar, text="Disable", width=100, state="disabled", command=self._on_toggle_enabled
        )
        self.btn_toggle.pack(side="left", padx=3)
        self.btn_move = ctk.CTkButton(toolbar, text="Move to OU", width=110, state="disabled", command=self._on_move)
        self.btn_move.pack(side="left", padx=3)
        self.btn_groups = ctk.CTkButton(toolbar, text="Groups", width=90, state="disabled", command=self._on_manage_groups)
        self.btn_groups.pack(side="left", padx=3)
        self.btn_delete = ctk.CTkButton(
            toolbar,
            text="Delete",
            width=90,
            state="disabled",
            fg_color="#C0392B",
            hover_color="#A93226",
            command=self._on_delete,
        )
        self.btn_delete.pack(side="left", padx=3)

        ctk.CTkLabel(toolbar, text="|", text_color="gray").pack(side="left", padx=6)

        self.filter_var = ctk.StringVar()
        self.filter_var.trace_add("write", self._on_filter_change)
        ctk.CTkEntry(toolbar, textvariable=self.filter_var, placeholder_text="Search computers...", width=200).pack(
            side="left", padx=3
        )

        self.combo_ou = ctk.CTkComboBox(toolbar, values=["All OUs"], width=180, command=self._on_filter_change)
        self.combo_ou.pack(side="left", padx=3)
        self.combo_status = ctk.CTkComboBox(
            toolbar, values=["All", "Enabled", "Disabled"], width=120, command=self._on_filter_change
        )
        self.combo_status.pack(side="left", padx=3)
        self.combo_status.set("All")

        ctk.CTkButton(
            toolbar, text="Reload", width=90, fg_color="transparent", border_width=1, command=self.refresh
        ).pack(side="right", padx=3)
        ctk.CTkButton(
            toolbar, text="Export CSV", width=110, fg_color="transparent", border_width=1, command=self._on_export_csv
        ).pack(side="right", padx=3)

    def _build_table(self) -> None:
        frame = ctk.CTkFrame(self)
        frame.pack(fill="both", expand=True, padx=12, pady=6)

        columns = ("name", "dns", "os", "os_version", "enabled", "last_logon", "ou", "ip")
        self.tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="extended")
        headers = {
            "name": ("Name", 160),
            "dns": ("DNS Hostname", 200),
            "os": ("OS", 180),
            "os_version": ("Version", 120),
            "enabled": ("Status", 80),
            "last_logon": ("Last Logon", 140),
            "ou": ("OU", 220),
            "ip": ("IP Address", 120),
        }
        for col, (heading, width) in headers.items():
            self.tree.heading(col, text=heading, command=lambda c=col: self._sort_by(c))
            self.tree.column(col, width=width, minwidth=60)

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)

        self.tree.tag_configure("disabled", foreground="#E74C3C")
        self.tree.tag_configure("enabled", foreground="#2ECC71")
        self.tree.bind("<<TreeviewSelect>>", self._on_selection_change)
        self.tree.bind("<Double-1>", self._on_double_click)
        self.tree.bind("<Button-3>", self._on_right_click)

        self._context_menu = tk.Menu(self, tearoff=0)
        self._context_menu.add_command(label="Edit", command=self._on_edit)
        self._context_menu.add_command(label="Details", command=self._on_details)
        self._context_menu.add_separator()
        self._context_menu.add_command(label="Disable / Enable", command=self._on_toggle_enabled)
        self._context_menu.add_command(label="Move to OU", command=self._on_move)
        self._context_menu.add_command(label="Manage Groups", command=self._on_manage_groups)
        self._context_menu.add_separator()
        self._context_menu.add_command(label="Copy Name", command=self._on_copy_name)
        self._context_menu.add_separator()
        self._context_menu.add_command(label="Delete", command=self._on_delete)

    def set_domain(self, domain_id: str | None) -> None:
        self._current_domain_id = domain_id
        self.refresh()

    def reload(self) -> None:
        self.refresh()

    def refresh(self) -> None:
        did = self._get_selected_domain_id()

        def work() -> list[dict]:
            if not did:
                return []
            try:
                try:
                    con = self.domain_manager.get_connector(did)
                except Exception:
                    self.domain_manager.connect_domain(did)
                    con = self.domain_manager.get_connector(did)
                if not con or not con.is_connected:
                    append_runtime_log(self.app.project_root, f"computers_tab:reload:{did}:connector_offline")
                    return []
                rows = con.get_computers() or []
                append_runtime_log(self.app.project_root, f"computers_tab:reload:{did}:rows={len(rows)}")
                if not rows:
                    append_runtime_log(
                        self.app.project_root,
                        f"computers_tab:reload:{did}:last_error={getattr(con, 'last_error', '')}",
                    )
                return rows
            except Exception as e:  # noqa: BLE001
                append_error_log(self.app.project_root, f"computers_tab reload {did}", e)
                return []

        def done(rows: list[dict]) -> None:
            self._populate_table(rows)

        threading.Thread(target=lambda: self.after(0, lambda: done(work())), daemon=True).start()

    def _on_right_click(self, event) -> None:
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self._context_menu.post(event.x_root, event.y_root)

    def _on_selection_change(self, _event=None) -> None:
        selected = self.tree.selection()
        count = len(selected)
        state_single = "normal" if count == 1 else "disabled"
        state_any = "normal" if count >= 1 else "disabled"
        self.btn_edit.configure(state=state_single)
        self.btn_details.configure(state=state_single)
        self.btn_toggle.configure(state=state_single)
        self.btn_move.configure(state=state_any)
        self.btn_groups.configure(state=state_single)
        self.btn_delete.configure(state=state_any)
        if count == 1:
            item = self.tree.item(selected[0])
            status = str(item["values"][4]).lower()
            self.btn_toggle.configure(text="Disable" if status == "true" else "Enable")

    def _populate_table(self, computers: list) -> None:
        self._all_computers = computers
        ous = sorted(
            set(c.get("OUPath", c.get("DistinguishedName", "")) for c in computers if c.get("OUPath") or c.get("DistinguishedName"))
        )
        self.combo_ou.configure(values=["All OUs"] + ous)
        self.combo_ou.set("All OUs")
        self._apply_filters()

    def _apply_filters(self) -> None:
        search = self.filter_var.get().lower()
        ou_filter = self.combo_ou.get()
        st_filter = self.combo_status.get()
        self.tree.delete(*self.tree.get_children())
        for c in self._all_computers:
            name = str(c.get("Name", c.get("name", "")))
            dns = str(c.get("DNSHostName", ""))
            os_ = str(c.get("OperatingSystem", c.get("operatingSystem", "")))
            ver = str(c.get("OperatingSystemVersion", ""))
            enabled = str(c.get("Enabled", ""))
            logon = str(c.get("LastLogonDate", "") or _filetime_to_iso(c.get("lastLogonTimestamp")) or "Never")
            ou = str(c.get("OUPath", c.get("DistinguishedName", c.get("distinguishedName", ""))))
            ip = str(c.get("IPv4Address", ""))

            if search and search not in (name + dns + os_ + ou + ip).lower():
                continue
            if ou_filter != "All OUs" and ou_filter not in ou:
                continue
            if st_filter == "Enabled" and enabled.lower() != "true":
                continue
            if st_filter == "Disabled" and enabled.lower() == "true":
                continue

            tag = "enabled" if enabled.lower() == "true" else "disabled"
            self.tree.insert("", "end", iid=name, values=(name, dns, os_, ver, enabled, logon, ou, ip), tags=(tag,))

    def _on_filter_change(self, *_args) -> None:
        self._apply_filters()

    def _sort_by(self, col: str) -> None:
        items = [(self.tree.set(k, col), k) for k in self.tree.get_children("")]
        items.sort(reverse=getattr(self, f"_sort_rev_{col}", False))
        for i, (_, k) in enumerate(items):
            self.tree.move(k, "", i)
        setattr(self, f"_sort_rev_{col}", not getattr(self, f"_sort_rev_{col}", False))

    def _get_selected_name(self) -> str:
        sel = self.tree.selection()
        return sel[0] if sel else ""

    def _get_selected_names(self) -> list[str]:
        return list(self.tree.selection())

    def _on_double_click(self, _event) -> None:
        if self.tree.selection():
            self._on_edit()

    def _on_copy_name(self) -> None:
        name = self._get_selected_name()
        if name:
            self.clipboard_clear()
            self.clipboard_append(name)

    def _on_export_csv(self) -> None:
        path = fd.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile="computers.csv"
        )
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Name", "DNS", "OS", "Version", "Enabled", "LastLogon", "OU", "IP"])
            for row_id in self.tree.get_children():
                writer.writerow(self.tree.item(row_id)["values"])
        self._show_toast(f"Exported to {path}")

    def _on_edit(self) -> None:
        name = self._get_selected_name()
        connector = self._get_connector()
        if not name or not connector:
            return
        from ui.dialogs.edit_computer_dialog import EditComputerDialog

        dialog = EditComputerDialog(self, connector, name, self.domain_manager, self._get_selected_domain_id() or "")
        dialog.wait_window()
        self.refresh()

    def _on_details(self) -> None:
        name = self._get_selected_name()
        connector = self._get_connector()
        if not name or not connector:
            return
        computer = connector.get_computer_by_name(name)
        dn = computer.get("DistinguishedName", "")
        if dn:
            all_attrs = connector.get_all_attributes(dn)
            ObjectDetailDialog(self, title=f"Computer details - {name}", payload=all_attrs)

    def _on_toggle_enabled(self) -> None:
        name = self._get_selected_name()
        connector = self._get_connector()
        if not name or not connector:
            return
        item = self.tree.item(name)
        enabled = str(item["values"][4]).lower() == "true"
        action = "disable" if enabled else "enable"
        if not self._confirm(f"{'Disable' if enabled else 'Enable'} computer", f"Are you sure you want to {action} {name}?"):
            return
        ok, msg = connector.disable_computer(name) if enabled else connector.enable_computer(name)
        self._show_toast(f"{name} {'disabled' if enabled else 'enabled'}." if ok else f"Error: {msg}", error=not ok)
        if ok:
            self.refresh()

    def _on_move(self) -> None:
        names = self._get_selected_names()
        connector = self._get_connector()
        if not names or not connector:
            return
        selected = names[0]
        current_dn = str(self.tree.item(selected)["values"][6])
        target_holder: dict[str, str] = {"dn": ""}

        def on_move(target_dn: str) -> None:
            target_holder["dn"] = target_dn

        dialog = MoveObjectDialog(
            self,
            title="Move computer",
            current_dn=current_dn,
            load_tree=connector.get_ou_tree,
            on_move=on_move,
        )
        dialog.wait_window()
        if not target_holder["dn"]:
            return
        errors = []
        for name in names:
            ok, msg = connector.move_computer(name, target_holder["dn"])
            if not ok:
                errors.append(f"{name}: {msg}")
        if errors:
            self._show_toast(f"Errors: {'; '.join(errors)}", error=True)
        else:
            self._show_toast(f"{len(names)} computer(s) moved.")
            self.refresh()

    def _on_manage_groups(self) -> None:
        name = self._get_selected_name()
        connector = self._get_connector()
        if not name or not connector:
            return
        from ui.dialogs.manage_computer_groups_dialog import ManageComputerGroupsDialog

        dialog = ManageComputerGroupsDialog(self, connector, name)
        dialog.wait_window()
        self.refresh()

    def _on_delete(self) -> None:
        names = self._get_selected_names()
        connector = self._get_connector()
        if not names or not connector:
            return
        if not self._confirm(
            "Delete computers",
            f"Permanently delete {len(names)} computer(s)?\n" + "\n".join(names) + "\n\nThis cannot be undone.",
        ):
            return
        errors = []
        for name in names:
            ok, msg = connector.delete_computer(name)
            if not ok:
                errors.append(f"{name}: {msg}")
        if errors:
            self._show_toast(f"Errors: {'; '.join(errors)}", error=True)
        else:
            self._show_toast(f"{len(names)} computer(s) deleted.")
            self.refresh()

    def _get_selected_domain_id(self) -> str | None:
        return self._current_domain_id or self.app.selected_domain_id

    def _get_connector(self):
        domain_id = self._get_selected_domain_id()
        if not domain_id:
            self._show_toast("No domain selected.", error=True)
            return None
        try:
            connector = self.domain_manager.get_connector(domain_id)
        except Exception:
            self.domain_manager.connect_domain(domain_id)
            connector = self.domain_manager.get_connector(domain_id)
        if not connector or not connector.is_connected:
            self._show_toast("Domain is offline.", error=True)
            return None
        return connector

    def _confirm(self, title: str, message: str) -> bool:
        return mb.askyesno(title, message)

    def _show_toast(self, message: str, error: bool = False) -> None:
        color = "#C0392B" if error else "#27AE60"
        toast = ctk.CTkLabel(self, text=message, fg_color=color, corner_radius=8, text_color="white", padx=12, pady=6)
        toast.place(relx=0.5, rely=0.97, anchor="s")
        self.after(3000, toast.destroy)
