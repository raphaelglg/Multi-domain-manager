"""Users grid with filters, toolbar actions, and CSV export."""

from __future__ import annotations

import csv
import threading
from tkinter import Menu, filedialog, simpledialog, ttk
from typing import TYPE_CHECKING

import customtkinter as ctk

from core.ad_constants import UAC_ACCOUNTDISABLE, _filetime_to_iso
from core.user_manager import UserManager
from ui.dialogs.confirm_dialog import ask_confirm
from ui.dialogs.edit_user_dialog import EditUserDialog
from ui.dialogs.manage_groups_dialog import ManageGroupsDialog
from ui.dialogs.move_object_dialog import MoveObjectDialog
from ui.dialogs.object_detail_dialog import ObjectDetailDialog
from ui.dialogs.reset_password_dialog import ResetPasswordDialog
from ui.dialogs.user_detail_dialog import UserDetailDialog
from ui.toast import show_toast
from utils.audit_logger import append_error_log, append_runtime_log

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class UsersTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app
        self._cache: list[dict] = []
        self._view: list[dict] = []
        self._limit = 500

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=6)
        self.search = ctk.CTkEntry(top, placeholder_text="Search (name, logon name, email)")
        self.search.pack(side="left", fill="x", expand=True, padx=4)
        self.status_f = ctk.CTkOptionMenu(top, values=["All", "Enabled", "Disabled"])
        self.status_f.set("All")
        self.status_f.pack(side="left", padx=4)
        self.ou_f = ctk.CTkEntry(top, placeholder_text="Filter OU (contains)")
        self.ou_f.pack(side="left", padx=4, fill="x", expand=True)
        self.grp_f = ctk.CTkEntry(top, placeholder_text="Filter group (memberOf DN contains)")
        self.grp_f.pack(side="left", padx=4, fill="x", expand=True)
        ctk.CTkButton(top, text="Apply filters", width=120, command=self._apply_filters).pack(side="left", padx=4)

        tb = ctk.CTkFrame(self, fg_color="transparent")
        tb.pack(fill="x", padx=8, pady=4)
        self._btns: dict[str, ctk.CTkButton] = {}
        for spec in (
            ("new", "+ New user", self._act_new, False),
            ("edit", "✎ Edit", self._act_edit, True),
            ("det", "👁 Details", self._act_details, True),
            ("unlock", "🔓 Unlock", self._act_unlock, True),
            ("tog", "⏸ Disable / ▶ Enable", self._act_toggle, True),
            ("pwd", "🔑 Reset password", self._act_reset_pwd, True),
            ("move", "➜ Move to OU", self._act_move, True),
            ("grp", "👥 Groups", self._act_groups, True),
            ("del", "🗑 Delete", self._act_delete, True),
            ("rel", "↻ Reload", self.reload, False),
            ("exp", "⬇ Export CSV", self._export, False),
        ):
            key, label, cmd, needs_sel = spec
            b = ctk.CTkButton(tb, text=label, width=118, command=cmd)
            b.pack(side="left", padx=2, pady=2)
            self._btns[key] = b

        self.progress = ctk.CTkProgressBar(self, mode="indeterminate")
        self.tree_frame = ctk.CTkFrame(self)
        self.tree_frame.pack(fill="both", expand=True, padx=8, pady=6)

        cols = (
            "displayName",
            "sAMAccountName",
            "mail",
            "ou",
            "groups",
            "status",
            "lastlogon",
            "domain",
        )
        self.tree = ttk.Treeview(self.tree_frame, columns=cols, show="headings", height=18, selectmode="extended")
        headings = {
            "displayName": "Name",
            "sAMAccountName": "Logon name",
            "mail": "Email",
            "ou": "OU",
            "groups": "Groups",
            "status": "Status",
            "lastlogon": "Last logon",
            "domain": "Domain / client",
        }
        for c in cols:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=120 if c != "ou" else 220, stretch=True)
        vsb = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)

        self.tree.bind("<Double-1>", self._open_detail)
        self.tree.bind("<Button-3>", self._menu)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._update_toolbar())

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=8, pady=4)
        self.lbl_count = ctk.CTkLabel(foot, text="")
        self.lbl_count.pack(side="left")
        ctk.CTkButton(foot, text="Load more (+500)", command=self._more).pack(side="right")

        self.reload()
        self._update_toolbar()

    def focus_sam(self, sam: str) -> None:
        self.search.delete(0, "end")
        self.search.insert(0, sam.strip())
        self._apply_filters()

    def _selected_domain_filter(self) -> str | None:
        return self.app.selected_domain_id

    def _update_toolbar(self) -> None:
        sel = self.tree.selection()
        one = len(sel) == 1
        for key, b in self._btns.items():
            if key in ("rel", "exp", "new"):
                b.configure(state="normal")
            else:
                b.configure(state="normal" if one else "disabled")

    def _single_user(self) -> dict | None:
        sel = self.tree.selection()
        if len(sel) != 1:
            return None
        dn = sel[0]
        for u in self._view:
            if u.get("distinguishedName") == dn:
                return u
        return None

    def _did_for(self, u: dict) -> str | None:
        return u.get("domain_id") or self._selected_domain_filter()

    def _act_new(self) -> None:
        self.app.open_create_user_tab(None)

    def _act_edit(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did:
            show_toast(self, "Select a domain in the sidebar.")
            return
        EditUserDialog(self, app=self.app, domain_id=did, user=u, on_saved=self.reload)

    def _act_details(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            ObjectDetailDialog(self, title=f"Details — {u.get('sAMAccountName')}", payload=u)
            return

        def load() -> None:
            try:
                con = self.app.dm.get_connector(did)
                fresh = con.get_user_by_sam(str(u.get("sAMAccountName", ""))) or {}
                merged = dict(u)
                merged.update(fresh)
                self.after(0, lambda: ObjectDetailDialog(self, title=f"Details — {merged.get('sAMAccountName')}", payload=merged))
            except Exception:
                self.after(0, lambda: ObjectDetailDialog(self, title=f"Details — {u.get('sAMAccountName')}", payload=u))

        threading.Thread(target=load, daemon=True).start()

    def _act_unlock(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))
        mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
        ok, msg = mgr.unlock(sam)
        self.app.log_audit("unlock_user", did, sam, ok, err=msg)
        show_toast(self, "Account unlocked." if ok else msg[:200])
        self.reload()

    def _act_toggle(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))
        uac = int(u.get("userAccountControl") or 0)
        disabled = bool(uac & UAC_ACCOUNTDISABLE)
        if not disabled:
            if not ask_confirm(self, "Disable account", "Disable this account?"):
                return
        mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
        if disabled:
            ok, msg = mgr.enable(sam)
        else:
            ok, msg = mgr.disable(sam)
        self.app.log_audit("toggle_user", did, sam, ok, err=msg)
        show_toast(self, "Account state updated." if ok else msg[:200])
        self.reload()

    def _act_reset_pwd(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))

        def on_confirm(pwd: str, must_change: bool) -> None:
            mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
            ok, msg = mgr.reset_password(sam, pwd, must_change=must_change)
            self.app.log_audit("reset_password", did, sam, ok, err=msg, params={"must_change": must_change})
            show_toast(self, "Password reset." if ok else msg[:200])
            self.reload()

        ResetPasswordDialog(self, display_name=u.get("displayName") or sam, on_confirm=on_confirm)

    def _act_move(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))
        cur_dn = str(u.get("distinguishedName", ""))

        def load_tree() -> list[dict]:
            return self.app.dm.get_connector(did).get_ou_tree()

        def on_move(target: str) -> None:
            mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
            ok, msg = mgr.move(cur_dn, target)
            self.app.log_audit("move_user", did, cur_dn, ok, err=msg, params={"target": target})
            show_toast(self, "User moved." if ok else msg[:200])
            self.reload()

        MoveObjectDialog(self, title=f"Move — {sam}", current_dn=cur_dn, load_tree=load_tree, on_move=on_move)

    def _act_groups(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))
        dn = str(u.get("distinguishedName", ""))
        mos = u.get("memberOf") or []
        if isinstance(mos, str):
            mos = [x for x in mos.split(";") if x]
        ManageGroupsDialog(self, app=self.app, domain_id=did, user_sam=sam, user_dn=dn, initial_member_of=list(mos), on_done=self.reload)

    def _act_delete(self) -> None:
        u = self._single_user()
        if not u:
            return
        did = self._did_for(u)
        if not did or not self.app.ensure_online(did):
            return
        sam = str(u.get("sAMAccountName", ""))
        if not ask_confirm(self, "Delete user", "Are you sure you want to delete this account?"):
            return
        typed = simpledialog.askstring("Confirmation", f"Type the logon name ({sam}) to confirm:", parent=self)
        if (typed or "").strip() != sam:
            show_toast(self, "Confirmation does not match.")
            return
        mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
        ok, msg = mgr.delete(sam)
        self.app.log_audit("delete_user", did, sam, ok, err=msg)
        show_toast(self, "User deleted." if ok else msg[:200])
        self.reload()

    def reload(self) -> None:
        self.progress.pack(fill="x", padx=8, pady=4)
        self.progress.start()

        def work() -> list[dict]:
            if self._selected_domain_filter():
                did = self._selected_domain_filter()
                try:
                    try:
                        con = self.app.dm.get_connector(did)
                    except Exception:
                        self.app.dm.connect_domain(did)
                        con = self.app.dm.get_connector(did)
                    if not con.is_connected:
                        append_runtime_log(self.app.project_root, f"users_tab:reload:{did}:connector_offline")
                        return []
                    rows = con.get_all_users()
                    dcfg = self.app.dm.get_domain(did) or {}
                    for r in rows:
                        r["domain_id"] = did
                        r["client_name"] = dcfg.get("client_name", "")
                        r["domain_name"] = dcfg.get("domain_name", "")
                    append_runtime_log(self.app.project_root, f"users_tab:reload:{did}:rows={len(rows)}")
                    if not rows:
                        append_runtime_log(
                            self.app.project_root,
                            f"users_tab:reload:{did}:last_error={getattr(con, 'last_error', '')}",
                        )
                    return rows
                except Exception as e:  # noqa: BLE001
                    append_error_log(self.app.project_root, f"users_tab reload {did}", e)
                    return []
            return self.app.dm.get_all_users_consolidated()

        def done(rows: list[dict]) -> None:
            self._cache = rows
            self._limit = 500
            self.progress.stop()
            self.progress.pack_forget()
            self._apply_filters()

        def thread_target() -> None:
            rows = work()
            self.after(0, lambda: done(rows))

        threading.Thread(target=thread_target, daemon=True).start()

    def _apply_filters(self) -> None:
        q = self.search.get().strip().lower()
        st = self.status_f.get()
        ouq = self.ou_f.get().strip().lower()
        grpq = self.grp_f.get().strip().lower()
        did = self._selected_domain_filter()

        def ok(u: dict) -> bool:
            if did and u.get("domain_id") != did:
                return False
            uac = int(u.get("userAccountControl") or 0)
            disabled = bool(uac & UAC_ACCOUNTDISABLE)
            if st == "Enabled" and disabled:
                return False
            if st == "Disabled" and not disabled:
                return False
            dn = (u.get("distinguishedName") or "").lower()
            if ouq and ouq not in dn:
                return False
            if grpq:
                mos = u.get("memberOf") or []
                if isinstance(mos, str):
                    mos = [x for x in mos.split(";") if x]
                mos_l = [str(x).lower() for x in mos]
                if not any(grpq in m for m in mos_l):
                    return False
            if q:
                blob = " ".join(
                    [
                        str(u.get("displayName", "")),
                        str(u.get("sAMAccountName", "")),
                        str(u.get("mail", "")),
                        str(u.get("userPrincipalName", "")),
                    ]
                ).lower()
                if q not in blob:
                    return False
            return True

        self._view = [u for u in self._cache if ok(u)]
        self._fill_tree()
        self._update_toolbar()

    def _fill_tree(self) -> None:
        for i in self.tree.get_children():
            self.tree.delete(i)
        chunk = self._view[: self._limit]
        for u in chunk:
            uac = int(u.get("userAccountControl") or 0)
            disabled = bool(uac & UAC_ACCOUNTDISABLE)
            ou = ",".join((u.get("distinguishedName") or "").split(",")[1:])
            mos = u.get("memberOf") or []
            if isinstance(mos, str):
                mos = [x for x in mos.split(";") if x]
            vals = (
                u.get("displayName", ""),
                u.get("sAMAccountName", ""),
                u.get("mail", ""),
                ou,
                str(len(mos)),
                "Disabled" if disabled else "Enabled",
                _filetime_to_iso(u.get("lastLogonTimestamp")),
                u.get("client_name") or u.get("domain_name", ""),
            )
            self.tree.insert("", "end", iid=u.get("distinguishedName", ""), values=vals)
        self.lbl_count.configure(text=f"Showing {len(chunk)} of {len(self._view)} (cache: {len(self._cache)})")

    def _more(self) -> None:
        self._limit += 500
        self._fill_tree()

    def _export(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(
                [
                    "Name",
                    "Logon name",
                    "Email",
                    "OU",
                    "Groups",
                    "Status",
                    "Last logon",
                    "Domain",
                    "DN",
                ]
            )
            for u in self._view:
                uac = int(u.get("userAccountControl") or 0)
                disabled = bool(uac & UAC_ACCOUNTDISABLE)
                ou = ",".join((u.get("distinguishedName") or "").split(",")[1:])
                mos = u.get("memberOf") or []
                if isinstance(mos, str):
                    mos = [x for x in mos.split(";") if x]
                w.writerow(
                    [
                        u.get("displayName", ""),
                        u.get("sAMAccountName", ""),
                        u.get("mail", ""),
                        ou,
                        len(mos),
                        "Disabled" if disabled else "Enabled",
                        _filetime_to_iso(u.get("lastLogonTimestamp")),
                        u.get("client_name") or u.get("domain_name", ""),
                        u.get("distinguishedName", ""),
                    ]
                )

    def _current_user(self) -> dict | None:
        return self._single_user()

    def _open_detail(self, evt=None) -> None:
        if evt is not None:
            row = self.tree.identify_row(evt.y)
            if row:
                self.tree.selection_set(row)
        u = self._current_user()
        if not u:
            return

        def toggle(user: dict) -> None:
            did = user.get("domain_id")
            if not did:
                return
            if not self.app.ensure_online(did):
                return
            mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
            ok = False
            sam = str(user.get("sAMAccountName", ""))
            uac = int(user.get("userAccountControl") or 0)
            if uac & UAC_ACCOUNTDISABLE:
                ok, _ = mgr.enable(sam)
            else:
                ok, _ = mgr.disable(sam)
            self.app.log_audit("toggle_user", did, sam, ok)
            self.reload()

        def reset(user: dict, pwd: str) -> None:
            did = user.get("domain_id")
            if not did:
                return
            if not self.app.ensure_online(did):
                return
            mgr = UserManager(self.app.dm.get_connector(did), audit=self.app.make_audit_cb(did))
            sam = str(user.get("sAMAccountName", ""))
            ok, _ = mgr.reset_password(sam, pwd, must_change=False)
            self.app.log_audit("reset_password", did, sam, ok)
            self.reload()

        UserDetailDialog(self, user=u, actions={"toggle": toggle, "reset": reset})

    def _menu(self, event) -> None:
        row = self.tree.identify_row(event.y)
        if not row:
            return
        self.tree.selection_set(row)
        u = self._current_user()
        if not u:
            return
        menu = Menu(self, tearoff=0)
        menu.add_command(label="Details", command=self._act_details)
        menu.add_command(label="Edit…", command=self._act_edit)
        menu.add_command(label="Disable / Enable", command=self._act_toggle)
        menu.add_command(label="Move to OU…", command=self._act_move)
        menu.add_command(label="Manage groups…", command=self._act_groups)
        menu.tk_popup(event.x_root, event.y_root)
