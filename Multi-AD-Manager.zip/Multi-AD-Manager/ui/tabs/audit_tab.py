"""Local audit log viewer."""

from __future__ import annotations

from tkinter import ttk
from typing import TYPE_CHECKING

import customtkinter as ctk

if TYPE_CHECKING:
    from ui.app import AdManagerApp


class AuditTab(ctk.CTkFrame):
    def __init__(self, master, *, app: "AdManagerApp") -> None:
        super().__init__(master)
        self.app = app

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=6)
        self.op = ctk.CTkEntry(top, placeholder_text="Operation contains")
        self.op.pack(side="left", fill="x", expand=True, padx=4)
        self.only_fail = ctk.CTkCheckBox(top, text="Failures only")
        self.only_fail.pack(side="left", padx=6)
        ctk.CTkButton(top, text="Apply", command=self.reload).pack(side="right", padx=4)

        cols = ("ts", "analyst", "domain", "op", "target", "ok", "err")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=20)
        for c, t, w in zip(
            cols,
            ("When", "Operator", "Domain", "Operation", "Target", "OK", "Error"),
            (160, 120, 160, 160, 220, 50, 260),
            strict=False,
        ):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, stretch=True)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=6)
        vsb.pack(side="right", fill="y", padx=(0, 8), pady=6)

        self.reload()

    def reload(self) -> None:
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.app.audit.fetch(
            limit=800,
            operation_like=self.op.get().strip() or None,
            only_failures=bool(self.only_fail.get()),
        )
        for r in rows:
            self.tree.insert(
                "",
                "end",
                values=(
                    r.get("ts", ""),
                    r.get("analyst", ""),
                    r.get("domain_name", "") or r.get("domain_id", ""),
                    r.get("operation", ""),
                    r.get("target", ""),
                    "yes" if r.get("success") else "no",
                    r.get("error", ""),
                ),
            )
