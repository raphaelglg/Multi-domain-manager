@echo off
chcp 65001 >nul
title AD Manager — Dependency Installer

:: Change to the directory where this .bat file is located
cd /d "%~dp0"

echo.
echo ============================================================
echo   AD Manager - Dependency Installer
echo ============================================================
echo.

:: ─── CHECK PYTHON ────────────────────────────────────────────
:CHECK_PYTHON
python --version >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Python not found in PATH.
    echo.
    choice /c YN /m "Do you want to download and install Python 3.11 automatically?"
    if errorlevel 2 (
        echo [INFO] Skipped Python installation. Exiting.
        pause
        exit /b 1
    )
    goto DOWNLOAD_PYTHON
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [OK] Python found: %PYVER%
goto CHECK_PYVER

:: ─── DOWNLOAD AND INSTALL PYTHON ─────────────────────────────
:DOWNLOAD_PYTHON
echo.
echo [INFO] Detecting system architecture...

reg query "HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0" /v Identifier | find "x86" >nul 2>&1
if errorlevel 1 (
    set PYARCH=amd64
    set PYINSTALLER_URL=https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
    echo [OK] Architecture: 64-bit
) else (
    set PYARCH=win32
    set PYINSTALLER_URL=https://www.python.org/ftp/python/3.11.9/python-3.11.9.exe
    echo [OK] Architecture: 32-bit
)

echo [INFO] Downloading Python 3.11.9 (%PYARCH%)...
echo        This may take a few minutes depending on your connection.
echo.

powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%PYINSTALLER_URL%' -OutFile 'python_installer.exe'}" >nul 2>&1
if errorlevel 1 (
    echo [WARNING] PowerShell download failed. Trying with curl...
    curl -L -o python_installer.exe "%PYINSTALLER_URL%" --progress-bar
    if errorlevel 1 (
        echo [ERROR] Failed to download Python installer.
        echo         Please download manually from https://www.python.org/downloads/
        echo         and run this script again.
        echo.
        pause
        exit /b 1
    )
)

if not exist python_installer.exe (
    echo [ERROR] Python installer not found after download.
    pause
    exit /b 1
)

echo [OK] Download complete.
echo.
echo [INFO] Installing Python 3.11.9...

python_installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_pip=1 Include_launcher=1

if errorlevel 1 (
    echo [ERROR] Python installation failed.
    echo         Try running this script as Administrator.
    del /f /q python_installer.exe >nul 2>&1
    pause
    exit /b 1
)

echo [OK] Python installed successfully.
del /f /q python_installer.exe >nul 2>&1

:: Refresh PATH in current session
for /f "tokens=2*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set SYS_PATH=%%b
for /f "tokens=2*" %%a in ('reg query "HKCU\Environment" /v Path 2^>nul') do set USR_PATH=%%b
set PATH=%SYS_PATH%;%USR_PATH%;%PATH%

for %%d in (
    "%LOCALAPPDATA%\Programs\Python\Python311"
    "%LOCALAPPDATA%\Programs\Python\Python311\Scripts"
    "C:\Python311"
    "C:\Python311\Scripts"
    "C:\Program Files\Python311"
    "C:\Program Files\Python311\Scripts"
) do (
    if exist "%%~d\python.exe" set PATH=%%~d;%PATH%
    if exist "%%~d\pip.exe"    set PATH=%%~d;%PATH%
)

python --version >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Python installed but not yet available in this session.
    echo           Please close this window, open a new Command Prompt and run again.
    echo.
    pause
    exit /b 0
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [OK] Python %PYVER% is ready.
echo.

:: ─── CHECK MINIMUM VERSION ───────────────────────────────────
:CHECK_PYVER
for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
    set PYMAJ=%%a
    set PYMIN=%%b
)
if %PYMAJ% LSS 3 (
    echo [ERROR] Python 3.11+ required. Found: %PYVER%
    pause
    exit /b 1
)
if %PYMAJ% EQU 3 if %PYMIN% LSS 11 (
    echo [WARNING] Python 3.11+ recommended. Found: %PYVER%
    echo           Continuing anyway...
    echo.
)

:: ─── ENSURE PIP IS AVAILABLE ─────────────────────────────────
echo [INFO] Ensuring pip is available...
python -m ensurepip --upgrade >nul 2>&1
python -m pip --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] pip is not available and could not be installed.
    pause
    exit /b 1
)
echo [OK] pip is ready.

:: ─── CHECK REQUIREMENTS.TXT ──────────────────────────────────
if not exist requirements.txt (
    echo [ERROR] requirements.txt not found in: %cd%
    echo         Make sure requirements.txt is in the same folder as this .bat file.
    echo.
    pause
    exit /b 1
)
echo [OK] requirements.txt found.

:: ─── UPGRADE PIP ─────────────────────────────────────────────
echo.
echo [INFO] Upgrading pip...
python -m pip install --upgrade pip --quiet
echo [OK] pip upgraded.

:: ─── INSTALL REQUIREMENTS ────────────────────────────────────
echo.
echo [INFO] Installing dependencies from requirements.txt...
echo.
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to install one or more dependencies.
    echo         Check your internet connection and try again.
    echo         If the error persists, run manually:
    echo           python -m pip install -r requirements.txt
    echo.
    pause
    exit /b 1
)

:: ─── PYWINRM EXTRAS (OPTIONAL) ───────────────────────────────
echo.
echo [INFO] Installing Kerberos support for pywinrm (optional)...
python -m pip install pywinrm[kerberos] --quiet
if errorlevel 1 (
    echo [WARNING] Kerberos support not installed (not required).
    echo           NTLM authentication will continue to work normally.
) else (
    echo [OK] Kerberos support installed.
)

echo [INFO] Installing CredSSP support for pywinrm (optional)...
python -m pip install pywinrm[credssp] --quiet
if errorlevel 1 (
    echo [WARNING] CredSSP support not installed (not required).
) else (
    echo [OK] CredSSP support installed.
)

:: ─── VERIFY CRITICAL PACKAGES ────────────────────────────────
echo.
echo [INFO] Verifying critical installations...
echo.

set FAILED=0

python -c "import customtkinter; print('[OK] customtkinter', customtkinter.__version__)" 2>nul
if errorlevel 1 ( echo [ERROR] customtkinter not installed & set FAILED=1 )

python -c "import winrm; print('[OK] pywinrm OK')" 2>nul
if errorlevel 1 ( echo [ERROR] pywinrm not installed & set FAILED=1 )

python -c "import cryptography; print('[OK] cryptography OK')" 2>nul
if errorlevel 1 ( echo [ERROR] cryptography not installed & set FAILED=1 )

python -c "import requests; print('[OK] requests OK')" 2>nul
if errorlevel 1 ( echo [ERROR] requests not installed & set FAILED=1 )

python -c "from PIL import Image; print('[OK] Pillow OK')" 2>nul
if errorlevel 1 ( echo [ERROR] Pillow not installed & set FAILED=1 )

python -c "import PyInstaller; print('[OK] PyInstaller OK')" 2>nul
if errorlevel 1 ( echo [WARNING] PyInstaller not installed (only needed to build .exe) )

:: ─── FINAL RESULT ────────────────────────────────────────────
echo.
if %FAILED% EQU 1 (
    echo ============================================================
    echo   INSTALLATION COMPLETED WITH ERRORS
    echo   Some critical packages failed. See errors above.
    echo   Try running this script as Administrator.
    echo ============================================================
) else (
    echo ============================================================
    echo   INSTALLATION COMPLETED SUCCESSFULLY
    echo   Run the app with: python main.py
    echo ============================================================
)

echo.
pause