"""Entry point for AD Multi-Domain Manager."""

from __future__ import annotations

import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    ROOT = Path(sys.executable).parent
else:
    ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _ensure_icon() -> str | None:
    path = ROOT / "assets" / "app_icon.ico"
    if path.exists():
        return str(path)
    try:
        from PIL import Image, ImageDraw

        path.parent.mkdir(parents=True, exist_ok=True)
        img = Image.new("RGB", (64, 64), color="#1f2a37")
        dr = ImageDraw.Draw(img)
        dr.rounded_rectangle((8, 8, 56, 56), radius=10, outline="#4a90d9", width=4)
        dr.text((18, 22), "AD", fill="#e5e7eb")
        img.save(path, format="ICO")
        return str(path)
    except Exception:
        return None


def main() -> None:
    import customtkinter as ctk

    from ui.app import AdManagerApp

    app = AdManagerApp(ROOT)
    icon = _ensure_icon()
    if icon:
        try:
            app.iconbitmap(icon)
        except Exception:
            pass
    app.mainloop()


if __name__ == "__main__":
    main()
